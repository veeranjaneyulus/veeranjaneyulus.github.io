function [ Dk ] = gen_Dk( x,k )
% gen_Dk    this function generate Dk, the discrete kth order derivative
%           matrix
% input
% x         data points
% k         order k

n=length(x);
if k==0
   Dk=speye(n);
   return;
end
Dk=gen_D1(n);
for i=1:k-1
    Dk=gen_D1(n-i)*diag(i./(x(i+1:n)-x(1:n-i)))*Dk;
end


end

