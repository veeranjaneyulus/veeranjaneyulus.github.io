kmax = 5;
m=250;n=250;num=500;
polyproj=false; % do not project out polynomials
w=0;
runsim=true; % true -> run simulations, false -> only plot
centerhks=false; % true -> HKS zero derivatives at mean of [x;y], false -> zero derivatives at 0
hksalldeg = [1:5, 8:4:20]; hks_choices = [1,2,3,5,6];
mmdpolydeg = [1:5, 8:4:20]; mmd_choices = [1,2,3,5,6];
hksodddeg = 1:2:kmax;
[tests_noolr,tt] = tests_noproj(kmax,polyproj,w,mmdpolydeg,hksalldeg,centerhks);
% [tests_noolr,iproj,iprojfree,ihksall,immdpoly,iks,ienergy,immd,iad] = alltests(kmax, polyproj,w,mmdpolydeg,hksalldeg);
tt.iolr = numel(tests_noolr)+1;

dr = sprintf('NewPlots2/kuiper_m%d_',m);
suff = 'mmdweights'; % suffix indicating the method to combine hks test stats 
if centerhks
    expsuff = ''; 
else
    expsuff = '_pin0';
end
legend_labs_projfree = {'KS.new','MMD.poly','KS','Oracle'};
legend_labs_proj = {'KS.new.proj','MMD.poly','KS','Oracle'};
legend_labs_comb = {sprintf('KS.%s',suff),'MMD.poly','KS','Oracle'};

cc = get_colors();

%% N(0,1) vs. N(0.2,1)
prefix = sprintf('%sExp_1stMoment_v1%s',dr,expsuff);
mu_diff = 0.2;
pd = makedist('Normal');
pd2 = makedist('Normal','mu',mu_diff);
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n));
olrfun = @(x,y) olrfun_pd(x,y,pd,pd2);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end

plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)

%% N(0,1) vs. N(0,1.44)
prefix = sprintf('%sExp_2ndMoment_v1%s',dr,expsuff);
sigma_diff = 0.2;
pd = makedist('Normal');
pd2 = makedist('Normal','sigma',1+sigma_diff);
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n));
olrfun = @(x,y) olrfun_pd(x,y,pd,pd2);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end

plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)

%% Laplace(0,1/sqrt(2)) vs. Laplace(0,1/2)
prefix = sprintf('%sExp_2ndMoment_v2%s',dr,expsuff);
b_diff=1/sqrt(2);
pd = makedist('Exponential','mu',1/2);
pd2 = makedist('Exponential','mu',1/sqrt(2));

xgen = @(m,n) sort(random(pd,m,n).*((rand(m,n)<0.5)-0.5)*2);
ygen = @(m,n) sort(random(pd2,m,n).*((rand(m,n)<0.5)-0.5)*2);
olrfun = @(x,y) olrfun_pd(abs(x),abs(y),pd,pd2); % p, q multiplied by 2
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end

plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)

%% N(0,1) vs. Laplace(0,1/sqrt(2))
prefix = sprintf('%sExp_3rdMoment_v1%s',dr,expsuff);
pd = makedist('Normal');
pd2 = makedist('Exponential','mu',1/sqrt(2));
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n).*((rand(m,n)<0.5)-0.5)*2);
olrfun = @(x,y) olrfun_normal_laplace(x,y);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end

plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)
load(sprintf('%s.mat',prefix),'ex')
plotHKSMMD(ex,sprintf('%s_%s_HKSMMD_3.pdf',prefix,suff),tt.ihksall(1:3),tt.iks,tt.immdpoly(1:3),tt.iolr,hksalldeg(hks_choices), mmdpolydeg(mmd_choices), cc)
%% Normal vs t(5)*3/5

prefix = sprintf('%sExp_3rdMoment_v2%s',dr,expsuff);
pd = makedist('Normal');
nu=5;
pd2 = makedist('tLocationScale','sigma',sqrt((nu-2)/nu),'nu',nu);%default dof=5
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n));
olrfun = @(x,y) olrfun_pd(x,y,pd,pd2);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end

plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)

%% Normal vs. t(3)
prefix = sprintf('%sExp_normal_vs_t3_50_%s',dr,expsuff);
pd = makedist('Normal');
pd2 = makedist('tLocationScale','nu',3);%default dof=5

m=50;n=50;
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n));
olrfun = @(x,y) olrfun_pd(x,y,pd,pd2);
tests = [tests_noolr {olrfun}];
if runsim
    ex = exp_roc(xgen,ygen,m,n,num,tests);
    res = simulate(ex);
    save(sprintf('%s.mat',prefix),'ex');
end

plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)


% n=10000;
% x=sort(random(pd,n,1));
% y=sort(random(pd2,n,1));
% [mm,vv,ss,0;mean(x),var(x),skewness(x),kurtosis(x); mean(y),var(y),skewness(y),kurtosis(y)]

%% oracle likelihood function


function olr = olrfun_3rdMoment_v1(x,y,m,n)
    pd = makedist('Normal');
    pd2 = makedist('Exponential','mu',1/sqrt(2));
    logL0 = sum(log( (pdf(pd,[x;y]) + pdf(pd2,abs([x;y]))/2 )/2 ));
    logL1 = sum(log(pdf(pd,x)) + log(pdf(pd2,abs(y))/2));
    olr=logL1-logL0;
end

%% plotting functions
%% Plot PDFs of two distributions
function [] = plotpdfs(filename,x,pdf1,pdf2,lab1,lab2)
    figure
    plot(x,pdf1,x,pdf2,'LineWidth',2)
    lh=legend(lab1,lab2);
    set(lh,'fontsize',16)
    set(gca,'Position',[.05 .05 .9 .93])
    saveTightFig(gcf,filename);
end

%% test functions
function [tests,tt] = tests_noproj(kmax,polyproj,w,mmdpolydeg,hksalldeg,centerhks)
    for k=1:kmax
        projfree_tests{k} = @(x,y) HKS_projfree_test(x,y,k,polyproj,centerhks);
    end
    for i=1:numel(mmdpolydeg)
        mmdpoly_tests{i} = @(x,y) mmdTestPoly(x,y,mmdpolydeg(i));
    end
    for i=1:numel(hksalldeg)
        hksall_tests{i} = @(x,y) HKS_allk_test(x,y,hksalldeg(i),centerhks);
    end
    tests = [ projfree_tests hksall_tests mmdpoly_tests ...
        {@kstestfun, @kuipertestfun, @mmdfun, @adtestfun}];
    
    tt.iprojfree=1:kmax;
    tt.ihksall= tt.iprojfree(end)+ (1:numel(hksalldeg));
    tt.immdpoly=tt.ihksall(end)+ (1:numel(mmdpolydeg));
    tt.iks=max(tt.immdpoly)+1;
    tt.ienergy=tt.iks+1; 
    tt.immd=tt.iks+2;
    tt.iad=tt.iks+3;
end

function [tests,iproj,iprojfree,ihksall,immdpoly,iks,ienergy,immd,iad] = alltests(kmax,polyproj,w,mmdpolydeg,hksalldeg)
    for k=1:kmax
        proj_tests{k} = @(x,y) HKSHseptest(x,y,k,w);
        projfree_tests{k} = @(x,y) HKS_projfree_test(x,y,k,polyproj);
    end
    for i=1:numel(mmdpolydeg)
        mmdpoly_tests{i} = @(x,y) mmdTestPoly(x,y,mmdpolydeg(i));
    end
    for i=1:numel(hksalldeg)
        hksall_tests{i} = @(x,y) HKS_allk_test(x,y,hksalldeg(i));
    end
    tests = [proj_tests projfree_tests hksall_tests mmdpoly_tests ...
        {@kstestfun, @kuipertestfun, @mmdfun, @adtestfun}];
    iproj=1:kmax;
    iprojfree=iproj+kmax;
    ihksall= iprojfree(end)+ (1:numel(hksalldeg));
    immdpoly=ihksall(end)+ (1:numel(mmdpolydeg));
    iks=max(immdpoly)+1;
    ienergy=iks+1; 
    immd=iks+2;
    iad=iks+3;
end

function [] = plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)
    load(sprintf('%s.mat',prefix),'ex')
    plotHKS(ex,sprintf('%s_HKS_projfree.pdf',prefix),tt.iprojfree,tt.immdpoly,tt.iks,tt.iolr,legend_labs_projfree)
    plotHKSOnly(ex,sprintf('%s_HKSOnly_projfree.pdf',prefix),tt.iprojfree,tt.iks,tt.iolr,cc)
    plotHKS(ex,sprintf('%s_HKS_%s.pdf',prefix,suff),tt.ihksall,tt.immdpoly,tt.iks,tt.iolr,legend_labs_comb)
    plotKSOthers(ex,sprintf('%s_benchmark_projfree.pdf',prefix),tt.iprojfree,tt.immdpoly,tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,mmdpolydeg,1:numel(tt.iprojfree),cc)
    plotKSOthers(ex,sprintf('%s_benchmark_%s.pdf',prefix,suff),tt.ihksall,tt.immdpoly,tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,mmdpolydeg,hksalldeg,cc)
    plotHKSOthers(ex,sprintf('%s_benchmark_projfree_allhksroc.pdf',prefix),tt.iprojfree(hksodddeg),tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,hksodddeg,cc)
    plotBestHKSOthers(ex,sprintf('%s_benchmark_projfree_besthksroc.pdf',prefix),tt.iprojfree,tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,1:numel(tt.iprojfree),cc)
    plotBestHKSOthers(ex,sprintf('%s_benchmark_%s_besthksroc.pdf',prefix,suff),tt.ihksall,tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,hksalldeg,cc)
    plotHKSMMD(ex,sprintf('%s_%s_HKSMMD.pdf',prefix,suff),tt.ihksall(hks_choices),tt.iks,tt.immdpoly(mmd_choices),tt.iolr,hksalldeg(hks_choices), mmdpolydeg(mmd_choices), cc)
end

