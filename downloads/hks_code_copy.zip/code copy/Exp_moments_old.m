kmax = 5;
m=100;n=100;num=1000;
polyproj=false; % do not project out polynomials
w=0;
runsim=false; % true -> run simulations, false -> only plot
hksalldeg = [1:5, 8:4:20]; hks_choices = [1,2,3,5,6];
mmdpolydeg = [1:5, 8:4:20]; mmd_choices = [1,2,3,5,6];
hksodddeg = 1:2:kmax;
[tests_noolr,tt] = tests_noproj(kmax,polyproj,w,mmdpolydeg,hksalldeg);
% [tests_noolr,iproj,iprojfree,ihksall,immdpoly,iks,ienergy,immd,iad] = alltests(kmax, polyproj,w,mmdpolydeg,hksalldeg);
tt.iolr = numel(tests_noolr)+1;

dr = 'NewPlots2/';
suff = 'mmdweights'; % suffix indicating the method to combine hks test stats 
legend_labs_projfree = {'KS.new','MMD.poly','KS','Oracle'};
legend_labs_proj = {'KS.new.proj','MMD.poly','KS','Oracle'};
legend_labs_comb = {sprintf('KS.%s',suff),'MMD.poly','KS','Oracle'};

cc = get_colors();

%% N(0,1) vs. N(0.2,1)
prefix = sprintf('%sExp_1stMoment_v1',dr);
mu_diff = 0.2;
xgen = @(m,n) normrnd(0,1,m,n);
ygen = @(m,n) normrnd(0,1,m,n) + mu_diff;
olrfun = @(x,y) sum(y.^2) - sum( (y-mu_diff).^2);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end

plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)



%% N(0,1) vs. N(0,1.44)
prefix = sprintf('%sExp_2ndMoment_v1_dup',dr);
sigma_diff = 0.2;
xgen = @(m,n) normrnd(0,1,m,n);
ygen = @(m,n) normrnd(0,1,m,n) .* (1+sigma_diff);
olrfun = @(x,y) olrfun_2ndMoment_v1(x,y,sigma_diff);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end


plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)

%% Laplace(0,1/sqrt(2)) vs. Laplace(0,1/2)
prefix = sprintf('%sExp_2ndMoment_v2',dr);
b_diff=1/sqrt(2);
pd = makedist('Exponential','mu',1/2);
pd2 = makedist('Exponential','mu',1/sqrt(2));

xgen = @(m,n) sort(random(pd,m,n).*((rand(m,n)<0.5)-0.5)*2);
ygen = @(m,n) sort(random(pd2,m,n).*((rand(m,n)<0.5)-0.5)*2);
olrfun = @(x,y) olrfun_2ndMoment_v2(x,y,m,n,b_diff);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end

plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)

%% Beta(1.3,2.6) vs Beta(1,2)
prefix = sprintf('%sExp_2ndMoment_v3',dr);
pd = makedist('Beta','a',1.3,'b',2.6);
pd2 = makedist('Beta','a',1,'b',2);
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n));
olrfun = @(x,y) olrfun_pd(x,y,pd,pd2);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end


plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)

%% N(0,1) vs. Laplace(0,1/sqrt(2))
% prefix = sprintf('%sExp_3rdMoment_v1_reverse_pq',dr);
m=100;n=100;
prefix = sprintf('%sExp_3rdMoment_v1',dr);
pd = makedist('Normal');
pd2 = makedist('Exponential','mu',1/sqrt(2));
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n).*((rand(m,n)<0.5)-0.5)*2);
olrfun = @(x,y) olrfun_3rdMoment_v1(x,y,m,n);
% olrfun = @(x,y) olrfun_3rdMoment_v1_rev(x,y,m,n);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end


plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)


plotHKSMMD(ex,sprintf('%s_%s_HKSMMD_3.pdf',prefix,suff),tt.ihksall(1:3),tt.iks,tt.immdpoly(1:3),tt.iolr,hksalldeg(hks_choices), mmdpolydeg(mmd_choices), cc)
%% Normal vs t(5)*3/5


prefix = sprintf('%sExp_3rdMoment_v2',dr);
pd = makedist('Normal');
nu=5;
pd2 = makedist('tLocationScale','sigma',sqrt((nu-2)/nu),'nu',nu);%default dof=5
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n));
olrfun = @(x,y) olrfun_pd(x,y,pd,pd2);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end

plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)

%% Normal vs. t(3)
prefix = sprintf('%sExp_normal_vs_t3',dr);
pd = makedist('Normal');
pd2 = makedist('tLocationScale','nu',3);%default dof=5

m=50;n=50;
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n)); % Uniform -- with triangular bumps
olrfun = @(x,y) olrfun_pd(x,y,pd,pd2);
tests = [tests_noolr {olrfun}];
if runsim
    ex = exp_roc(xgen,ygen,m,n,num,tests);
    res = simulate(ex);
    save(sprintf('%s.mat',prefix),'ex');
end

plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)

%% 4thMoment v1: GEV(k=0.2,sigma=1,mu=0) vs GeneralizedPareto
prefix = sprintf('%sExp_GEV_GP',dr);
k=0.2; sigma=1;mu=0;
pd = makedist('GeneralizedExtremeValue','k',k,'sigma',sigma,'mu',mu);
% mm=mu+sigma*eulergamma;
% vv=sigma^2*pi^2/6;
% ss=12*sqrt(6)*zeta(3)/pi^3;

mm=mu+sigma*(gamma(1-k)-1)/k;
vv=sigma^2*(gamma(1-2*k)-gamma(1-k)^2)/k^2;
ss=(gamma(1-3*k)-3*gamma(1-k)*gamma(1-2*k)+2*gamma(1-k)^3)/(gamma(1-2*k)-gamma(1-k)^2)^(3/2);

fun=@(x) 2*(1+x).*sqrt(1-2.*x)./(1-3.*x) - ss;
xi = fsolve(fun,0.1);
sigma=sqrt(vv*(1-xi)^2*(1-2*xi));
mu=mm-sigma/(1-xi);

pd2 = makedist('GeneralizedPareto','theta',mu,'sigma',sigma,'k',xi);
% chosen such taht variance is 1.

x=-4:.05:4;
plotpdfs(sprintf('%s_pdfs.pdf',prefix),x,pdf(pd,x),pdf(pd2,x),'Gen. Extreme Value','Gen. Pareto');

xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n));
olrfun = @(x,y) olrfun_pd(x,y,pd,pd2);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end


plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)

%% 4thMoment v2: Beta vs GeneralizedPareto
prefix = sprintf('%sExp_Beta_GP',dr);
a=3;
b=2;
pd = makedist('Beta','a',a,'b',b);
mm=a/(a+b);
vv=a*b/(a+b)^2/(a+b+1);
ss=2*(b-a)*sqrt(a+b+1)/(a+b+2)/sqrt(a*b);
fun=@(x) 2*(1+x).*sqrt(1-2.*x)./(1-3.*x) - ss;
xi = fsolve(fun,0.1);
sigma=sqrt(vv*(1-xi)^2*(1-2*xi));
mu=mm-sigma/(1-xi);
pd2 = makedist('GeneralizedPareto','theta',mu,'sigma',sigma,'k',xi);

x=-4:.05:4;
plotpdfs(sprintf('%s_pdfs.pdf',prefix),x,pdf(pd,x),pdf(pd2,x),'Gen. Extreme Value','Gen. Pareto');
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n));
olrfun = @(x,y) olrfun_pd(x,y,pd,pd2);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end


plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)

% n=10000;
% x=sort(random(pd,n,1));
% y=sort(random(pd2,n,1));
% [mm,vv,ss,0;mean(x),var(x),skewness(x),kurtosis(x); mean(y),var(y),skewness(y),kurtosis(y)]

%% oracle likelihood function
function olr = olrfun_pd(x,y,pd,pd2)
    logL0= sum(log(pdf(pd,[x;y])));
    logL1= sum(log(pdf(pd,x))) + sum(log(pdf(pd2,y)));
    olr=logL1-logL0;
end

function olr = olrfun_1stMoment_v0(x,y,mu_diff)
    logL0= -sum(abs([x;y]));
    logL1= -sum(abs(x))-sum(abs(y-mu_diff));
    %logL1= std_normal_logL((y-mu_diff))+std_normal_logL(x);
    olr=logL1-logL0;
end

function olr = olrfun_2ndMoment_v1(x,y,sigma_diff)
    logL0= std_normal_logL( [x;y] );
    logL1= std_normal_logL((y))/(1+sigma_diff)^2 ...
        + length(y)*log(1/(1+sigma_diff)) +std_normal_logL(x);
    olr=logL1-logL0;
end

% function olr = olrfun_2ndMoment_v2(x,y,m,n,b_diff)
%     logL0= sum(-sqrt(2)*abs([x;y])) +(m+n)*log(1/sqrt(2));
%     logL1= sum(-sqrt(2)*abs(x)) +m*log(1/sqrt(2))...
%         +sum(-sqrt(2)/b_diff*abs(y)) +n*log(b_diff/sqrt(2));
%     olr=logL1-logL0;
% end

function olr = olrfun_2ndMoment_v2(x,y,m,n,b_diff)
    logL0= sum(-2*abs([x;y])); % density, p=exp(-2|t|), q=1/sqrt(2) exp(-sqrt(2) |t|)
    logL1= sum(-2*abs(x)) ...
        +sum(-sqrt(2)*abs(y)) +n*log(1/sqrt(2));
    olr=logL1-logL0;
end

function olr = olrfun_3rdMoment_v1(x,y,m,n)
    logL0= 0.5*std_normal_logL( [x;y] ) + (m+n)*log(1/sqrt(2*pi));
    logL1= sum(-sqrt(2)*abs(y)) +n*log(1/sqrt(2))...
        +0.5*std_normal_logL(x)+m*log(1/sqrt(2*pi));
    olr=logL1-logL0;
end
function olr = olrfun_3rdMoment_v1_rev(x,y,m,n)
    logL0= sum(-sqrt(2)*abs([x;y])) +(m+n)*log(1/sqrt(2));
    logL1= sum(-sqrt(2)*abs(x)) +m*log(1/sqrt(2))...
        +0.5*std_normal_logL(y)+n*log(1/sqrt(2*pi));
    olr=logL1-logL0;
end

%% plotting functions
%% Plot PDFs of two distributions
function [] = plotpdfs(filename,x,pdf1,pdf2,lab1,lab2)
    figure
    plot(x,pdf1,x,pdf2,'LineWidth',2)
    lh=legend(lab1,lab2);
    set(lh,'fontsize',16)
    set(gca,'Position',[.05 .05 .9 .93])
    saveTightFig(gcf,filename);
end

%% test functions
function [tests,tt] = tests_noproj(kmax,polyproj,w,mmdpolydeg,hksalldeg)
    for k=1:kmax
        projfree_tests{k} = @(x,y) HKS_projfree_test(x,y,k);
    end
    for i=1:numel(mmdpolydeg)
        mmdpoly_tests{i} = @(x,y) mmdTestPoly(x,y,mmdpolydeg(i));
    end
    for i=1:numel(hksalldeg)
        hksall_tests{i} = @(x,y) HKS_allk_test(x,y,hksalldeg(i));
    end
    tests = [ projfree_tests hksall_tests mmdpoly_tests ...
        {@kstestfun, @energyDist, @mmdfun, @adtestfun}];
    
    tt.iprojfree=1:kmax;
    tt.ihksall= tt.iprojfree(end)+ (1:numel(hksalldeg));
    tt.immdpoly=tt.ihksall(end)+ (1:numel(mmdpolydeg));
    tt.iks=max(tt.immdpoly)+1;
    tt.ienergy=tt.iks+1; 
    tt.immd=tt.iks+2;
    tt.iad=tt.iks+3;
end

function [tests,iproj,iprojfree,ihksall,immdpoly,iks,ienergy,immd,iad] = alltests(kmax,polyproj,w,mmdpolydeg,hksalldeg)
    for k=1:kmax
        proj_tests{k} = @(x,y) HKSHseptest(x,y,k,w);
        projfree_tests{k} = @(x,y) HKS_projfree_test(x,y,k,polyproj);
    end
    for i=1:numel(mmdpolydeg)
        mmdpoly_tests{i} = @(x,y) mmdTestPoly(x,y,mmdpolydeg(i));
    end
    for i=1:numel(hksalldeg)
        hksall_tests{i} = @(x,y) HKS_allk_test(x,y,hksalldeg(i));
    end
    tests = [proj_tests projfree_tests hksall_tests mmdpoly_tests ...
        {@kstestfun, @energyDist, @mmdfun, @adtestfun}];
    iproj=1:kmax;
    iprojfree=iproj+kmax;
    ihksall= iprojfree(end)+ (1:numel(hksalldeg));
    immdpoly=ihksall(end)+ (1:numel(mmdpolydeg));
    iks=max(immdpoly)+1;
    ienergy=iks+1; 
    immd=iks+2;
    iad=iks+3;
end

function [] = plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)
    load(sprintf('%s.mat',prefix),'ex')
    plotHKS(ex,sprintf('%s_HKS_projfree.pdf',prefix),tt.iprojfree,tt.immdpoly,tt.iks,tt.iolr,legend_labs_projfree)
    plotHKSOnly(ex,sprintf('%s_HKSOnly_projfree.pdf',prefix),tt.iprojfree,tt.iks,tt.iolr,cc)
    plotHKS(ex,sprintf('%s_HKS_%s.pdf',prefix,suff),tt.ihksall,tt.immdpoly,tt.iks,tt.iolr,legend_labs_comb)
    plotKSOthers(ex,sprintf('%s_benchmark_projfree.pdf',prefix),tt.iprojfree,tt.immdpoly,tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,mmdpolydeg,1:numel(tt.iprojfree),cc)
    plotKSOthers(ex,sprintf('%s_benchmark_%s.pdf',prefix,suff),tt.ihksall,tt.immdpoly,tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,mmdpolydeg,hksalldeg,cc)
    plotHKSOthers(ex,sprintf('%s_benchmark_projfree_allhksroc.pdf',prefix),tt.iprojfree(hksodddeg),tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,hksodddeg,cc)
    plotBestHKSOthers(ex,sprintf('%s_benchmark_projfree_besthksroc.pdf',prefix),tt.iprojfree,tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,1:numel(tt.iprojfree),cc)
    plotBestHKSOthers(ex,sprintf('%s_benchmark_%s_besthksroc.pdf',prefix,suff),tt.ihksall,tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,hksalldeg,cc)
    plotHKSMMD(ex,sprintf('%s_%s_HKSMMD.pdf',prefix,suff),tt.ihksall(hks_choices),tt.iks,tt.immdpoly(mmd_choices),tt.iolr,hksalldeg(hks_choices), mmdpolydeg(mmd_choices), cc)
end

%% Include projected HKS
% function [] = plot_ex(prefix,iproj,iprojfree,ihksall,immdpoly,iks,ienergy,immd,iad,iolr,mmdpolydeg,hksalldeg,suff,legend_labs_projfree,legend_labs_proj,legend_labs_comb,cc)
%     load(sprintf('%s.mat',prefix),'ex')
%     plotHKS(ex,sprintf('%s_HKS_projfree.pdf',prefix),iprojfree,immdpoly,iolr,iks,legend_labs_projfree)
%     plotHKS(ex,sprintf('%s_HKS_proj.pdf',prefix),iproj,immdpoly,iolr,iks,legend_labs_proj)
%     plotHKS(ex,sprintf('%s_HKS_%s.pdf',prefix,suff),ihksall,immdpoly,iolr,iks,legend_labs_comb)
%     plotKSOthers(ex,sprintf('%s_benchmark_projfree.pdf',prefix),iprojfree,immdpoly,iks,ienergy,immd,iad,iolr,mmdpolydeg,1:numel(iprojfree),cc)
%     plotKSOthers(ex,sprintf('%s_benchmark_proj.pdf',prefix),iproj,immdpoly,iks,ienergy,immd,iad,iolr,mmdpolydeg,1:numel(iproj),cc)
%     plotKSOthers(ex,sprintf('%s_benchmark_%s.pdf',prefix,suff),ihksall,immdpoly,iks,ienergy,immd,iad,iolr,mmdpolydeg,hksalldeg,cc)
% end
