% function y = gen_unif_bump1(h,m,n)
%    
%     x = sort(rand(m,n));
%     
%     y = (x<=.25+h/8) .* (-1+sqrt(1+8*h*x))./(4*h) + ...
%         (.25+h/8 < x & x<=.75+h/8) .* (.5+1/(4*h) - sqrt(1+4*h*(1-2*x)+2*h*h)./(4*h)) + ...
%         (.75+h/8 < x) .* (1-1/(4*h) + sqrt(1-8*h + 8*h*x)./(4*h));
% 
% end


function y = gen_unif_bump12(r,b,m,n)
    % pdf f
    % [0,r] -> 1
    % (r,r+b] -> 1 + isosceles triangle of height 1, base b
    % (r+b,r+2b] -> 1 - isosceles triangle of height 1, base b
    % (r+2b,1] -> 1
    
    x = rand(m,n);
    % y = F^{-1}(x), F is cdf
    % x <= r -> y=x
    % x in (r,r+1.5b] -> y=r + (x-r)/1.5
    % (r+1.5b,r+2b] -> y=r + b + (x-r)/0.5
    % (r+2b,1] -> y = x
    
    
    y = sort((x<=r | x>r+2*b) .*x + ...
        (r<x & x<=r+0.75*b) .* (r+ (sqrt(b^2+ 4*b*(x-r)) - b)/2) + ...
        (r+0.75*b<x & x<=r+1.5*b) .* (r+b - (sqrt(b^2+ 4*b*((r+1.5*b)-x)) - b)/2) + ...
        (r+1.5*b<x & x<=r+1.75*b) .* (r+b + (-sqrt(b^2 - 4*b*(x-(r+1.5*b))) + b)/2) + ...
        (r+1.75*b<x & x<=r+2*b) .* (r+2*b - (-sqrt(b^2 - 4*b*((r+2*b)-x)) + b)/2));
    
end
