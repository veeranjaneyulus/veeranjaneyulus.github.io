function [y] = gen_unif_tail_bump0(b,h,m,n)
%GEN_UNIF_TAIL_BUMP0 Bumps on tails of uniform(-1,1)
    % pdf f
    % [-1,-1+b] -> 0.5-h
    % (-1+b,1-b] -> 0.5
    % (1-b,1] -> 0.5+h
    
    x = rand(m,n);
    % y = F^{-1}(x), F is cdf
    % x <= (0.5-h)b -> y= x/(0.5-h) -1
    % x in ((0.5-h)b,1-(0.5+h)b] -> y=2x-1+bh
    % x > 1-(0.5+h)b -> y = (x-1)/(0.5+h) + 1
    
    y = sort((x<=(0.5-h)*b) .* (x./(.5-h)-1) + ...
        ((.5-h)*b < x & x<=1-(.5+h)*b) .* (2*x-1+b*h) + ...
        (1-(.5+h)*b < x) .* ((x-1)/(.5+h) + 1));
end

