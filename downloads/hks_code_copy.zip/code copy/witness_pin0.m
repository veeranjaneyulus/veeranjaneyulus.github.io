
% k=0,1,2
% plot a few potential witness functions
ks = [0,1,2];

x = linspace(-3,3,100);
knots = [1.5,3/4,0];
bump = 0;
    
cc = distinguishable_colors(numel(knots));
cc = flip(cc);
for ik=1:numel(ks)
    
    k = ks(ik);
    
    for left = [false, true]
        figure
        for iknot=1:numel(knots)
            if (k>0)
                if (left) 
                    plot(x, bump*iknot+max(0,-knots(iknot)-x).^k /factorial(k), 'LineWidth', 2, 'Color',cc(iknot,:)); hold on
                else
                    plot(x, bump*iknot+ max(0,x-knots(iknot)).^k /factorial(k), 'LineWidth', 2,'Color',cc(iknot,:)); hold on;
                end
            else
                if (left) 
                    plot(x, bump*iknot + x<=-knots(iknot), 'LineWidth', 2, 'Color',cc(iknot,:)); hold on
                else
                    plot(x, bump*iknot + x>=knots(iknot), 'LineWidth', 2,'Color',cc(iknot,:)); hold on;
                end
                    
            end
        end
        set(gca,'FontSize',16)
        ylim(ylim*1.1)
        title(sprintf('k=%d',k),'FontSize',20)
        saveTightFig(gcf,sprintf('NewPlots2/witness_pin0_k%d_left%d.pdf',k,left))
    end
end


%% Illustration for univariate piecewise polynomial optimization


k=1;

cc = lines(3);
knots = (6:-1:2)/3; % reverse order so that the trunc. pow basis funcs are visible where they overlap on x-axis
x = linspace(min(knots),max(knots)+abs(knots(1)-knots(2)),100);

for i=1:numel(knots)-2
    t = knots(i);
    plot(x, max(0,x-t).^k /factorial(k), 'LineWidth', 2,'Color',cc(2,:)); hold on;
end
plot(x, max(0,x-knots(end-1)).^k /factorial(k), ':','LineWidth', 2,'Color',.5*[1 1 1]); hold on;
plot([min(x),max(x)],[0,0],'k--','LineWidth', 2)
set(gca,'FontSize',24)
ax=gca;
ax.YAxis.Visible = 'off';
ax.XAxis.Visible = 'off';

% ax.TickLabelInterpreter='latex';
z1=knots(end-1);z2=knots(end-2); t = (z1+z2)/2;
text(z1,-0.2,'$z_{i}$','FontSize',40,'Interpreter','latex')
text(z2,-0.2,'$z_{i+1}$','FontSize',40,'Interpreter','latex')
text(t,-0.2,'$t$','FontSize',40,'Interpreter','latex','Color','r')
stairs([z1,z1],[-0.1,0.1],'LineWidth',2,'Color','k')
stairs([t,t],[-0.1,0.1],'LineWidth',2,'Color','k')
stairs([z2,z2],[-0.1,0.1],'LineWidth',2,'Color','k')

knotdiff=knots(1)-knots(2);
xlim([min(x), max(x)])

saveTightFig(gcf,'NewPlots2/phi_piecewise_poly.pdf')

