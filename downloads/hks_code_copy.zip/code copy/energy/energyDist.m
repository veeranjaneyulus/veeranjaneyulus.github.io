function [teststat] = energyDist(X,Y)

m = size(X,1);
n = size(Y,1);
teststat = 2*sum(sum(pdist2(X,Y))) / (m*n) - sum(sum(pdist2(X,X)))/(m*m) -...
    sum(sum(pdist2(Y,Y)))/(n*n);

end

