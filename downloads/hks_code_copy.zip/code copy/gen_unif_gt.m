function y = gen_unif_gt(r,b,m,n)
% pdf: 1 on [0,r], 
%     (1+b(t-r))^2 on (r,r+c] 
% where c is chosen so that the pdf integrates to 1

% sampling x ~ uniform(0,1), find y = F^{-1}(x)
% x <= r : y = x
% x > r : y = r +  1/b * [{1 + 3b(u-r)}^1/3 - 1]

    x = rand(m,n);

    if(b==0)
        y = x;
    else
        y = sort((x<=r) .* x + ...
            (x>r) .* (r + ( (1+(3*b).*(x-r)).^(1/3)  -1)./b));
    end
end
