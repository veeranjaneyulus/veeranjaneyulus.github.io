%This function implements the MMD two-sample test using a bootstrap
%approach to compute the test threshold.

% MODIFIED FROM THE ORIGINAL CODE TO OUTPUT ONLY TEST STATISTIC

%Arthur Gretton
%07/12/08

%Inputs: 
%        X contains dx columns, m rows. Each row is an i.i.d sample
%        Y contains dy columns, m rows. Each row is an i.i.d sample
%        alpha is the level of the test
%        sig is kernel size. If -1, use median distance heuristic.
%        params.shuff is number of bootstrap shuffles used to
%                     estimate null CDF
%        params.bootForce: if this is 1, do bootstrap, otherwise
%                     look for previously saved threshold


%Outputs: 
%        thresh: test threshold for level alpha test
%        testStat: test statistic: m * MMD_b (biased)



function [testStat,witness] = mmdTestBootStats(X,Y,sig)

    
m=size(X,1);



%Set kernel size to median distance between points in aggregate sample
if sig == -1
  sig = medianBandwidth(X,Y);
end


K = rbf_dot(X,X,sig);
L = rbf_dot(Y,Y,sig);
KL = rbf_dot(X,Y,sig);


%MMD statistic. Here we use biased 
%v-statistic. NOTE: this is m * MMD_b
testStat = 1/m * sum(sum(K + L - KL - KL'));


if nargout >= 2
    % f(t) = 1/m \sum_{i=1}^m  k(x_i, t) -   1/n \sum_{i=1}^n  k(y_i, t)
    % evaluated at Z
    witness = [mean(K)' - mean(KL,2); mean(KL)'-mean(L)'];
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%