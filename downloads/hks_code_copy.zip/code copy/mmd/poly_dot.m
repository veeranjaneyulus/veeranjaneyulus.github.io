function [K] = poly_dot(X,Y,d)
%POLY_DOT Polynomial kernel inner product of degree d
%   X: mxk, Y: nxk

K = (X*Y' + 1).^d;

end

