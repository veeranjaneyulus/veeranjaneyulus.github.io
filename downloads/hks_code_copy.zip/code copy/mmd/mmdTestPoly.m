function [testStat,witness] = mmdTestPoly(X,Y,d)
%MMDTESTPOLY Summary of this function goes here
%   Detailed explanation goes here

    

m=size(X,1);
n=size(Y,1);

% Fast implementation
coeffs = zeros(d+1,1);
testStat = 0;
for j=0:d
   coeffs(j+1) = mean(X.^j)-mean(Y.^j);
   testStat = testStat + nchoosek(d,j) * coeffs(j+1)^2;
end

if nargout >= 2
    % f(t) = 1/m \sum_{i=1}^m  k(x_i, t) -   1/n \sum_{i=1}^n  k(y_i, t)
    % evaluated at Z
    Z = [X(:);Y(:)];
    witness = zeros(numel(Z),1);
    for j=0:d
        witness = (nchoosek(d,j)* coeffs(j+1)) .* (Z.^(d-j));
    end
    
end



% K = poly_dot(X,X,d);
% L = poly_dot(Y,Y,d);
% KL = poly_dot(X,Y,d);
% 
% 
% %MMD statistic. Here we use biased 
% %v-statistic. NOTE: this is m * MMD_b
% testStat = 1/m * sum(sum(K + L - KL - KL'));
% 
% 
% if nargout >= 2
%     % f(t) = 1/m \sum_{i=1}^m  k(x_i, t) -   1/n \sum_{i=1}^n  k(y_i, t)
%     % evaluated at Z
%     witness = [mean(K)' - mean(KL,2); mean(KL)'-mean(L)'];
%     
% end




end

