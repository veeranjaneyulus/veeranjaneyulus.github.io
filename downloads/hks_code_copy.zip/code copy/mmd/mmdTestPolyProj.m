function [teststat,witness] = mmdTestPolyProj(X,Y,d,k)
%MMDTESTPOLYPROJ MMD test with polynomial kernel of degree d with
%polynomial projections
%   Project out kth degree polynomials from RKHS functions

if nargin<=3
    k=d-1;
end

m = size(X,1);
theta = [ones(m,1);-ones(m,1)]./m;

Z = [X;Y];
theta_res = theta - polynomialproj(Z,k,theta); % Z has only one column

K = poly_dot(Z,Z,d); % for smallish m

teststat = theta_res' * K * theta_res;


if nargout >= 2
    % f(t) = 1/m \sum_{i=1}^m  k(x_i, t) -   1/n \sum_{i=1}^n  k(y_i, t)
    % evaluated at Z
    % and then \Pi_k^\perp f(Z)
    witness = K*theta_res;
    
end
end


