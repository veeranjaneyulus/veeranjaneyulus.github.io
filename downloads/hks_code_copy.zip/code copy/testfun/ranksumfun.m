function stat = ranksumfun(x,y)
    %wilcoxon test
    [p,h,rs] = ranksum(x,y);
    stat = -rs.ranksum;
end

