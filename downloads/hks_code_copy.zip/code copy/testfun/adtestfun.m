function stat = adtestfun(x,y)
    %AD-test
    stat = ADtestk([[x, ones(size(x))];[y, 2*ones(size(y))]]);
end

