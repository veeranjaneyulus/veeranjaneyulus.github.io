function stat = kuipertestfun(x,y)
    [h,p,statplus] = kstest2(x,y,'tail','smaller');
    [h,p,statminus] = kstest2(x,y,'tail','larger');
    stat = statplus + statminus;
end

