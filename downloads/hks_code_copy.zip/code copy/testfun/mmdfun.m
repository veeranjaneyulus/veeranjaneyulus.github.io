function stat = mmdfun(x,y)
    %alex's mmd 

    stat = mmdTestBootStats(x,y,-1);

end

