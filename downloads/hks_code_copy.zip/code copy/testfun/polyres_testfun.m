function [stat] = polyres_testfun(testfunc,k,x,y)
%POLYRES_TESTFUN testfunc on the ortho complement of poly-projection
%   Detailed explanation goes here

n1=length(x);
n2=length(y);

[z,idxx,idxy]=merge_sort_idx(x,y);
sz=length(z);
% map it to [-1,1]
zz=(z-min(z))/(max(z)-min(z)); zz=zz*2-1;

% Construct chebychev basis
A(:,1) = ones(sz,1);
if k >= 1
    A(:,2) = zz;
end
if k >= 2
    for i = 3:k+1
        A(:,i) = 2*zz.*A(:,i-1) - A(:,i-2);  %% recurrence relation
    end
end

%fit polynomial
theta=(double(idxx)/n1-double(idxy)/n2);
[U S V]=svd(A,'econ');
res=theta-U*(U'*theta);

stat = feval(testfunc,res(idxx),res(idxy));

end

