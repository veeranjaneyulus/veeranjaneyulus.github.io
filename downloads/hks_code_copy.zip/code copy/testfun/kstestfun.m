function stat = kstestfun(x,y)
    [h,p,stat] = kstest2(x,y);
end

