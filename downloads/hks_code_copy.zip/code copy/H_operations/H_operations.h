void H_times(double* y, double* x, int n, int k);
void invH_times(double* y, double* x, int n, int k);
void HT_times(double* y, double* x, int n, int k);
void invHT_times(double* y, double* x, int n, int k);