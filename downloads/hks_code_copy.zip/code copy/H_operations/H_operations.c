 
void cum_sum( double*, int);
void rev_cum_sum( double*, int);
void pair_diff(double*, int);
void rev_pair_diff(double*, int);

void H_times(double* y, double* x, int n, int k){
    int iter,i,j; 
    for(iter=0;iter<k+1;iter++){
         i=k-iter;
         cum_sum(y+i,n-i);
         if(i){
             for(j=i;j<n;j++){
                 y[j]=(x[j]-x[j-i])*(y[j]);
             }            
         }              
     }
 }


void invH_times(double* y, double* x, int n, int k){
    int i,j;
    for(i=0;i<k+1;i++){
         if(i){
             for(j=i;j<n;j++){
                 y[j]=(y[j])/(x[j]-x[j-i]);
             }            
         }
         pair_diff(y+i,n-i);
     }
 }

void HT_times(double* y, double* x, int n, int k){
    int i,j;
    for(i=0;i<k+1;i++){
         if(i){
             for(j=i;j<n;j++){
                 y[j]=(y[j])*(x[j]-x[j-i]);
             }            
         }
         rev_cum_sum(y+i,n-i);
     }
 }
 
void invHT_times(double* y, double* x, int n, int k){
    int iter,i,j;
    for(iter=0;iter<k+1;iter++){
        i=k-iter;
        rev_pair_diff(y+i,n-i);
         if(i){
             for(j=i;j<n;j++){
                 y[j]=(y[j])/(x[j]-x[j-i]);
             }            
         }
     }
 }

//subroutines
void cum_sum( double* y, int n){
    int i;
for(i=1;i<n;i++){
    y[i]+=y[i-1];
}
return;
}

void rev_cum_sum( double* y, int n){
    int i;
for(i=n-2;i>-1;i--){
    y[i]+=y[i+1];
}
return;
}

void pair_diff(double* y, int n){
//compute pair difference inplace, update entries with index 2 to n    
int i;
    for(i=0;i<n-1;i++){
    y[n-1-i]-=y[n-i-2];
}
return;
}

void rev_pair_diff(double* y, int n){
//compute pair difference inplace, update entries with index 2 to n    
int i;
    for(i=0;i<n-1;i++){
    y[i]-=y[i+1];
}
return;
}