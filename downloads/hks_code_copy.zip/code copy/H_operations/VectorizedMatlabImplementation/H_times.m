function [ z ] = H_times( x,y,k )
%H_times fast left multiplication with H
%   
n=length(x);
for iter=0:k
    i=k-iter;
    y(i+1:n)=cumsum(y(i+1:n));
    if i
        y(i+1:n)=(x(i+1:n)-x(1:n-i)).*y(i+1:n);
%        y(i+1:n)=(x(i+1:n)-x(1:n-i)).*y(i+1:n)/i;
    end
end

z=y;
end
