function [ z ] = invH_times( x,y,k )
%invH_times fast left multiplication with inv(H)
%   
n=length(x);
for i=0:k
    if i~=0
        y(i+1:n)=1./(x(i+1:n)-x(1:n-i)).*y(i+1:n);
    end
    y(i+1:n) = [y(i+1); diff( y(i+1:n))];

end

z=y;
end
