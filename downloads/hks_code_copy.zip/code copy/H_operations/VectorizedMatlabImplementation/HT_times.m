function [ z ] = HT_times( x,y,k )
%HT_times fast left multiplication with H^T
%   
n=length(x);
for i=0:k
    if i
        y(i+1:n)=(x(i+1:n)-x(1:n-i)).*y(i+1:n);
    end
    y(i+1:n) = wrev( cumsum( wrev( y(i+1:n))));
end

z=y;
end

