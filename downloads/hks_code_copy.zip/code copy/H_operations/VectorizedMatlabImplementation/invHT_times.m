function [ z ] = invHT_times( x,y,k )
%invH_times fast left multiplication with inv(H)
%   
n=length(x);
for iter=0:k
    i=k-iter;
    y(i+1:n) = [wrev(diff( wrev(y(i+1:n))));y(n)];
    if i~=0
        y(i+1:n)=1./(x(i+1:n)-x(1:n-i)).*y(i+1:n);
    end
end

z=y;
end
