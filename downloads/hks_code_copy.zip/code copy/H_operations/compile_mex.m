% compile mex

mex H_operations.c H_times.c
mex H_operations.c  invHT_times.c
mex H_operations.c HT_times.c
mex H_operations.c invH_times.c