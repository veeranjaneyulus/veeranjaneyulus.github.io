function [ logL ] = std_normal_logL( x )
%std_normal_logL compute the loglikelihood of std normal
%   x gives a vector of observations
%   logL is the log-likelihood assuming they are generated from the normal
%   distrubtion

%constant term is ignored.
logL=sum(-x.^2);


end

