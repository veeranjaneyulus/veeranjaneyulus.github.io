%% Plot the distribution


pd1=makedist('Normal');

pd2 = makedist('tLocationScale','nu',5);
x=-4:.1:4;

pdf1 = pdf(pd1,x);
pdf2 = pdf(pd2,x);
plot(x,pdf1,...
    x,pdf2,'LineWidth',2)
lh=legend('N(0,1)','t(0,1,\nu=5)');
set(lh,'fontsize',14)
set(gca,'Position',[.05 .05 .9 .93])

%%


pd1=makedist('Normal');

pd2 = makedist('Normal','mu',0.3);
x=-4:.1:4;

pdf1 = pdf(pd1,x);
pdf2 = pdf(pd2,x);
plot(x,pdf1,...
    x,pdf2,'LineWidth',2)
lh=legend('N(0,1)','N(0.3,1)');
set(lh,'fontsize',14)
set(gca,'Position',[.05 .05 .9 .93])

%% For Laplace vs. Laplace experiment


% pd1=makedist('Normal');
% 
% pd2 = makedist('Normal','mu',0.3);
x=-4:.1:4;

pdf1=0.5*exp(-abs(x));
pdf2=0.5*exp(-abs(x-0.3));

% pdf1 = pdf(pd1,x);
% pdf2 = pdf(pd2,x);
plot(x,pdf1,...
    x,pdf2,'LineWidth',2)
lh=legend('N(0,1)','N(0.3,1)');
set(lh,'fontsize',14)
set(gca,'Position',[.05 .05 .9 .93])