function [out] = cdfrnd(F,varargin)
%QUANTILERND Generates random numbers for a quantile function
%   
 % F is cdf
 q = @(x) fzero(@(t) F(t)-x, x);
   
 out = arrayfun(q, unifrnd(0,1,varargin{:}));

end

