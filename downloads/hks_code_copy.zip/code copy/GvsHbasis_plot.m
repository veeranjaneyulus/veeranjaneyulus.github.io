
n=40;
x = linspace(0,1,n)';
k = 2;

G = gen_trunc_pow_basis(x,k);
H = gen_fallingfactobasis(x,k);

is = round([k+2, n/3, 2*n/3]);


figure
plot(x,G(:,is(1)),'r-',x,H(:,is(1)),'r:','linewidth',2); hold on
plot(x,G(:,is(2)),'b-',x,H(:,is(2)),'b:','linewidth',2); hold on
plot(x,G(:,is(3)),'c-',x,H(:,is(3)),'c:','linewidth',2); hold on

% legend positions
y1=.9; y2=.83; % y's for the two names
x1=.05; x2=.1; x3=.12; % lines from x1 to x2 and text starts at x3
plot([x1,x2],[y1,y1],'k','linewidth',2)
text(x3,y1,'Truncated power basis cols($G$)','Interpreter','latex','FontSize',20)
hold on
plot([x1,x2],[y2,y2],'k:','linewidth',2)
text(x3,y2,'Falling factorial basis cols($H$)','Interpreter','latex','FontSize',20)
saveTightFig(gcf,'GHbasis.pdf')
hold off