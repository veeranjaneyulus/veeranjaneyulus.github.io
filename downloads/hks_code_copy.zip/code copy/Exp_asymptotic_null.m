% QQ plots for Higer-order KS statistic vs. asymptotic goodness-of-fit null
% requires export_fig for append_pdfs

rng(0)
m=2000;n=2000;
nsimgp=1000; %1000
nsimtest=1000; %1000;

runsim=false;
tic

%% 
nQ = 3;
Q_list = cell(nQ,1);

Q.pd = makedist('Normal');
Q.xmin = -Inf;
Q.xmax = Inf;
Q_list{1} = Q;
Q.xmin = 0;
Q.xmax = 1;
Q.pd = makedist('Uniform');
Q_list{2} = Q;
Q.pd = makedist('beta',1,2); %careful with this..
Q.xmin = 0;
Q.xmax = 1;
Q_list{3} = Q;

prefix='NewPlots2/nulldist_norm';
kk=0:3;
nk = numel(kk);
%%
if runsim
T_n = zeros(nsimgp,nQ,nk);
T_ts = zeros(nsimtest,nQ,nk); % two-sample

% Asymptotic null
for ik=1:numel(kk)
    k=kk(ik);
    if k==0
        nquantiles=1000;
    else
        nquantiles=100;
    end
    parfor i=1:nQ
        qles = linspace(0,1,nquantiles);
        T_n(:,i,ik) = HKS_null(Q_list{i},qles,k,nsimgp,mean(Q_list{i}.pd));
        
        % normalize Q to have mean=0, variance=1
        T_n(:,i,ik) = Q_list{i}.pd.std^(-k) .* T_n(:,i,ik);
    end
end

% Two-sample null stats
for i=1:nQ	
    for j=1:nsimtest
        Q = Q_list{i};
        
        % normalize Q to have mean=0, variance=1
        x = sort((random(Q.pd,[m,1])-Q.pd.mean)./Q.pd.std);
        y = sort((random(Q.pd,[n,1])-Q.pd.mean)./ Q.pd.std);
        parfor ik=1:numel(kk)
            T_ts(j,i,ik) = HKS_projfree_test(x,y,kk(ik));
        end
    end
end

save(sprintf('%s.mat',prefix), 'T_n', 'T_ts', 'Q_list')
end
%%

load(sprintf('%s.mat',prefix))
dist_names = {'Normal', 'Uniform', 'Beta'};


for ik=1:numel(kk)
    k=kk(ik);
    figure('pos',[10,10,1000,500])
    % QQ plots in an array  
    for i=1:nQ
        % Two sample test statistic vs. null
        subplot(2,nQ,i)
        qqplot(T_n(:,i,ik), T_ts(:,i,ik))
        title(dist_names{i}, 'fontsize', 12)
        if(i==1)
            xlabel('Null quantiles', 'fontsize', 12);
            ylabel('Test stat quantiles', 'fontsize', 12);
        else
            xlabel('')
            ylabel('')
        end
    end

    % Density plots
    for i=1:nQ
        
        subplot(2,nQ,i+nQ)
        [f,xi]=ksdensity(T_n(:,i,ik));
        plot(xi,f,'linewidth',2); hold on
        [f,xi]=ksdensity(T_ts(:,i,ik));
        plot(xi,f,'linewidth',2);
        title(dist_names{i}, 'fontsize', 12)
        if(i==1)
            xlabel('', 'fontsize', 12);
            ylabel('Density', 'fontsize', 12);
        else
            xlabel('')
            ylabel('')
        end
    end

    saveTightFig(gcf, sprintf('%s_k%d_normal_uniform.pdf',prefix,k))
end

%% Separate QQ plots
for ik=1:numel(kk)
    k=kk(ik);
    for i=1:nQ
        figure
        qqplot(T_n(:,i,ik), T_ts(:,i,ik)); 
        title(sprintf('%s k=%d',dist_names{i},k), 'fontsize', 30)
        xlabel('Null quantiles', 'fontsize', 30)
        ylabel('Test stat quantiles', 'fontsize', 30)
        set(gca, 'FontSize', 24)

        filename = sprintf('%s_k%d_%s_qq.pdf',prefix,k,dist_names{i});
        saveTightFig(gcf, filename)
    end
end
	
clear cc
cc.asymp=[0,0,1];
cc.ts = [1,0,0];

%% Separate density plots
for ik=1:numel(kk)
    k=kk(ik);

    for i=1:nQ
        figure
        [f,xi]=ksdensity(T_n(:,i,ik));
        plot(xi,f,'linewidth',2,'color',cc.asymp); hold on
        [f,xi]=ksdensity(T_ts(:,i,ik));
        plot(xi,f,'linewidth',2,'color',cc.ts);
        title(sprintf('%s k=%d',dist_names{i},k), 'fontsize', 30)
        lg=legend('Asymptotic', 'Finite-sample');
        set(lg,'FontSize',24,'Location','best')
        set(gca, 'FontSize', 24)

        filename = sprintf('%s_k%d_%s_density.pdf',prefix,k,dist_names{i});
        saveTightFig(gcf, filename)
        hold off
    end
end

%% Separate overlapping histograms

xlow=min(min(T_n(:)), min(T_ts(:)));
xhi=max(max(T_n(:)), max(T_ts(:)));
nbins=30;
maxfreq=0;
for ik=1:numel(kk)
    for i=1:nQ
        [nn,edges]=histcounts(T_n(:,i,ik),nbins);
        maxfreq=max(maxfreq, max(nn));
        nn2=histcounts(T_ts(:,i,ik),nbins,'BinEdges',edges);
        maxfreq=max(maxfreq, max(nn2));
    end
end

for ik=1:numel(kk)
    k=kk(ik);
    for i=1:nQ
        figure
        h=histogram(T_n(:,i,ik),nbins,'EdgeAlpha',0.3,'FaceColor',cc.asymp); hold on
        histogram(T_ts(:,i,ik),'BinEdges',h.BinEdges,'EdgeAlpha',0.3,'FaceColor',cc.ts,'FaceAlpha',0.3)
        xlim([0.9*xlow, xhi])
        ylim([0,maxfreq*1.02])
        lg=legend('Asymptotic', 'Finite-sample');
        set(lg,'FontSize',24,'Location','best')
        title(sprintf('%s k=%d',dist_names{i},k), 'fontsize', 30)
        set(gca, 'FontSize', 24)

        filename = sprintf('%s_k%d_%s_hist.pdf',prefix,k,dist_names{i});
        saveTightFig(gcf, filename)
        hold off
    end
end


%% KS test for null distribution matching
nk=numel(kk);
stats = zeros(nQ,nk);
pval = zeros(nQ,nk);
for i=1:nQ
    for ik=1:numel(kk)
        [~,pval(i,ik),stats(i,ik)] = kstest2(T_n(:,i,ik), T_ts(:,i,ik)); 
    end
end

pval
% print pval for latex
for i=1:size(pval,1)
    fprintf('%s  &',dist_names{i})
    fprintf('  %.2f', pval(i,1));
    fprintf('  &  %.2f', pval(i,2:end));
    fprintf('\\\\\n')
end
stats_Tn = zeros(nQ*nk,nQ*nk);
pval_Tn = zeros(nQ*nk,nQ*nk);

for i1=1:nQ
    for i2=1:nQ
        for ik1=1:nk
            for ik2=1:nk
                [~,p,st] = kstest2(T_n(:,i1,ik1),T_n(:,i2,ik2));
                stats_Tn( (ik1-1)*nQ+i1, (ik2-1)*nQ+i2) = st;
                pval_Tn( (ik1-1)*nQ+i1, (ik2-1)*nQ+i2) = p;
            end
        end
    end
end

save(sprintf('%s_matching.mat',prefix),'pval','stats', 'pval_Tn', 'stats_Tn')

