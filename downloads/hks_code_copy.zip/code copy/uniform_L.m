function [ L ] = uniform_L( x, a,b )
%std_normal_L compute the likelihood of uniform[a,b]
%   x gives a vector of observations
%   L is the likelihood assuming they are generated from unif[a,b]

%constant term is ignored.
L=prod((x>a).*(x<b));


end