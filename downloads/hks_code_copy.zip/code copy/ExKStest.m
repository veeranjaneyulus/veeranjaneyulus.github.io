function [H, pValue, KSstatistic, criticalValue]= ExKStest(x, k,varargin)
%ExKStest perform extended KS test
%   x  is the observation vector
%   k  is the order of the KS test
%       Parameter       Value
%       'alpha'         A value ALPHA between 0 and 1 specifying the
%                       significance level. Default is 0.05 for 5% significance.
%       'CDF'           CDF is the c.d.f. under the null hypothesis.  It can
%                       be specified either as a ProbabilityDistribution object
%                       or as a two-column matrix. Default is the standard
%                       normal, N(0,1).
%       'Type'          A string indicating the type of test. The one-sample
%                       K-S test tests the null hypothesis that F(x) = CDF
%                       for all x against the alternative specified by TYPE:
%            'unequal' -- "F(x) not equal to CDF" (two-sided test) (Default)
%            'larger'  -- "F(x) > CDF" (one-sided test)
%            'smaller' -- "F(x) < CDF" (one-sided test)


% as in matlab toolbox version of ks-test, CDF is indicated by a
% ProbabilityDistribution object, or a two-column matrix.

end

