function [ test_stat ] = pKS_goodness_of_fit( Q, T, k, xx )
%PKS_PARTIAL_MOMENT Summary of this function goes here
%   Detailed explanation goes here

[n, nsample] = size(xx);
if n==1 % row vector
	xx = xx';
	[n, nsample] = size(xx);
end

nt = numel(T);

if (k==1) % works only for k=1
	for i=1:nt	
		t = T(i);
		nu(i,1) = integral( @(x) (x-t).* Q.pdf(x), t, Q.xmax);
		nu(i,2) = integral( @(x) x.*(x-t).* Q.pdf(x), t, Q.xmax);
	end

	% a(i,:) are the coeffs of the polynomial Pi_Q (x-t)_+^k 
	a = zeros(nt,k+1);
	v = Q.mu(2) - Q.mu(1)^2;
	a(:,1) = (nu(:,2) - nu(:,1) * Q.mu(1)) ./ v;
	a(:,2) = (nu(:,1) * Q.mu(2) - nu(:,2) * Q.mu(1)) ./ v;
end

T = T(:);
test_stat = zeros(nsample,1);
for i=1:nsample
	x = xx(:,i);
	% \mean_x \Pi_{k,Q}^\perp (x-t)_+^k  for t in T
	%   = \mean_x (x-t)_+^k - a_t(1) x^k - a_t(2) x^{k-1} -.. for t in T
	errs = abs(mean(max(x-T', 0) - x * a(:,1)')' - a(:,2));
	test_stat(i) = max(errs);
end

test_stat = test_stat .* sqrt(n);

end

