function [tKS,witness] = KSproj(x,y,k)
%KS_PROJ Kolmogorov-Smirnov test on projected data 
%	KS on x,y after polynomials on x \cup y of degree k are projected out
%   x,y are assumed to be sorted in increasing order

n1=length(x);
n2=length(y);

[z,idxx,idxy]=merge_sort_idx(x,y);
theta=(double(idxx)/n1-double(idxy)/n2);

% sup_t < \Pi_k^\perp g_t, theta> = sup_t < g_t, \Pi_k^\perp theta>
res=theta-polynomialproj(z,k,theta);  % \Pi_k^\perp theta
[val,imax]=max(abs(cumsum(res)));
tKS = sqrt(n1*n2/(n1+n2)) * val;
witness = polynomialproj(z,k,[ones(imax,1); zeros(numel(z)-imax,1)]);

end

