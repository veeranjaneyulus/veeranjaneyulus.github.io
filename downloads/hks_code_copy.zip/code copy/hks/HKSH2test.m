function stat = HKSH2test(x,y,k)

    [z,idxx,idxy]=merge_sort_idx(x,y);
    sz=length(z);
    vv=HT_times(z,double(idxx)-double(idxy),k);
    stat=max(abs(vv(k+2:sz))) / factorial(k);
    
end

