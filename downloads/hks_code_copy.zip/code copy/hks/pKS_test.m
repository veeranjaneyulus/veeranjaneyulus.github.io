function [ tKS, tpoly, witness1, witness2 ] = pKS_test(x,y,k,useG)
%pKS_test Summary of this function goes here
%   x,y are assumed to be sorted
% degree k

n1=length(x);
n2=length(y);

[z,idxx,idxy]=merge_sort_idx(x,y);
sz=length(z);
% map it to [-1,1]
zz=(z-min(z))/(max(z)-min(z)); zz=zz*2-1;

% Construct chebychev basis
A(:,1) = ones(sz,1);
if k >= 1
    A(:,2) = zz;
end
if k >= 2
    for i = 3:k+1
        A(:,i) = 2*zz.*A(:,i-1) - A(:,i-2);  %% recurrence relation
    end
end

%fit polynomial
theta=(double(idxx)/n1-double(idxy)/n2);
[U S V]=svd(A,'econ');
res=theta-U*(U'*theta);
witness2 = theta-res;
tpoly = sqrt(n1*n2/(n1+n2)) * norm(U'*theta);

if nargin >= 4 && useG
    G = gen_trunc_pow_basis( z,k );
    vv= G'*res;
    [val,imax] = max(abs(vv(k+2:sz)));
    tKS= sqrt(n1*n2/(n1+n2)) * val / factorial(k);
    witness_g = G(:,k+1+imax);
    witness1 = witness_g - U*(U'*witness_g); % \Pi_{k,N}^\perp h
else
    vv=HT_times(z,res,k);
    [val,imax] = max(abs(vv(k+2:sz)));
    tKS= sqrt(n1*n2/(n1+n2)) * val / factorial(k);
    eimax = zeros(sz,1); eimax(k+1+imax)=1;
    witness_h = H_times(z,eimax,k);
    witness1 = witness_h - U*(U'*witness_h); % \Pi_{k,N}^\perp h

end



end

