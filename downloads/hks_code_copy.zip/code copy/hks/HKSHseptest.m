function stat = HKSHseptest(x,y,k,w)
%HKSHSEPTEST Summary of this function goes here
%   Detailed explanation goes here

[tperp,tpoly] = pKS_test(x,y,k);
stat = (1-w)*tperp + w*tpoly;

end

