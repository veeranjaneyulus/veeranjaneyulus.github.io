function stat = cdfHtest(x,y,k)

    m = numel(x);
    n = numel(y);
    
    x = sort(x(:));
    y = sort(y(:));
    
    % z = empirical cdf of x evaluated at y
    z = sum(x <= y')./m;
    
    % test uniformity of z.. 
    % use a one-sample test.. not this
    stat = pKS_test(z,(1:n)'/n,k);
    
    
end

