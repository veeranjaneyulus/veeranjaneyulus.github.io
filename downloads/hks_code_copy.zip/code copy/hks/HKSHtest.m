function stat = HKSHtest(x,y,k)

    [z,idxx,idxy]=merge_sort_idx(x,y);
    vv=HT_times(z,double(idxx)-double(idxy),k);
    stat=max(abs(vv)) / factorial(k);
    
end

