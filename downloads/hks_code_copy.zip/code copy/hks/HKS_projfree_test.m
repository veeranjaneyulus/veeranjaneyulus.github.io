function [ tKS, tpoly, witness1, witness2 ] = HKS_projfree_test(x,y,k,polyproj,center)
%HKS_projfree_test Projection-free HKS test
%   x,y are assumed to be sorted
% degree k
% uses truncated power basis functions

n1=length(x);
n2=length(y);

if nargin<4
    polyproj=false;
end
if nargin<5
    center=true;
end


[z,idxx,idxy]=merge_sort_idx(x,y);
sz=length(z);
% Split z into two parts around mean(z) and find sup_t P_m g_t - Q_n g_t 
% on the two parts separately
if center
    mu = mean(z);
    z = z-mu;
end

idx0 = find(z>=0,1,'first');
if isempty(idx0) % zs are all <0
    idx0=sz+1;
end

% % all z are equal
% if idx0==1 || idx0==numel(z) 
%     tKS=0;
%     witness1 = zeros(numel(z),1);
%     return;
% end

% map z to [-1,1]
zz=(z-min(z))/(max(z)-min(z)); zz=zz*2-1;

% Construct chebychev basis
A(:,1) = ones(sz,1);
if k >= 1
    A(:,2) = zz;
end
if k >= 2
    for i = 3:k+1
        A(:,i) = 2*zz.*A(:,i-1) - A(:,i-2);  %% recurrence relation
    end
end

%fit polynomial
theta=(double(idxx)/n1-double(idxy)/n2);
[U S V]=svd(A,'econ');
res=theta-U*(U'*theta);
witness2 = theta-res;
tpoly = sqrt(n1*n2/(n1+n2)) * norm(U'*theta);

tt = theta;
if polyproj
    tt = res;
end

    
% statistic for positive z and negative z
vp = G2T_times(z(idx0:end),tt(idx0:end),k,0);
vn = flip(G2T_times(flip(z(1:idx0-1)),flip(tt(1:idx0-1)),k,-0));
v = [vn;vp];

[val,imax] = max(abs(v));
tKS= sqrt(n1*n2/(n1+n2)) * val / factorial(k);

if k==0
    witness1 = [zeros(imax,1); ones(n1+n2-imax,1)];
else
    if imax < numel(vn)
        witness1 = max( z(1+imax)-z, 0 ).^k;
    elseif imax == numel(vn)
        witness1 = max(-z, 0).^k;
    elseif imax == numel(vn)+1
        witness1 = max(z, 0).^k;
    else
        witness1 = max(z-z(imax-1), 0 ).^k;
    end
end

if polyproj
    witness1 = witness1 - polynomialproj(z,k,witness1);
end

end

