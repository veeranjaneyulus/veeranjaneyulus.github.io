function [ tKS, witness ] = HKS_allk_test(x,y,k,center)
%HKS_projfree_test Projection-free HKS test
%   x,y are assumed to be sorted
% degree k
% uses truncated power basis functions

if nargin<4
    center=true;
end

n1=length(x);
n2=length(y);

[z,idxx,idxy]=merge_sort_idx(x,y);
sz=length(z);
% map it to [-1,1]
zz=(z-min(z))/(max(z)-min(z)); zz=zz*2-1;

% Construct chebychev basis
A(:,1) = ones(sz,1);
if k >= 1
    A(:,2) = zz;
end
if k >= 2
    for i = 3:k+1
        A(:,i) = 2*zz.*A(:,i-1) - A(:,i-2);  %% recurrence relation
    end
end

%fit polynomial
theta=(double(idxx)/n1-double(idxy)/n2);

% Split z into two parts around mean(z) and find sup_t P_m g_t - Q_n g_t 
% on the two parts separately
mu=0;
if center
    mu = mean(z);
    z = z-mu;
end

idx0 = find(z>=0,1,'first');
if isempty(idx0) % zs are all <0
    idx0=sz+1;
end

% fprintf('HKS_projfree_test 39: %d\n', idx0);
tt = theta;

[~,vp]=G2T_times(z(idx0:end),tt(idx0:end),k,0);
[~,vn]=G2T_times(flip(z(1:idx0-1)),flip(tt(1:idx0-1)),k,0);
vn=flip(vn);
v = [vn;vp];

[val,imaxj] = max(abs(v));

tKSj= sqrt(n1*n2/(n1+n2)) * val;

tKS = 0;
for j=0:k
    tKS = tKS + nchoosek(k,j) * tKSj(j+1)^2;
end

% witness function
[~,jmax] = max(val ./ factorial(0:k)); % jmax = argmax_j T_j 
imax = imaxj(jmax); % imax gives the knot point in the witness for T_j

if imax < numel(vn)
    witness = max( z(1+imax)-z, 0 ).^jmax;
elseif imax == numel(vn)
    witness = max( -z, 0 ).^jmax;
elseif imax == numel(vn)+1
    witness = max( z, 0 ).^jmax;
else
    witness = max(z-z(imax-1), 0 ).^jmax;
end
witness = witness + mu;

end

