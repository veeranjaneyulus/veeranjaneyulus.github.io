%% Conduct Runtime experiment
clear all
clc;

run('D:\Program Files\MATLAB\R2013a\toolbox\Wavelab850\startup.m')

%%

J_list=(4:22)';
nlist= 2.^J_list; %make it diadic length
%nlist=[16,20,50,100,200,500,1000];%,2000,5000,10000,20000, 50000]

num=length(nlist);
k=4;

rep=10;

fftlist=zeros(num,1);
ifftlist=zeros(num,1);

Hlist=zeros(num,1);
invHlist=zeros(num,1);

Glist=zeros(num,1);
invGlist=zeros(num,1);


Wavlist=zeros(num,1);
invWavlist=zeros(num,1);


Blist=zeros(num,1);
invBlist=zeros(num,1);

pause(2);
%%
for j=1:rep
for i=1:num
    n=nlist(i);
    x=(1:n)';
    y=rand(n,1);
    
    % FFT/inverse FFT
    tic;
    z=fft(y);
%     fftlist(i)=fftlist(i)+toc;
%     tic;
    yhat=ifft(z);
    ifftlist(i)=ifftlist(i)+toc;
    
    
    %Wavelet Transform/inverse Wavelet Transform
    tic
    z=FWT_PO(y,1,MakeONFilter('Symmlet',k));
%     Wavlist(i)=Wavlist(i)+toc;    
%     tic
    yhat=IWT_PO(z,1,MakeONFilter('Symmlet',k));
    invWavlist(i)=invWavlist(i)+toc; 

    %H Transform and its inverse
    tic
    z=invH_times( x,y,k );
%     invHlist(i)=invHlist(i)+toce;
%     tic;
    yhat=H_times(x,y,k);
    Hlist(i)=Hlist(i)+toc;
    
    
    %G Transform and its inverse
    if n<=2^13
        opt.LT=true;

        tic;
        G = gen_trunc_pow_basis( x,k );
        G=tril(G);
        
        z=linsolve(G,y,opt);

%         invGlist(i)=invGlist(i)+toc;
%         tic;
%        G = gen_trunc_pow_basis( x,k );
%        G=tril(G);
        yhat=G*z;
        Glist(i)=Glist(i)+toc;
    else
        invGlist(i)=nan;
        Glist(i)=nan;
    end
    %fprintf('Solved for size %d\n',n);
    
    
        %B Transform and its inverse
        %opt.LT=true;
        %B_blk = gen_Bspline_basis(x,k,1 );
        B= gen_Bspline_basis(x,k,0 );
        %B=sparse(B);
        tic;
        %linsolve(B,y,opt);
        z=B\y;

%         invBlist(i)=invBlist(i)+toc;
%         tic;
        yhat=B*z;
        Blist(i)=Blist(i)+toc;

    fprintf('Solved for size %d\n',n);
end
end

fprintf('Done.\n');
    %%
    %semilogx(nlist(2:num),[Wavlist(2:num)./nlist(2:num) invHlist(2:num)./nlist(2:num)])
    figure(1)
    loglog(nlist,fftlist/rep,'.-m',...
    nlist,Wavlist/rep,'x-c',...
    nlist, invHlist/rep,'o--b',...
    nlist, invGlist/rep,'s-.r',...
    nlist,nlist*1e-6,'k-.',...
    nlist,nlist.^2*1e-6,'k:',...
    'linewidth',2);
    lh=legend('FFT','Wavelet','InvH','InvG','1e-6\timesn','1e-6\timesn^2')
    xlim([2^4-1,2^20+1]);
    ylim([10^-5,10])
    xlabel('Length of input vector');
    ylabel('Runtime (in seconds)')
    set(lh,'fontsize',14)
set(gca,'Position',[.1 .1 .88 .88])

%%
    figure(2)
    plot(nlist,ifftlist/rep,'.-m',...
    nlist,invWavlist/rep,'x-c',...
    nlist, Hlist/rep,'o--b',...
    nlist, Glist/rep,'s-.r',...
    nlist,nlist*1e-6,'k-.',...
    nlist,nlist.^2*1e-6,'k:',...
    'linewidth',2);
    lh=legend('FFT','invWavelet','H','G','1e-6\timesn','1e-6\timesn^2')
    xlim([2^4-1,2^20+1]);
    ylim([10^-6,10])
    xlabel('Length of input vector');
    ylabel('Runtime (in seconds)')
        set(lh,'fontsize',14)
set(gca,'Position',[.1 .1 .88 .88])



%% Figure to compare H and G
   fh=figure(2)
    loglog(...
    nlist, Hlist/rep,'o--b',...
    nlist, Glist/rep,'s-.r',...
    nlist, Blist/rep,'*-.c',...
    'linewidth',2);
    lh=legend('Falling Factorial','Truncated Power','B-Spline')
    xlim([2^4-1,2^20+1]);
    ylim([10^-5,0.5])
    xlabel('n','fontsize',13);
    ylabel('Runtime (in seconds)','fontsize',13)
        set(lh,'fontsize',13,'location','southeast')
        set(fh,'position',[50,50,400,400])
set(gca,'Position',[.14 .1 .84 .88])
grid on

%% 

    fh=figure(3)
    plot(nlist,ifftlist/rep,'.-k',...
    nlist,invWavlist/rep,'x-m',...
    nlist, Hlist/rep,'o--b',...
    nlist, Blist/rep,'^--c',...
    'linewidth',2);
    lh=legend('Fourier','Wavelet','Falling factorial','B-spline')
     xlim([2^4-1,2^22*1.01]);
     ylim([10^-6,0.6])
    xlabel('n','fontsize',12);
    ylabel('Runtime (in seconds)','fontsize',12)

        set(lh,'fontsize',13,'location','northwest')
        set(fh,'position',[50,50,400,400])
set(gca,'Position',[.14 .1 .85 .88])
grid on