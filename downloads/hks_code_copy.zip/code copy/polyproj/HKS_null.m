function [ sample ] = HKS_null( Q, T, k, sample_sz )
%HKS_NULL Asymptotic null
%		T is a grid on the support of Q: [Q.xmin, Q.xmax]
%   Projection onto polynomials is w.r.t Q
%
%			Q should be a struct with xmin, xmax, pdf, mu(1:k+1)
%				mu(i) = E_Q [ X^i ]

nt = numel(T);

K = zeros(nt);

nu = zeros(nt,k+1);
% nu(t,1) = E_Q (x-t)_+; 
% nu(t,2) = E_Q x(x-t)_+

if (k==1) % works only for k=1
	for i=1:nt	
		t = T(i);
		nu(i,1) = integral( @(x) (x-t).* Q.pdf(x), t, Q.xmax);
		nu(i,2) = integral( @(x) x.*(x-t).* Q.pdf(x), t, Q.xmax);
	end

	% a(i,:) are the coeffs of the polynomial Pi_Q (x-t)_+^k 
	a = zeros(nt,k+1);
	v = Q.mu(2) - Q.mu(1)^2;
	a(:,1) = (nu(:,2) - nu(:,1) * Q.mu(1)) ./ v;
	a(:,2) = (nu(:,1) * Q.mu(2) - nu(:,2) * Q.mu(1)) ./ v;
end

% K(1,:),K(:,1),K(end,:),K(:,end)=0 as the bridge is tied to 0 at the ends
for i=2:(nt-1)
	for j=i:(nt-1)
		s = T(i);
		t = T(j);		
		if (k==0)
			K(i,j) = min(s,t) - s*t;
		end
		
		if (k==1)
			f = @(x) ( max(x-s,0) - a(i,1) .* x - a(i,2) ) .* ...
							 ( max(x-t,0) - a(j,1) .* x - a(j,2) ) .* Q.pdf(x);
			K(i,j) = integral(f, Q.xmin, Q.xmax); % - ...
				%integral( @(x) ( max(x-s,0) - a(i,1) .* x - a(i,2) ) .* Q.pdf(x), Q.xmin, Q.xmax) * ...
				%integral( @(x) ( max(x-t,0) - a(j,1) .* x - a(j,2) ) .* Q.pdf(x), Q.xmin, Q.xmax);
		end		
	end
end
K = K + K';
K(1:(nt+1):nt*nt) = K(1:(nt+1):nt*nt)/2; % diagonal

% ignore the first and last points of the bridge
gaussian_sample = mvnrnd(zeros(1,nt-2),K(2:(nt-1),2:(nt-1)),sample_sz);

sample = max(abs(gaussian_sample),[],2);

end

