function [ s ] = KS_stat_fallfact( x, y, k)
%KS_STAT_TRUNCPOW Falling factorial approximation of KS statistic of order k
%   Replace truncated power basis with the falling factorial basis

% 	if ~exist('Q','var'), Q = 'uniform'; end
	
	m = numel(x);
	n = numel(y);
	
	[z,idxx,idxy]=merge_sort_idx(x,y);
	sz=length(z);	
	
	vv=HT_times(z,double(idxx)/m-double(idxy)/n,k);
  	
	% projection \Pi_{k}^\perp w.r.t to L_2(Q_empirical)
	
	s = max(abs(vv(k+2:sz)));
	
end
