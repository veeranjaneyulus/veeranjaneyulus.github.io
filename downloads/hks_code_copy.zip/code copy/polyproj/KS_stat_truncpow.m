function [ s ] = KS_stat_truncpow( x, y, k)
%KS_STAT_TRUNCPOW Kolmogorov-Smirnov statistic of order k
%   Detailed explanation goes here

% 	if ~exist('Q','var'), Q = 'uniform'; end
	
	m = numel(x);
	n = numel(y);
	
	[z,idxx,idxy]=merge_sort_idx(x,y);
	sz=length(z);	
	
	G = gen_trunc_pow_basis( z,k );
	
	% projection \Pi_{k}^\perp w.r.t to L_2(Q_empirical)
	
	
	s = max(abs(G(:,k+2:sz)'*(double(idxx)/m-double(idxy)/n)));
end

