function z = polynomialproj(x,k,y)
%POLYPROJ z = \Pi_{k,x}(y)
%   Project y on to the space spanned by polynomials in x of degree <= k
sz=length(x);
% map it to [-1,1]
zz=(x-min(x))/(max(x)-min(x)); zz=zz*2-1;

% Construct chebychev basis
A(:,1) = ones(sz,1);
if k >= 1
    A(:,2) = zz;
end
if k >= 2
    for i = 3:k+1
        A(:,i) = 2*zz.*A(:,i-1) - A(:,i-2);  %% recurrence relation
    end
end

%fit polynomial

[U,~,~]=svd(A,'econ');
z=U*(U'*y);


end

