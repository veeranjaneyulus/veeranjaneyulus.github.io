function [ power ] = getPower( tpr,fpr, alpha_list )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
power=zeros(length(alpha_list),1);
for i=1:length(alpha_list)   
    ix=find(fpr>=alpha_list(i),1);
    power(i)=tpr(ix);
end
        

end

