function [tests,iHsep,icdf,iks,irs,immd,iad] = loadalltests(kmax,w)
    if nargin < 2
        w = 0;
    end
    for k=1:kmax
%         ksH_tests{k} = @(x,y) HKSHtest(x,y,k);
%         ksH2_tests{k} = @(x,y) HKSH2test(x,y,k);
%         pks_tests{k} = @(x,y) pKS_test(x,y,k);
        proj_tests{k} = @(x,y) HKSHseptest(x,y,k,w);
%         cdfH_tests{k} = @(x,y) cdfHtest(x,y,k);
        projfree_tests{k} = @(x,y) HKS_projfree_test(x,y,k);
    end
    tests = [proj_tests projfree_tests ...
        {@kstestfun, @ranksumfun, @mmdfun, @adtestfun}];
    iHsep=1:kmax;
    icdf=iHsep+kmax;
    iks=max(icdf)+1; 
    irs=iks+1; 
    immd=iks+2;
    iad=iks+3;
end

