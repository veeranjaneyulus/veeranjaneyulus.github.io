
m=10000;
n=10000;
k=3;

b=1/sqrt(2);
p = makedist('Normal');
q = makedist('Exponential','mu',b);

rng(0)
x = sort(random(p,m,1));
y = sort(random(q,n,1).*((rand(n,1)<0.5)-0.5)*2);
[z,idx] = merge_sort_idx(x,y);
useG=true;
[t1,t2,wit1,wit2] = pKS_test(x,y,k,useG);


[tmmd,wit] = mmdTestBootStats(x,y,-1);
%% wit[1:m] is f(x), wit[m+1:m+n] is f(y)
witmmd = zeros(size(wit));
witmmd(idx) = wit(1:m);
witmmd(~idx) = wit((m+1):(m+n));
%%

zmax = max(abs(z));
t= sort([0,linspace(-zmax,zmax,100)]);
pdf1=pdf(p,t);
pdf2=0.5/b*exp(-abs(t)/b);

figure
plot(t,pdf1,'k-',t,pdf2,'k-.','LineWidth',3); hold on
plot(z,2*wit1/norm(wit1),'r-x','LineWidth',2); hold on
plot(z,20*witmmd/norm(witmmd),'b-+','LineWidth',2); hold on

lh=legend('Gaussian','Laplacian',sprintf('KS k=%d Witness',k), 'K-MMD Witness');
set(lh,'fontsize',20)
set(lh,'Location','best')
set(gca,'fontsize',16)
set(gca,'Position',[.05 .05 .9 .93])

saveTightFig(gcf,sprintf('NewPlots/rev_witness_normal_Laplace_G_k%d.pdf',k))

%% witness vary w (the polynomial weight w in T1 + w*T2)
% 
figure('rend','painters','pos',[10 10 600 500])
nw = 6;
ws = [0, logspace(-2,2,nw-1)  ];
cc = distinguishable_colors(nw+2);

% set cc(1) to black, cc(2) blue, cc(3) red

cc(1,:) = [0,0,0]; 
cc(2,:) = [0,0,1]; 
cc(3,:) = [1,0,0]; 
cc(4,:) = [0,1,0];

plot(t,pdf1,'-',t,pdf2,'-.','LineWidth',3,'Color',cc(1,:)); hold on
plot(z,20*witmmd/norm(witmmd),'-+','LineWidth',2,'Color',cc(2,:)); hold on

labs = {};
% t1hat + w*t2hat, where t1hat, t2hat are unitvectors along wit1,wit2.
norm_ratio = norm(wit1)/norm(wit2);
for iw=1:numel(ws)
    w = ws(iw);
    wit = wit1 + (w*norm_ratio)*wit2;
    plot(z,2*wit/norm(wit),'-','LineWidth',2, 'Color', cc(iw+2,:)); hold on
    labs{iw} = sprintf('w''=%.2g',w);
end

xlim([-zmax,zmax])

lh=legend('Gaussian','Laplacian','K-MMD Witness', labs{:});
set(lh,'fontsize',18)
% set(lh,'Location','NorthWest')
set(lh,'Location','best')
set(gca,'fontsize',16)
set(gca,'Position',[.05 .05 .9 .93])

saveTightFig(gcf,sprintf('NewPlots/rev_witness_normal_Laplace_G_k%d_varyw.pdf',k))


