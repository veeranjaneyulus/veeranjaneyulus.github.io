%% oracle likelihood function, (p+q)/2 null
function olr = olrfun_pd(x,y,pd,pd2)
    logL0= sum(log( (pdf(pd,[x;y]) + pdf(pd2,[x;y]))/2 ));
    logL1= sum(log(pdf(pd,x))) + sum(log(pdf(pd2,y)));
    olr=logL1-logL0;
end
