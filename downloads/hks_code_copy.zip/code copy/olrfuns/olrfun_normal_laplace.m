function olr = olrfun_normal_laplace(x,y)
    pd = makedist('Normal');
    pd2 = makedist('Exponential','mu',1/sqrt(2));
    logL0 = sum(log( (pdf(pd,[x;y]) + pdf(pd2,abs([x;y]))/2 )/2 ));
    logL1 = sum(log(pdf(pd,x)) + log(pdf(pd2,abs(y))/2));
    olr=logL1-logL0;
end
