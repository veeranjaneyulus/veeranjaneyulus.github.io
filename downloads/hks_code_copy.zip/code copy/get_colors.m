function [cc] = get_colors()
%GET_COLORS Summary of this function goes here
%   Detailed explanation goes here
colors=distinguishable_colors(11); % HKS(5), ks, oracle, AD, mmd-rbf, mmd-poly, wasserstein
colors=flip(colors);
% want black for oracle
cc.olr = colors(8,:); % 11-3 is nearly black
cc.hks = colors(1:5,:);
cc.ks = colors(6,:);
cc.ad = colors(7,:);
cc.rbf = colors(9,:);
cc.poly = colors(10,:);
cc.energy = colors(11,:);

end

