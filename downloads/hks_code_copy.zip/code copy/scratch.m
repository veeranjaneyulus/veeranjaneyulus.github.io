
pd = makedist('Normal');
nu=5;
pd2 = makedist('tLocationScale','sigma',1,'nu',nu);%default dof=5

x = -4:0.05:4;
max(abs(cdf(pd,x) - cdf(pd2,x)))

nsim=200;
d0 = zeros(nsim,1);
d1 = zeros(nsim,1);
ks0 = zeros(nsim,1);
ks1 = zeros(nsim,1);
m=100;
for i=1:nsim
    xx = random(pd,m,1);
    xx2 = random(pd,m,1);
    yy = random(pd2,m,1);
    d0(i) = mean(abs(xx)) - mean(abs(xx2));
    d1(i) = mean(abs(xx)) - mean(abs(yy));
    
    [~,~,ks0(i)] = kstest2(xx,xx2);
    [~,~,ks1(i)] = kstest2(xx,yy);
end

[mystats([ks0,d0]);
 mystats([ks1,d1])]

%%
% check the null distribution of KS, KS(1) statistics
% check the alternate distribution of KS, KS(1) statistics
m=100;n=100;num=1000;
k=1;
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n));
[tests,iH,iH2,iPH2,icdfH,iHsep,iks,irs,immd,iad] = loadalltests(kmax);
pks_tests = {tests{iPH2}};
tests = {tests{iks},pks_tests{1}}; 
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex);

plotroc(ex,'NewPlots/scratch.pdf',1:numel(tests),{'KS', 'pKS'})
getpower(ex,0.1)

%%
fprintf('Top row is for null, bottom for alternative\n(means) (stds)')
[mystats(res(1:num/2,:));
 mystats(res(num/2+1:end,:))]

%%
mm=5000;
x = sort([normrnd(0,1,mm,1); normrnd(0.3,2,mm,1)])  ;
%x = linspace(0,1,mm)';
[q,r] = qr([ ones(size(x)), x, x.^2, x.^3],0);
plot(q)
legend('b0','b1','b2','b3')
max(abs(q))

%%
x = (1:8);k=2;
G = gen_trunc_pow_basis(x,k);
Gi = inv(G);
for i=1:numel(x)
    fprintf('%.0f ',Gi(i,:)); fprintf('\n'); 
end

%%
x = sort(normrnd(0,1,100,1)); 
y = sort(normrnd(0,4,100,1));

k=2;
[ tKS, tpoly, witness1, witness2 ] = HKS_projfree_test(x,y,k);


%%
function s = mystats(x)
 s = [mean(x), std(x)];
end

