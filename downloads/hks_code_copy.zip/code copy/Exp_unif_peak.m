
kmax = 5;
m=100;n=100;num=1000;

legend_labs = {'HKS','MMD.poly','KS','Oracle'};
runsim=true;
polyproj = false;
centerhks = false;
w = 0;
mmdpolydeg = [1:5, 8:4:20];
hksodddeg =1:2:kmax;
hks_tests = cell(1,kmax);
mmdpoly_tests = cell(1,numel(mmdpolydeg));

for k=1:kmax
    hks_tests{k} = @(x,y) HKS_projfree_test(x,y,k,polyproj,centerhks);
end
for i=1:numel(mmdpolydeg)
    mmdpoly_tests{i} = @(x,y) mmdTestPoly(x,y,mmdpolydeg(i));
end

dr = 'NewPlots2/permnull_';

iprojfree = 1:kmax;
immdpoly = kmax + (1:numel(mmdpolydeg));
iks = max(immdpoly)+1;
immd = iks+1;
ienergy = iks+2;
iad = iks+3;
iolr = iks+4;

cc = get_colors();


prefix = sprintf('%sExp_unif_peak',dr);
m=500;n=500;num=500;
t0=0.25; sig=0.01; w=0.1;% 0.9 U(0,1) + 0.1 N(t0,sig^2), s

xgen = @(m,n) sort(rand(m,n)); % Uniform [0,up]
ygen = @(m,n) gen_unif_peak_gauss(t0,sig,w,m,n); 
olrfun = @(x,y) olrfun_unif_peak_gauss(t0,sig,w,x,y);
tests = [hks_tests mmdpoly_tests {@kstestfun, @mmdfun, @energyDist, @adtestfun, olrfun}];

if runsim
    ex = exp_roc(xgen,ygen,m,n,num,tests);
    res = simulate(ex);
    save(sprintf('%s.mat',prefix),'ex');
end
%%
load(sprintf('%s.mat',prefix),'ex')

x=linspace(0,1,500);
pdf1=ones(numel(x),1);
pdf2=pdf_peak_gauss(t0,sig,w,x);
lab1='p';lab2='q';
plotpdfs(sprintf('%s_pdf.pdf',prefix),x,pdf1,pdf2,lab1,lab2);
% plot ROC curves
plotHKSOnly(ex,sprintf('%s_HKS.pdf',prefix),iprojfree,iks,iolr,cc)
plotKSOthers(ex,sprintf('%s_benchmark_mmdpoly.pdf',prefix),iprojfree,immdpoly,iks,ienergy,immd,iad,iolr,mmdpolydeg,1:kmax,cc)
plotHKSOthers(ex,sprintf('%s_benchmark_projfree_allhksroc.pdf',prefix),iprojfree(hksodddeg),iks,ienergy,immd,iad,iolr,hksodddeg,cc)
plotBestHKSOthers(ex,sprintf('%s_benchmark_projfree_besthksroc.pdf',prefix),iprojfree,iks,ienergy,immd,iad,iolr,1:kmax,cc)
hold off



function y = gen_unif_peak_gauss(t0,sig,w,m,n)
    x = rand(m,n);
    y = (x<=1-w).* rand(m,n) + (x>1-w).* normrnd(t0,sig,m,n);
end

function px = pdf_peak_gauss(t0,sig,w,x)
    px = (1-w) + w.*normpdf(x,t0,sig);
end

function olr = olrfun_unif_peak_gauss(t0,sig,w,x,y)
    logL1 = sum(log(pdf_peak_gauss(t0,sig,w,y)));
    olr = logL1;
end

function [] = plotpdfs(filename,x,pdf1,pdf2,lab1,lab2)
    figure
    plot(x,pdf1,'b-','LineWidth',2); hold on
    plot(x,pdf2,'r:','LineWidth',2)
    lh=legend(lab1,lab2);
    set(lh,'fontsize',18,'Location','best')
    set(gca,'Position',[.05 .05 .9 .93],'FontSize',18)
    
    saveTightFig(gcf,filename);
end

