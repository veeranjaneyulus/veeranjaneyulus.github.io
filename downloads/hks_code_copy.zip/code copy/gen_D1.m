function [ D ] = gen_D1( n )
% gen_Dk    this function generate Dk, the discrete kth order derivative
%           matrix
% input
% n         input dimension

D=sparse(n-1,n);
%D=zeros(n-1,n);
idx=sub2ind(size(D),1:n-1,1:n-1);
idx1=sub2ind(size(D),1:n-1,2:n);

D(idx)=-1;
D(idx1)=1;
end