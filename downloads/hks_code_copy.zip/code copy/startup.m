
fprintf('Starting at hks/code\n')

%addpath(genpath(pwd))
