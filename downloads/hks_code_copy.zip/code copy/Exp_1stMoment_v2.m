%% This script explores potential failure case for 
addpath('prec_rec')
addpath('btest-master')
addpath('mmd')
%% setting
m=100;n=100;
stats=0;
num=1000;
mu_diff=0.2;

kmax=5;
eksG_list=zeros(num,kmax);
eksH_list=zeros(num,kmax);


pks_list=zeros(num,kmax);

ks_list=zeros(num,1);
rs_list=zeros(num,1);%rank-sum
kb_list=zeros(num,1);%kernel B-test
mmd_list=zeros(num,1);%MMD
ad_list=zeros(num,1);
olr_list=zeros(num,1);% oracle likelihood ratio test


pd = makedist('Exponential','mu',1/sqrt(2));


figure(3)
x=-4:.1:4;
b=1/sqrt(2);
pdf1=0.5/b*exp(-abs(x)/b);
pdf2=0.5/b*exp(-abs(x-mu_diff)/b);

% pdf1 = pdf(pd1,x);
% pdf2 = pdf(pd2,x);
plot(x,pdf1,...
    x,pdf2,'LineWidth',2)
lh=legend('Lap(0,1/sqrt(2))','N(0.2,1/sqrt(2))');
set(lh,'fontsize',14)
set(gca,'Position',[.05 .05 .9 .93])
%%
%figure(3)

for i=1:num

x=sort(sort(random(pd,m,1).*((rand(m,1)<0.5)-0.5)*2));
if i<=floor(num/2)
y=sort(random(pd,n,1).*((rand(n,1)<0.5)-0.5)*2);
else
y=sort(random(pd,n,1).*((rand(n,1)<0.5)-0.5)*2)+mu_diff;
end



for j=1:kmax
    k=j;
    [z,idxx,idxy]=merge_sort_idx(x,y);
    sz=length(z);
%     H = gen_fallingfactobasis( z,k );
%     eksH=1/n*max(abs(H(:,k+2:sz)'*(double(idxx)-double(idxy))));
    
    % compare KS-test, Gk-test and Hk-test
    vv=HT_times(z,double(idxx)-double(idxy),k);
    eksH=1/n*max(abs(vv(k+2:sz)));
    eksH_list(i,j)=eksH;
    
    G = gen_trunc_pow_basis( z,k );
    eksG=1/n*max(abs(G(:,k+2:sz)'*(double(idxx)-double(idxy))));
    eksG_list(i,j)=eksG;
    
    
    pks_list(i,j)=pKS_test( x,y,k);
    
end

%AD-test
ad = ADtestk([[x, ones(size(x))];[y, 2*ones(size(y))]]);
ad_list(i)=ad;

%ks-test
[h,p, ks]=kstest2(x,y);
ks_list(i)=ks;

%wilcoxon test
[p,h,rs] = ranksum(x,y);
rs_list(i)=-rs.ranksum;

%alex's mmd 

mmd = mmdTestBootStats(x,y,-1);
mmd_list(i)=mmd;

%Fast MMD: B-test
[h,p,kb]=btest(num2cell(x),num2cell(y));
kb_list(i)=kb;


%oracle likelihood ratio test
logL0= sum(-sqrt(2)*abs([x;y])) +(m+n)*log(1/sqrt(2));
logL1= sum(-sqrt(2)*abs(x)) +n*log(1/sqrt(2))...
    +sum(-sqrt(2)*abs(y-mu_diff)) +n*log(1/sqrt(2));
olr=logL1-logL0;
olr_list(i)=olr;
fprintf('Iteration %i done.\n',i);
end



%% FFKS plot with increasing k

figure(1)
target=[zeros(floor(num/2),1);ones(ceil(num/2),1)];
%[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1);
tpr1=[];tpr2=[];
fpr1=[];fpr2=[];
for i=1:kmax
    [prec, tpr, fpr, thresh] = prec_rec(pks_list(:,i), target, 'plotROC',0);

%[prec, tpr, fpr, thresh] = prec_rec(eksG_list(:,i), target, 'plotROC',0);
tpr1=[tpr1,tpr];fpr1=[fpr1,fpr];
[prec, tpr, fpr, thresh] = prec_rec(eksH_list(:,i), target, 'plotROC',0);
tpr2=[tpr2,tpr];fpr2=[fpr2,fpr];
end
hold off;
[prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',0);
plot(fpr,tpr,'k-.','linewidth',2);
hold on;
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',0);
plot(fpr,tpr,'m-','linewidth',2);

for i=1:kmax
plot(fpr1(:,i),tpr1(:,i),'r-','linewidth',2);
hold on;
plot(fpr2(:,i),tpr2(:,i),'b--','linewidth',2);
end

plot([0,1],[0,1],'k')
xlim([-0.01,1.01]);
ylim([-0.01,1.01]);
xlabel('False postive rate','fontsize',12);
ylabel('True postive rate','fontsize',12)
ti = get(gca,'TightInset');
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

hline = findobj(gcf, 'type', 'line');
lg=legend(hline([end-1,end-2,end-3,end]),{'0th order KS','kth order pKS','kth order KS','Oracle'});
%lg=legend(hline([end-1,end-2,end-3,end]),{'0th order KS','kth order KS (with G)','kth order KS (with H)','Oracle'});
set(lg,'fontsize',12,'Location','best')
%
for i=1:kmax
    str=sprintf('k=%d',i);
%      txx=0.8-0.1*(i-1);
%      txy=0.7-0.1*(i-1);
     txx=0.8-0.1*(kmax-i);
     txy=0.7-0.1*(kmax-i);
    %arx=[txx,fpr1(floor(length(fpr1(:,i))/2),i)+0.05];
    arx=[txx,0.15];
    [val,IX]=min(abs(fpr1(:,i)-0.15));
    ary=[txy,tpr1(IX,i)];
    
text(txx,txy,str)
axPos = get(gca,'Position');
xMinMax = xlim;
yMinMax = ylim;
xAnnotation = axPos(1) + ((arx - xMinMax(1))/(xMinMax(2)-xMinMax(1))) * axPos(3);
yAnnotation = axPos(2) + ((ary - yMinMax(1))/(yMinMax(2)-yMinMax(1))) * axPos(4);
ah=annotation('arrow',xAnnotation,yAnnotation);
end

h=figure(1)
saveTightFigure(h,'Exp_pKS_1stMoment_v2.pdf');


%% Compare with other two-sample tests

[prec, tpr, fpr, thresh] = prec_rec(eksH_list(:,1), target, 'plotROC',1, 'numThresh',1000,'style','--b');
[prec, tpr, fpr, thresh] = prec_rec(pks_list(:,1), target, 'plotROC',1,'holdFigure',1,'style',':b');
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1,'holdFigure',1,'style','m-');
[prec, tpr, fpr, thresh] = prec_rec(rs_list, target, 'plotROC',1,'holdFigure',1,'style','c-');
[prec, tpr, fpr, thresh] = prec_rec(mmd_list, target, 'plotROC',1,'holdFigure',1,'style','g-');
%[prec, tpr, fpr, thresh] = prec_rec(kb_list, target, 'plotROC',1,'holdFigure',1);
[prec, tpr, fpr, thresh] = prec_rec(ad_list, target, 'plotROC',1,'holdFigure',1,'style','r-');
[prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',1,'holdFigure',1,'style','k-.');
xlim([-0.01,1.01]);
ylim([-0.01,1.01]);

ti = get(gca,'TightInset');
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

hline = findobj(gcf, 'type', 'line');
set(hline(1:end-1),'linewidth',2)

xlabel('False postive rate','fontsize',12);
ylabel('True postive rate','fontsize',12)
lg=legend(hline([5,6,7,4,3,2,1]),{'0th order KS','1st order pKS','1st order KS','Rank-sum','MMD','Anderson-Darling','Oracle'});
set(lg,'fontsize',12,'Location','best')

h=figure(1)
saveTightFigure(h,'Exp_pBenchMark_1stMoment_v2.pdf');
