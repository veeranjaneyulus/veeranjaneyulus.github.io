% QQ plots for Higer-order KS statistic vs. asymptotic goodness-of-fit null

% requires export_fig for append_pdfs

rng(0)
m=1000;n=1000;
k=1;
nsim=1000; %1000
nsample = 1000; %1000;
tic

%% 
T = linspace(0,1,100); %100
T_null = linspace(0,1,50); %100

% Create a bunch of beta distributions
beta_par1 = [1,1,1,2,4,2,2,5];
beta_par2 = [1,2,4,1,1,2,8,5];

nQ = numel(beta_par1);
Q_list = cell(nQ,1);
for i=1:nQ
	a = beta_par1(i); b= beta_par2(i);
	pd = makedist('beta',a,b);
	Q.xmin = 0;
	Q.xmax = 1;
	Q.pdf = @(x) pd.pdf(x);
	Q.mu = [pd.mean, pd.var+pd.mean^2]; % E[x], E[x^2]
	Q.pd = pd;
	Q_list{i} = Q;
end
%%
% qq_gof_pdfs = cell(nQ,1);
qq_ts_pdfs = cell(nQ,1);

eksN = zeros(nsim,nQ);
% eksT_gof = zeros(nsample,nQ); % goodness-of-fit
eksT_ts = zeros(nsample,nQ); % two-sample

parfor i=1:nQ	
	eksN(:,i) = HKS_null(Q_list{i},T_null,k,nsim);
end

% parfor i=1:nQ	
% 	Q = Q_list{i};
% 	xx = random(Q.pd, [n, nsample]);
% 	eksT_gof(:,i) = pKS_goodness_of_fit(Q, T, k, xx );
% end
% clear xx

%%
for i=1:nQ	
	Q = Q_list{i};	
	for j=1:nsample
		x = random(Q.pd,[m,1]);
		y = random(Q.pd,[n,1]);
		eksT_ts(j,i) = pKS_test(sort(x),sort(y),k);
	end		
end

%% QQ plots in an array
figure('pos',[10,10,1000,500])
for i=1:nQ
	% Two sample test statistic vs. null
    subplot(2,4,i)
	qqplot(eksN(:,i), eksT_ts(:,i))
	title(sprintf('a=%d b=%d',beta_par1(i), beta_par2(i)), 'fontsize', 12)
    if(i==1)
        xlabel('Null quantiles', 'fontsize', 12);
        ylabel('Test stat quantiles', 'fontsize', 12);
    else
        xlabel('')
        ylabel('')
    end
end

saveTightFig(gcf, 'NewPlots/nulldist_twosample_beta_k1_w0.pdf')

    
%%
figure
for i=1:nQ
	% Two sample test statistic vs. null
	qqplot(eksN(:,i), eksT_ts(:,i)); 
	title(sprintf('a=%d b=%d',beta_par1(i), beta_par2(i)), 'fontsize', 30)
    
    xlabel('Null quantiles', 'fontsize', 30)
    ylabel('Test stat quantiles', 'fontsize', 30)

    xt = get(gca, 'XTick');
    yt = get(gca, 'YTick');
    set(gca, 'FontSize', 24)

    qq_ts_pdfs{i} = sprintf('NewPlots/qq_ts_k1_beta_a%d_b%d.pdf',beta_par1(i), beta_par2(i));
	saveTightFig(gcf, qq_ts_pdfs{i})

end
	

% system('rm ../Experiments/qq_k1_beta.pdf');
% append_pdfs('../Experiments/qq_k1_beta.pdf', qq_gof_pdfs{:})
% system('rm ../Experiments/qq_ts_k1_beta.pdf');
% append_pdfs('../Experiments/qq_ts_k1_beta.pdf', qq_ts_pdfs{:})


    %%	Goodness-of-fit test statistic vs. null
% 	qqplot(eksN(:,i), eksT_gof(:,i))	
% 	title(sprintf('a=%d b=%d',beta_par1(i), beta_par2(i)), 'fontsize', 12)	
% 	if(i==1)
% 		xlabel('Null quantiles', 'fontsize', 12)
% 		ylabel('Test stat quantiles', 'fontsize', 12)
% 	end
% 	qq_gof_pdfs{i} = sprintf('../NewPlots/qq_k1_beta_a%d_b%d.pdf',beta_par1(i), beta_par2(i));
% 	saveTightFig(gcf, qq_gof_pdfs{i})



