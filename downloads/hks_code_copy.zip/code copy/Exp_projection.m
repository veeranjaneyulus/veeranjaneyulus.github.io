% HKS with polynomial projection has good power on p,q which have 
% same k moments but different higher order moments.
% Is the power of HKS simply due to projection? To check this, do a similar
% projection on other IPM tests -- KS, MMD-RBF and MMD-poly and check their
% power

kmax = 5;
m=100;n=100;num=1000;
polyproj=false; % do not project out polynomials
w=0;
runsim=true; % true -> run simulations, false -> only plot
hksalldeg = [1:5, 8:4:20];
mmdpolydeg = [1:5, 8:4:20];
[tests_noolr,iproj,immdpoly,iks,irs,immd,iad] = alltests(kmax, polyproj,w,mmdpolydeg,hksalldeg);
iolr = numel(tests_noolr)+1;

dr = 'NewPlots2/';

legend_labs_proj = {'KS.new.proj','MMD.poly','KS','Oracle'};


%% N(0,1) vs. Laplace(0,1/sqrt(2))
prefix = sprintf('%sProj_Exp_3rdMoment_v1',dr);
pd = makedist('Normal');
pd2 = makedist('Exponential','mu',1/sqrt(2));
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n).*((rand(m,n)<0.5)-0.5)*2);
olrfun = @(x,y) olrfun_3rdMoment_v1(x,y,m,n);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end

plot_ex(prefix,iproj,immdpoly,iks,irs,immd,iad,iolr,mmdpolydeg,legend_labs_proj)


function olr = olrfun_3rdMoment_v1(x,y,m,n)
    logL0= 0.5*std_normal_logL( [x;y] ) + (m+n)*log(1/sqrt(2*pi));
    logL1= sum(-sqrt(2)*abs(y)) +n*log(1/sqrt(2))...
        +0.5*std_normal_logL(x)+m*log(1/sqrt(2*pi));
    olr=logL1-logL0;
end


%% test functions
function [tests,iproj,immdpoly,iks,irs,immd,iad] = alltests(kmax,polyproj,w,mmdpolydeg,hksalldeg)
    k_proj=3; % 3 for Normal vs Laplace
    for k=1:kmax
        proj_tests{k} = @(x,y) HKSHseptest(x,y,k,w);
        % projfree_tests{k} = @(x,y) HKS_projfree_test(x,y,k,polyproj);
    end
    for i=1:numel(mmdpolydeg)
        mmdpoly_tests{i} = @(x,y) mmdTestPolyProj(x,y,mmdpolydeg(i),k_proj);
    end
%     for i=1:numel(hksalldeg)
%         hksall_tests{i} = @(x,y) HKS_allk_test(x,y,hksalldeg(i));
%     end
    tests = [proj_tests mmdpoly_tests ...
        {@(x,y) KSproj(x,y,k_proj), @ranksumfun, @(x,y) mmdTestGaussProj(x,y,-1,k_proj), @adtestfun}];
    iproj=1:kmax; current=max(iproj);
    immdpoly=current+ (1:numel(mmdpolydeg)); current=max(immdpoly);
    iks=current+1;
    irs=iks+1; 
    immd=iks+2;
    iad=iks+3;
end


function [] = plot_ex(prefix,iproj,immdpoly,iks,irs,immd,iad,iolr,mmdpolydeg,legend_labs_proj)
    load(sprintf('%s.mat',prefix),'ex')
    
    plotHKS(ex,sprintf('%s_HKS_proj.pdf',prefix),iproj,immdpoly,iolr,iks,legend_labs_proj)
    
    
    plotKSOthers(ex,sprintf('%s_benchmark_proj.pdf',prefix),iproj,immdpoly,iks,irs,immd,iad,iolr,mmdpolydeg,1:numel(iproj))
    
end
