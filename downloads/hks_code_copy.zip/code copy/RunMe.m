
run Exp_motivation.m
run Exp_asymptotic_null.m
run Exp_moments.m
run Exp_perturbations.m

%% talk figs

run witness_pin0.m  % trunc. pow. basis function plots

stairs([0,r,r+b,r+2*b,1]',[1,1+b,1-b,1,1]','r:','LineWidth',2)



