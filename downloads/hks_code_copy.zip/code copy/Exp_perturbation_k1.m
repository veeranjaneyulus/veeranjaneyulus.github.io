
%%
kmax = 5;

legend_labs = {'HKS','MMD.poly','KS','Oracle'};
runsim=false;
polyproj = false;
centerhks = true;
w = 0;
mmdpolydeg = [1:5, 8:4:20];
hksodddeg =1:2:kmax;
hks_tests = cell(1,kmax);
mmdpoly_tests = cell(1,numel(mmdpolydeg));

for k=1:kmax
    hks_tests{k} = @(x,y) HKS_projfree_test(x,y,k,polyproj,centerhks);
end
for i=1:numel(mmdpolydeg)
    mmdpoly_tests{i} = @(x,y) mmdTestPoly(x,y,mmdpolydeg(i));
end

dr = 'NewPlots2/';

cc = get_colors();


%% Uniform vs. Uniform + bump k=1 (triangle function bump)
prefix = sprintf('%sExp_unif_bump1',dr);
pd = makedist('Uniform');
pd2 = makedist('Beta','a',1,'b',2);

h=0.2;r=0.2;b=0.05;
m=5000;n=5000;num=100;
xgen = @(m,n) sort(rand(m,n));
ygen = @(m,n) gen_unif_bump12(r,b,m,n); % Uniform -- with triangular bumps
olrfun = @(x,y) olrfun_pd(x,y,pd,pd2); %TODO change this!!
tests = [hks_tests {@kstestfun, olrfun}];
iprojfree=1:numel(hks_tests);
iks=iprojfree(end)+1;
iolr=iks+1;
if runsim
    ex = exp_roc(xgen,ygen,m,n,num,tests);
    res = simulate(ex);
    save(sprintf('%s.mat',prefix),'ex');
end

load(sprintf('%s.mat',prefix),'ex')

% plot pdfs
figure
lab1='p';lab2='q';
plot(linspace(0,1,5), ones(5,1), 'b-','LineWidth',2);hold on
plot([0,r,r+b/2,r+b,r+3*b/2,r+2*b,1]',[1,1,2,1,0,1,1]','r:','LineWidth',2)
lh=legend(lab1,lab2);
set(lh,'fontsize',18,'Location','best')
set(gca,'Position',[.05 .05 .9 .93])
set(gca,'FontSize',18)

saveTightFig(gcf,sprintf('%s_pdf.pdf',prefix));
hold off

plotHKSOnly(ex,sprintf('%s_HKS.pdf',prefix),iprojfree,iks,iolr,cc)
% plotKSOthers(ex,sprintf('%s_benchmark.pdf',prefix),iprojfree,immdpoly,iks,ienergy,immd,iad,iolr,mmdpolydeg,1:kmax,cc)
hold off
k1=3;
legend_names={ sprintf('KS k=%d',k1), 'KS k=0'};
% plotTestStats(ex,sprintf('%s_teststats.pdf',prefix),[iprojfree(k1), iks],legend_names)
plotTestStats(ex,sprintf('%s_teststats.pdf',prefix),1:6,legend_names)


function olr = olrfun_pd(x,y,pd,pd2)
    logL0= sum(log(pdf(pd,[x;y])));
    logL1= sum(log(pdf(pd,x))) + sum(log(pdf(pd2,y)));
    olr=logL1-logL0;
end

function [] = plotpdfs(filename,x,pdf1,pdf2,lab1,lab2)
    figure
    plot(x,pdf1,x,pdf2,'LineWidth',2)
    lh=legend(lab1,lab2);
    set(lh,'fontsize',14)
    set(gca,'Position',[.05 .05 .9 .93])
    saveTightFig(gcf,filename);
end
