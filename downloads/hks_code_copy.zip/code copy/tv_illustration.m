

figure
stairs([0,1,2,3]',[0,1,0,0]','LineWidth',4)
lh=legend('step');
set(lh,'visible','off')
yl=ylim;
% ylim([0 1]*1.1)
set(gca,'Position',[.05 .05 .9 .93])
set(gca,'FontSize',36)
ax = gca;
ax.XAxis.Visible = 'off'; % remove x-axis
ax.LineWidth=0.25;
yticks([0,1])
box(ax,'off')
saveTightFig(gcf,'NewPlots2/step.pdf');

%%
figure
plot([0,1,2,3]',[0,0,1,1]','LineWidth',4)
lh=legend('step1');
set(lh,'visible','off')
set(gca,'Position',[.05 .05 .9 .93])
set(gca,'FontSize',36)
xticks([0,1,2,3])
yticks([0,1])
ax=gca;
ax.LineWidth=0.25;
box(gca,'off')
saveTightFig(gcf,'NewPlots2/triangle.pdf');
