kmax = 5;
m=100;n=100;num=100;
polyproj=false; % do not project out polynomials
w=0;
runsim=true; % true -> run simulations, false -> only plot

tests = {@energyDist, @kstestfun};
dr = 'NewPlots2/';


prefix = sprintf('%sEnergyDist',dr);
b_diff=1/sqrt(2);
pd = makedist('Exponential','mu',1/sqrt(2));
pd2 = makedist('Exponential','mu',1/sqrt(2)*b_diff);
xgen = @(m,n) sort(random(pd,m,n).*((rand(m,n)<0.5)-0.5)*2);
ygen = @(m,n) sort(random(pd2,m,n).*((rand(m,n)<0.5)-0.5)*2);
olrfun = @(x,y) olrfun_2ndMoment_v2(x,y,m,n,b_diff);
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end

%%
legend_labs={'ED','KS'};
plotroc(ex,sprintf('%s_roc.pdf',prefix),1:numel(tests),legend_labs)
plotTestStats(ex,sprintf('%s_teststats.pdf',prefix),1:numel(tests),legend_labs)


%%
num=100;
ed=zeros(num,2);
for i=1:num
    x=xgen(m,1);y=xgen(n,1);
    ed(i,1)=energyDist(x,y);
end

for i=1:num
    x=xgen(m,1);y=ygen(n,1);
    ed(i,2)=energyDist(x,y);
end
figure
[f,xi] = ksdensity(ed(:,1));
plot(xi,f,'linewidth',2); hold on

[f,xi] = ksdensity(ed(:,2));
plot(xi,f,'linewidth',2);
legend('Null', 'Alternative')
hold off


function olr = olrfun_2ndMoment_v2(x,y,m,n,b_diff)
    logL0= sum(-sqrt(2)*abs([x;y])) +(m+n)*log(1/sqrt(2));
    logL1= sum(-sqrt(2)*abs(x)) +m*log(1/sqrt(2))...
        +sum(-sqrt(2)/b_diff*abs(y)) +n*log(b_diff/sqrt(2));
    olr=logL1-logL0;
end

