function normA = norm(A, n)
%NORM   Norm of a CHEBMATRIX object.
%   NORM(A) computes the Frobenius norm of the CHEBMATRIX object A, defined as
%   the sum of the squares of the 2-norms of each of the blocks.
%
%   NORM(A, 2) or NORM(A, 'fro') is the same as above.
%
%   NORM(A, INF) computes the infinity norm of the CHEBMATRIX A, defined as the
%   maximum infinity norm of each of the blocks.
%
% See also CHEBMATRIX, CHEBFUN/NORM.

% Copyright 2014 by The University of Oxford and The Chebfun Developers.
% See http://www.chebfun.org/ for Chebfun information.

% [TODO]: Add support for norms of operators (inf x inf blocks).

% Empty CHEBMATRIX has norm 0.
if ( isempty(A) )
    normA = 0;
    return
end

if ( nargin == 1 )
    n = 'fro'; 	% Frobenius norm is the default.
end

% The norm of a CHEBMATRIX with inf x inf block(s) is not supported.
s = cellfun(@(b) min(size(b)), A.blocks);
if ( ~all(isfinite(s(:))) )
    error('CHEBFUN:CHEBMATRIX:norm:notSupported', ...
    'Norm of a chebmatrix with inf x inf block(s) is not supported.')
end

% Deal with different cases.
switch n
    
    case {'fro', 2}
        normA = cellfun(@(v) norm(v, 2), A.blocks);
        normA = sqrt(sum(normA(:).^2));
        
    case {inf, 'inf'}
        normA = cellfun(@(v) norm(v, inf), A.blocks);
        normA = max(normA(:));
        
    otherwise
        if ( ~ischar(n) )
            n = num2str(n);
        end
        error('CHEBFUN:CHEBMATRIX:norm:uknown', ...
            'unsupported norm type ''%s''', n)
        
end

end
