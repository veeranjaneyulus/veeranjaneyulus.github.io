function [ stats ] = Bspline_test( x,y,k )
addpath('Bsplines')
[ z, idx1,idx2 ] = merge_sort_idx( x,y );
[B] = bspline_basismatrix(k+1,z,z);

[sp,values] = spaps(z,eye(length(z)),1,ones(size(z)),k); 
pp=csaps(z,eye(length(z)));
tmp=eye(length(z));
pp = csape(z,tmp(2,:),'variational') 
%Bspline_test This function constructs the test statistic for smoothing
%splines
%   input x and y are two groups of data
%   k is the order of the splines, k=1, linear B-spline, k=2, 



end

