
%%
kmax = 5;
m=100;n=100;num=1000;

legend_labs = {'HKS','MMD.poly','KS','Oracle'};
runsim=false;
polyproj = false;
w = 0;
mmdpolydeg = [1:5, 8:4:20];
ksHsep_tests = cell(1,kmax);
mmdpoly_tests = cell(1,numel(mmdpolydeg));

for k=1:kmax
%     ksHsep_tests{k} = @(x,y) HKSHseptest(x,y,k,w);
%     ksHsep_tests{k} = @(x,y) HKS_allk_test(x,y,k);
    ksHsep_tests{k} = @(x,y) HKS_projfree_test(x,y,k,polyproj);
    
end
for i=1:numel(mmdpolydeg)
    mmdpoly_tests{i} = @(x,y) mmdTestPoly(x,y,mmdpolydeg(i));
end

dr = 'NewPlots2/';

iprojfree = 1:kmax;
immdpoly = kmax + (1:numel(mmdpolydeg));
iks = max(immdpoly)+1;
immd = iks+1;
irs = iks+2;
iad = iks+3;
iolr = iks+4;




%% Uniform vs. Uniform + g_t
prefix = sprintf('%sExp_unif',dr);
pd = makedist('Uniform');
pd2 = makedist('Beta','a',1,'b',2);

m=500;n=500;
r=9/10; b=5; % MMD-poly slightly better than HKS
up = r +  (1/b) * ((1 + 3*b*(1-r))^(1/3) - 1);
xgen = @(m,n) sort(rand(m,n) .* up);
ygen = @(m,n) gen_unif_gt(r,b,m,n); % Uniform -- with alignment to a g_t
olrfun = @(x,y) olrfun_pd(x,y,pd,pd2); %TODO change this!!
tests = [ksHsep_tests mmdpoly_tests {@kstestfun, @mmdfun, @ranksumfun, @adtestfun, olrfun}];
if runsim
    ex = exp_roc(xgen,ygen,m,n,num,tests);
    res = simulate(ex);
    save(sprintf('%s.mat',prefix),'ex');
end

load(sprintf('%s.mat',prefix),'ex')
plotHKS(ex,sprintf('%s_HKS.pdf',prefix),iprojfree,immdpoly,iks,iolr,legend_labs)
plotKSOthers(ex,sprintf('%s_benchmark.pdf',prefix),iprojfree,immdpoly,iks,irs,immd,iad,iolr,mmdpolydeg)
hold off


%% Normal vs. t(3)
prefix = sprintf('%sExp_normal_vs_t_mmdpoly',dr);
pd = makedist('Normal');
pd2 = makedist('tLocationScale','nu',3);%default dof=5

h=0.1;r=0.25;b=0.05;
m=50;n=50;
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n)); % Uniform -- with triangular bumps
olrfun = @(x,y) olrfun_pd(x,y,pd,pd2);
tests = [ksHsep_tests mmdpoly_tests {@kstestfun, @mmdfun, @energyDist, @adtestfun, olrfun}];
if runsim
    ex = exp_roc(xgen,ygen,m,n,num,tests);
    res = simulate(ex);
    save(sprintf('%s.mat',prefix),'ex');
end

load(sprintf('%s.mat',prefix),'ex')

plotHKS(ex,sprintf('%s_HKS.pdf',prefix),iprojfree,immdpoly,iks,iolr,legend_labs)
plotKSOthers(ex,sprintf('%s_benchmark.pdf',prefix),iprojfree,immdpoly,iks,irs,immd,iad,iolr,mmdpolydeg)
hold off

%%
alpha=0.1;
t5 = getpower(ex,0.05);
t10 = getpower(ex,alpha);

fprintf('k\tKS\tMMD(polynomial)\n')
fprintf('%d\t%.3f\t%.3f\n', [(1:kmax)', t10(1:kmax), t10(kmax+1:2*kmax)]')
fprintf('KS\t%.3f\nMMD-RBF\t%.3f\nRankSum\t%.3f\nAD\t%.3f\nOracle\t%.3f\n',t10(2*kmax+1:end))

%% Plot test statistic values
m=2000;n=2000;
k1=1;k2=1;
r = 0.2; b = 0.1;
xgen = @(m,n) sort(rand(m,n));
ygen = @(m,n) gen_unif_bump1(r,b,m,n); % Uniform -- with a step
tests = {@(x,y) HKS_projfree_test(x,y,k1), @(x,y) mmdTestPoly(x,y,k2), @kstestfun};
% tests = {@(x,y)  HKSHseptest(x,y,k1,0.05), @(x,y) mmdTestPoly(x,y,k2)};
ex2 = exp_roc(xgen,ygen,m,n,num,tests);
res2 = simulate(ex2);

legend_names={ sprintf('HKS k=%d',k1), sprintf('MMD-poly k=%d',k2), 'KS'};
plotTestStats(ex2,sprintf('%s_teststats.pdf',prefix),1:numel(tests),legend_names)
getpower(ex2,0.1)

%% HKS witness function

prefix = sprintf('%sExp_unif_bump1',dr);
h=0.1;
r=0.25;b=0.05;
m=500;n=500;
xgen = @(m,n) sort(rand(m,n));
ygen = @(m,n) gen_unif_bump1(h,m,n); % Uniform -- with triangular bumps

x=sort(xgen(m,1));
y=sort(ygen(n,1));
% y=sort(xgen(n,1));  % NULL
[z,idx] = merge_sort_idx(x,y);

k1=1; k2=1;
[tks,tpoly,wit1,wit2] = HKS_projfree_test(x,y,k1,false);

[tmmd,wit] = mmdTestPoly(x,y,k2);
% wit[1:m] is f(x), wit[m+1:m+n] is f(y)
witmmd = zeros(size(wit));
witmmd(idx) = wit(1:m);
witmmd(~idx) = wit((m+1):(m+n));

plot(z, wit1/mean(abs(wit1)),z,witmmd/mean(abs(witmmd)));
legend( sprintf('KS k=%d',k1), sprintf('MMD-poly k=%d',k2))


fprintf('%.2E %.2E\n',[max(abs(wit1)), max(abs(witmmd)); tks, tmmd]);

fprintf('\n')


%% test statistic plot in debug mode while running HKS_projfree_test
% plot(v,'LineWidth',2)
% xlabel('input index (in in z_i)','FontSize',18)
% ylabel('test statistic at z_i','FontSize',18)

%%

% function y = gen_unif_gt(b,m,n)
%     x = rand(m,n);
%     y = sort((x<=2/3) .* x + (x>2/3) .* ((b.*x+1).^(1/3)-1)./b);
% end

function olr = olrfun_pd(x,y,pd,pd2)
    logL0= sum(log(pdf(pd,[x;y])));
    logL1= sum(log(pdf(pd,x))) + sum(log(pdf(pd2,y)));
    olr=logL1-logL0;
end

function olr = olrfun_unif_bump0(x,y,r,b)
    logL0 = 0;
    logL1 = sum(log(pdf_bump0(r,b,y)));
    olr=logL1-logL0;
end
function olr = olrfun_3rdMoment_v1(x,y,m,n)
    logL0= 0.5*std_normal_logL( [x;y] ) + (m+n)*log(1/sqrt(2*pi));
    logL1= sum(-sqrt(2)*abs(y)) +n*log(1/sqrt(2))...
        +0.5*std_normal_logL(x)+m*log(1/sqrt(2*pi));
    olr=logL1-logL0;
end

function px = pdf_bump0(r,b,x)
    px = (x<=r).* 1 + (r<x & x<=r+b).* (1+b) + ...
        (r+b<x & x <= r+2*b) .* (1-b) + (r+2*b<x).*1;
end
function [] = plotpdfs(filename,x,pdf1,pdf2,lab1,lab2)
    figure
    plot(x,pdf1,x,pdf2,'LineWidth',2)
    lh=legend(lab1,lab2);
    set(lh,'fontsize',14)
    set(gca,'Position',[.05 .05 .9 .93])
    saveTightFig(gcf,filename);
end
