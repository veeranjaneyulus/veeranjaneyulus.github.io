function y = gen_unif_bump0(r,b,m,n)
    % pdf f
    % [0,r] -> 1
    % (r,r+b] -> 1.5
    % (r+b,r+2b] -> 0.5
    % (r+2b,1] -> 1
    
    x = rand(m,n);
    % y = F^{-1}(x), F is cdf
    % x <= r -> y=x
    % x in (r,r+1.5b] -> y=r + (x-r)/1.5
    % (r+1.5b,r+2b] -> y=r + b + (x-r)/0.5
    % (r+2b,1] -> y = x
    
    y = sort((x<=r | x>r+2*b) .*x + ...
        (r<x & x<=r+1.5*b) .* (r+(x-r)./1.5) + ...
        (r+1.5*b<x & x<=r+2*b) .* (r+(x-r)./0.5));
end
