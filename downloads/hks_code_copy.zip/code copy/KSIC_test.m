function [ KSIC ] = KSIC_test( x,y,k )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


n=length(x);
m=length(y);

best=0;

[x, idx1 ]=sort(x);
[y, idx2] =sort(y);


[z,idxx,idxy]=merge_sort_idx(x,y);
sz=length(z);
alpha=zeros(sz,1);


for i=k+2:sz % parallelizeable.
    alpha(i-1:i)=[0;1];
    Halpha=H_times(z,alpha,k);
    tmp1=zeros(n,1);
    tmp1(idx1)=Halpha(idxx);
    tmp1=tmp1(idx2);
    tmp=zeros(sz,1);
    tmp(idxy)=tmp1;
    tmp=1/n*tmp...
        -1/n/m*double(idxy)*(double(idxx)'*Halpha);
    
    tmp=HT_times(z,tmp,k);
    best=max(best,max(abs(tmp(k+2:end))));
end

KSIC=best;


end

% n=length(x);
% m=length(y);
% if m<n
%     n=m;
%     tmp=x(1:n);
%     x=y;
%     y=tmp;    
%     fprintf('Warning! Must be equal length')
% elseif m>n
%     fprintf('Warning! Must be equal length')
%     y=y(1:n);
% end
%     
% x=sort(x);
% y=sort(y);
% alpha=zeros(n,1);
% best=0;
% for i=k+2:n % parallelizeable.
%     alpha(i-1)=0;
%     alpha(i)=1;
%     tmp=H_times(x,alpha,k)-ones(n,1)*mean(H_times(x,alpha,k));
%     tmp=HT_times(y,tmp,k)/n;
%     best=max(best,max(abs(tmp(k+2:end))));
% end
% 
% KSIC=best;


