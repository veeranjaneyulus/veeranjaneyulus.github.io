
x=linspace(-10,10,1000);
laplace_cdf = 0.5 + sign(x) .* expcdf(abs(x))/2; % 0.5+fx/2 if x>0; 0.5-fx/2
plot(x,normcdf(x),'b',x, laplace_cdf, 'r')

