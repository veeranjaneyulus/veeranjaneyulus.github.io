function [ KSIC ] = KSIC_test_G( x,y,k )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here



n=length(x);
m=length(y);

best=0;

[x, idx1 ]=sort(x);
[y, idx2] =sort(y);

[z,idxx,idxy]=merge_sort_idx(x,y);
sz=length(z);
G=gen_trunc_pow_basis( z,k );


for i=k+2:sz % parallelizeable.
    alpha=sparse(i,1,1,sz,1);
    Halpha=G*alpha;
    tmp1=zeros(n,1);
    tmp1(idx1)=Halpha(idxx);
    tmp1=tmp1(idx2);
    tmp=zeros(sz,1);
    tmp(idxy)=tmp1;
    tmp=1/n*tmp...
        -1/n/m*double(idxy)*(double(idxx)'*Halpha);    tmp=G'*tmp;
    best=max(best,max(abs(tmp(k+2:end))));
end

KSIC=best;
end

