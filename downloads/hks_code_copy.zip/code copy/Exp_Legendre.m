

%%
kmax = 5;
m=500;n=500;num=1000;

runsim=true;
polyproj = false;
w = 0;
mmdpolydeg = [1:4, 6:2:12];
ksHsep_tests = cell(1,kmax);
mmdpoly_tests = cell(1,numel(mmdpolydeg));

for k=1:kmax
    ksHsep_tests{k} = @(x,y) HKS_projfree_test(x,y,k,polyproj);
   
end
for i=1:numel(mmdpolydeg)
    mmdpoly_tests{i} = @(x,y) mmdTestPoly(x,y,mmdpolydeg(i));
end

dr = 'NewPlots2/';

iprojfree = 1:kmax;
immdpoly = kmax + (1:numel(mmdpolydeg));
iks = max(immdpoly)+1;
immd = iks+1;
iolr = iks+2;

%% Uniform vs. Uniform + Legendre (9)

d=6; r=0.45; % r should be <= 1/2 for the densities to be >= 0
prefix = sprintf('%sExp_Legendre%d',dr,d);
dmax=7;
p7=[429,0,-693,0,315,0,-35,0]'/16;
p6=[0,231,0,315,0,105,0,-5/16]'./16; %legendreP(6,t)
p5=[0,0,63,0,-70,0,15,0]'./8;
p4=[0,0,0,35,0,-30,0,3]'./8;
p3=[0,0,0,0,5,0,-3,0]'./2;
p2=[0,0,0,0,0,3,0,-1]'./2;
p1 = [0,0,0,0,0,0,1,0]';
P = [p1,p2,p3,p4,p5,p6,p7];

pp=r.* (P(:,d+1)-P(:,d-1))./(2*d+1)+[zeros(size(P,1)-2,1); 1/2;1/2];

xgen = @(m,n) sort(2*rand(m,n)-1); % Uniform(-1,1)
ygen = @(m,n) gen_unif_legendre(pp,m,n);

olrfun = @(x,y) olrfun_legendre(d,r,x,y);
tests = [ksHsep_tests mmdpoly_tests {@kstestfun, @mmdfun, olrfun}];

if runsim
    ex = exp_roc(xgen,ygen,m,n,num,tests);
    res = simulate(ex);
    save(sprintf('%s.mat',prefix),'ex');
end

%%
load(sprintf('%s.mat',prefix),'ex')
cc = get_colors();

x=linspace(-1,1,200);

ppd = P(:,d);
Pd_at_x = legendreP(d,x)';
plotpdfs(sprintf('%s_pdf.pdf',prefix),x,0.5*ones(numel(x),1),...
    0.5+r*Pd_at_x, 'Uniform','Uniform + Legendre');

%%
legend_labs={'MMD-poly','KS','Oracle'};
plotHKSOnlyArrows(ex,sprintf('%s_mmdpoly.pdf',prefix),immdpoly,iks,iolr,legend_labs); % olr replaced by AD
legend_labs={'HKS','KS','Oracle'};
plotHKSOnlyArrows(ex,sprintf('%s_HKS.pdf',prefix),iprojfree,iks,iolr,legend_labs); % olr replaced by AD

%%
function [samples] = gen_unif_legendre(pp,m,n)
    A = rand(m,n);
    samples = zeros(m,n);
    for i=1:numel(A)
        ppnew = pp; 
        ppnew(end) = pp(end)-A(i);
        rr = roots(ppnew); % polynomial solver
        rr_real = rr(rr==real(rr));
        samples(i)= rr_real(abs(rr_real)<=1);
    end
end

function olr = olrfun_legendre(d,r,x,y)
    logL0 = -numel(y)*log(2);
    logL1 = sum(log(pdf_bump_legendre(d,r,y)));
    olr=logL1-logL0;
end
function [] = plotpdfs(filename,x,pdf1,pdf2,lab1,lab2)
    figure
    plot(x,pdf1,x,pdf2,'LineWidth',2)
    lh=legend(lab1,lab2);
    set(lh,'fontsize',24)
    set(gca,'Position',[.05 .05 .9 .93],'fontsize',24)
    
    saveTightFig(gcf,filename);
end

function px = pdf_bump_legendre(d,r,x)
    px = 1/2 + r*legendreP(d,x);
end
% function [samples] = gen_unif_legendre(d,r,m,n)
%     A = rand(m,n);
%     samples = zeros(m,n);
%     syms t
%     eq1 = r*(legendreP(d+1,t)-legendreP(d-1,t))/(2*d+1) + (t+1)/2;
%     parfor i=1:numel(A)
%         % samples(i) = invcdf(d,r,A(i));
%         samples(i) = invcdf(eq1,A(i));
%         
%     end
% end
% 
% function [s] = invcdf(eq1,q)
%     syms t
%     roots=vpasolve(eq1-q,t);
%     s = roots(roots==real(roots));
% end

