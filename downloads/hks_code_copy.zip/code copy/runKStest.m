%%
clear all

m=100;n=100;
H=0;
for i=1:1000
x=sort(randn(m,1));
y=sort(randn(n,1));

[h,p]=kstest2(x,y);
H=H+h;
end

H/1000