function [ H ] = gen_fallingfactobasis( x,k )
%gen_trunc_pow_basis:   Generate an evaluation of falling factorial basis with
%                       kth order
%----------------------------------------------------------------
% x:            input data points (sorted into ascending order)
% knots:        knots are assumed to be exactly the data points
% k:            order we want to consider
% H:            output basis matrix. Each column is the evaluations
%               of the truncated basis
%----------------------------------------------------------------

m=length(x);
H=zeros(m,m);

% Cumulative Sum implementation (fast)
I=eye(m);
for i=1:m
    H(:,i)=H_times(x,I(:,i),k);
end

% % Falling Factorial implementation (slow)
% H(:,1)=ones(m,1);
% for i=2:k+1
%     H(:,i)=H(:,i-1).*(x-x(i-1));
% end
% 
% mask=true(m,1);
% mask(1:k)=0;
% for i=k+2:m
%     j=i-k-1;
%     mask(i-1)=0;
%     H(mask,i)= prod(bsxfun(@minus,x(mask)*ones(1,k),x(i-k:i-1)'),2);  
% end

end

