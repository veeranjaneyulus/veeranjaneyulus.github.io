%% Conduct Runtime experiment
clear all
clc;

run('D:\Program Files\MATLAB\R2013a\toolbox\Wavelab850\startup.m')

%%

J_list=(4:20)';
nlist= 2.^J_list; %make it diadic length
%nlist=[16,20,50,100,200,500,1000];%,2000,5000,10000,20000, 50000]

num=length(nlist);
k=4;

rep=1;

fftlist=zeros(num,1);
ifftlist=zeros(num,1);

Hlist=zeros(num,1);
invHlist=zeros(num,1);

Glist=zeros(num,1);
invGlist=zeros(num,1);


Wavlist=zeros(num,1);
invWavlist=zeros(num,1);


pause(2);

for j=1:rep
for i=1:num
    n=nlist(i);
    x=(1:n)';
    y=rand(n,1);
    
    % FFT/inverse FFT
    tic;
    z=fft(y);
    fftlist(i)=fftlist(i)+toc;
    tic;
    yhat=ifft(z);
    ifftlist(i)=ifftlist(i)+toc;
    
    
    %Wavelet Transform/inverse Wavelet Transform
    tic
    z=FWT_PO(y,1,MakeONFilter('Symmlet',k));
    Wavlist(i)=Wavlist(i)+toc;    
    tic
    yhat=IWT_PO(z,1,MakeONFilter('Symmlet',k));
    invWavlist(i)=invWavlist(i)+toc; 

    %H Transform and its inverse
    tic
    z=invH_times( x,y,k );
    invHlist(i)=invHlist(i)+toc;
    tic;
    yhat=H_times(x,y,k);
    Hlist(i)=Hlist(i)+toc;
    
    
    %G Transform and its inverse
    if n<=2^13
        opt.LT=true;

        tic;
        G = gen_trunc_pow_basis( x,k );
        G=tril(G);
        z=linsolve(G,y,opt);

        invGlist(i)=invGlist(i)+toc;
        tic;
        G = gen_trunc_pow_basis( x,k );
        G=tril(G);
        yhat=G*z;
        Glist(i)=Glist(i)+toc;
    else
        invGlist(i)=nan;
        Glist(i)=nan;
    end
    fprintf('Solved for size %d\n',n);
end
end

fprintf('Done.\n');
    %%
    %semilogx(nlist(2:num),[Wavlist(2:num)./nlist(2:num) invHlist(2:num)./nlist(2:num)])
    figure(1)
    loglog(nlist,fftlist/rep,'.-m',...
    nlist,Wavlist/rep,'x-c',...
    nlist, invHlist/rep,'o--b',...
    nlist, invGlist/rep,'s-.r',...
    nlist,nlist*1e-6,'k-.',...
    nlist,nlist.^2*1e-6,'k:',...
    'linewidth',2);
    lh=legend('FFT','Wavelet','InvH','InvG','1e-6\timesn','1e-6\timesn^2')
    xlim([2^4-1,2^20+1]);
    ylim([10^-5,10])
    xlabel('Length of input vector');
    ylabel('Runtime (in seconds)')
    set(lh,'fontsize',14)
set(gca,'Position',[.1 .1 .88 .88])

%%
    figure(2)
    loglog(nlist,ifftlist/rep,'.-m',...
    nlist,invWavlist/rep,'x-c',...
    nlist, Hlist/rep,'o--b',...
    nlist, Glist/rep,'s-.r',...
    nlist,nlist*1e-6,'k-.',...
    nlist,nlist.^2*1e-6,'k:',...
    'linewidth',2);
    lh=legend('FFT','invWavelet','H','G','1e-6\timesn','1e-6\timesn^2')
    xlim([2^4-1,2^20+1]);
    ylim([10^-5,10])
    xlabel('Length of input vector');
    ylabel('Runtime (in seconds)')
        set(lh,'fontsize',14)
set(gca,'Position',[.1 .1 .88 .88])