%%
% tests for the variational problem with free knots.

t=0:0.01:1;
k=3;

x=[0.4,0.6];
y=[0.1,0.8];

if k~=0
    f=max(0,x(1)-t).^k + max(0,x(2)-t).^k - max(0,y(1)-t).^k  - max(0,y(2)-t).^k;
else
    f=double((x(1)-t)>0)+ double((x(2)-t)>0) - double((y(1)-t)>0) - double(y(2)-t>0);
end

plot(t,f)