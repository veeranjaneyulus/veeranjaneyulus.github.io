%% Testing independence

addpath('prec_rec')
addpath('btest-master')
addpath('mmd')
addpath('mmd_independence')
%% Generate data


m=100;n=100;
stats=0;
num=1000;

kmax=5;
eksG_list=zeros(num,kmax);
eksH_list=zeros(num,kmax);

pks_list=zeros(num,kmax);

ks_list=zeros(num,1);

mmd_list=zeros(num,1);%MMD_HSIC
l1_list=zeros(num,1); % L1 distance based test
info_list=zeros(num,1); % Mutual information based tests


% Generate data
% Multivariate normal
mu=[0,0];
Sigma0=[1,0;0,1];
Sigma=[1,0.2;0.2,1];

%%
params.q=4;
params.sigx=-1;
params.sigy=-1;
%%
parfor i=1:num

    
if i<=floor(num/2)
    R = mvnrnd(mu,Sigma0,n);
    x=R(:,1);y=R(:,2);
else
    R = mvnrnd(mu,Sigma,n);
    x=R(:,1);y=R(:,2);
end



for j=1:kmax
    k=j;
    eksH_list(i,j)=KSIC_test(x,y,k);
    eksG_list(i,j)=KSIC_test_G(x,y,k);
    
%    pks_list(i,j)=pKS_test( x,y,k);
    
end


%ks-test
ks=KSIC_test_G(x,y,0);
ks_list(i)=ks;

% L1 test
% 0.05 level doesn't matter. we are not using it.
[thresh,l1_list(i)] = GreGyoL1Test(x,y,0.05,params);
% Mutual info test
[thresh,info_list(i)] = likeRatioTest(x,y,0.05,params);


%alex's mmd HSIC

[thresh,mmd_list(i)] = hsicTestGamma(x,y,0.05,params);


%Oracle
olr_list(i)=-0.5*sum(sum([x,y]'.*(pinv(Sigma)*[x,y]')))+0.5*log(det(Sigma)) +sum(x.*x)/2+sum(y.*y)/2;

fprintf('Iteration %i done.\n',i);
end


%% FFKS plot with increasing k

figure(1)
target=[zeros(floor(num/2),1);ones(ceil(num/2),1)];
%[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1);
tpr1=[];tpr2=[];
fpr1=[];fpr2=[];
for i=1:kmax
%    [prec, tpr, fpr, thresh] = prec_rec(pks_list(:,i), target, 'plotROC',0);

[prec, tpr, fpr, thresh] = prec_rec(eksG_list(:,i), target, 'plotROC',0);
tpr1=[tpr1,tpr];fpr1=[fpr1,fpr];
[prec, tpr, fpr, thresh] = prec_rec(eksH_list(:,i), target, 'plotROC',0);
tpr2=[tpr2,tpr];fpr2=[fpr2,fpr];
end

hold off;
[prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',0);
plot(fpr,tpr,'k-.','linewidth',2);
hold on;
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',0);
plot(fpr,tpr,'m-','linewidth',2);

for i=1:kmax
plot(fpr1(:,i),tpr1(:,i),'r-','linewidth',2);
hold on;
plot(fpr2(:,i),tpr2(:,i),'b--','linewidth',2);
end

plot([0,1],[0,1],'k')
xlim([-0.01,1.01]);
ylim([-0.01,1.01]);
xlabel('False postive rate','fontsize',12);
ylabel('True postive rate','fontsize',12)
ti = get(gca,'TightInset');
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

hline = findobj(gcf, 'type', 'line');
lg=legend(hline([end-1,end-2,end-3,end]),{'0th order KS','kth order KS with G','kth order KS with H','Oracle'});
%lg=legend(hline([end-1,end-2,end-3,end]),{'0th order KS','kth order KS (with G)','kth order KS (with H)','Oracle'});
set(lg,'fontsize',12,'Location','best')
%
for i=1:kmax
    str=sprintf('k=%d',i);
%      txx=0.8-0.1*(i-1);
%      txy=0.7-0.1*(i-1);
     txx=0.8-0.1*(kmax-i);
     txy=0.7-0.1*(kmax-i);
    %arx=[txx,fpr1(floor(length(fpr1(:,i))/2),i)+0.05];
    arx=[txx,0.15];
    [val,IX]=min(abs(fpr1(:,i)-0.15));
    ary=[txy,tpr1(IX,i)];
    
text(txx,txy,str)
axPos = get(gca,'Position');
xMinMax = xlim;
yMinMax = ylim;
xAnnotation = axPos(1) + ((arx - xMinMax(1))/(xMinMax(2)-xMinMax(1))) * axPos(3);
yAnnotation = axPos(2) + ((ary - yMinMax(1))/(yMinMax(2)-yMinMax(1))) * axPos(4);
ah=annotation('arrow',xAnnotation,yAnnotation);
end

h=figure(1)
saveTightFigure(h,'Exp_KSIC.pdf');
%saveTightFigure(h,'Exp_pKS_4thMoment_Beta_vs_GP.pdf');

%saveTightFigure(h,'Exp_pKS_2ndMoment_normal_vs_t.pdf');

%% Compare with other independence tests

[prec, tpr, fpr, thresh] = prec_rec(eksH_list(:,1), target, 'plotROC',1, 'numThresh',1000,'style','--b');
[prec, tpr, fpr, thresh] = prec_rec(eksG_list(:,1), target, 'plotROC',1,'holdFigure',1,'style',':b');
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1,'holdFigure',1,'style','m-');
[prec, tpr, fpr, thresh] = prec_rec(l1_list, target, 'plotROC',1,'holdFigure',1,'style','c-');
[prec, tpr, fpr, thresh] = prec_rec(mmd_list, target, 'plotROC',1,'holdFigure',1,'style','g-');
%[prec, tpr, fpr, thresh] = prec_rec(kb_list, target, 'plotROC',1,'holdFigure',1);
[prec, tpr, fpr, thresh] = prec_rec(info_list, target, 'plotROC',1,'holdFigure',1,'style','r-');
[prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',1,'holdFigure',1,'style','k-.');
xlim([-0.01,1.01]);
ylim([-0.01,1.01]);

ti = get(gca,'TightInset');
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

hline = findobj(gcf, 'type', 'line');
set(hline(1:end-1),'linewidth',2)

xlabel('False postive rate','fontsize',12);
ylabel('True postive rate','fontsize',12)
lg=legend(hline([5,6,7,4,3,2,1]),{'0th order KS','1st order KS (with H)','1st order KS (with G)','L1','MMD','MutualInfo','Oracle'});
set(lg,'fontsize',12,'Location','best')

h=figure(1)
saveTightFigure(h,'Exp_KSIC_benchmark.pdf');
%saveTightFigure(h,'Exp_pBenchMark_2ndMoment_normal_vs_t.pdf');

