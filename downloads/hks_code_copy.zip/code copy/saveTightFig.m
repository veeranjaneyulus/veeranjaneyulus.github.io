function saveTightFig(h,outfilename)
%SAVETIGHTFIG Summary of this function goes here
%   Detailed explanation goes here

hfig = tightfig(h);
saveas(hfig, outfilename);

end

