

%% This script explores potential failure case for 
addpath('prec_rec')
addpath('btest-master')
addpath('mmd')
%% setting
m=100;n=100;
stats=0;
num=1000;
mu_diff=0.3;

kmax=5;
eksG_list=zeros(num,kmax);
eksH_list=zeros(num,kmax);

pks_list=zeros(num,kmax);

ks_list=zeros(num,1);
rs_list=zeros(num,1);%rank-sum
kb_list=zeros(num,1);%kernel B-test
mmd_list=zeros(num,1);%MMD
ad_list=zeros(num,1);
olr_list=zeros(num,1);% oracle likelihood ratio test



%pd = makedist('tLocationScale','nu',2);%default dof=5

pd = makedist('Exponential');

parfor i=1:num
x=sort(random(pd,m,1).*((rand(m,1)<0.5)-0.5)*2);
if i<=floor(num/2)
y=sort(random(pd,m,1).*((rand(m,1)<0.5)-0.5)*2);
else
y=sort(random(pd,m,1).*((rand(m,1)<0.5)-0.5)*2)+mu_diff;
end



for j=1:kmax
    k=j;
    [z,idxx,idxy]=merge_sort_idx(x,y);
    sz=length(z);
%     H = gen_fallingfactobasis( z,k );
%     eksH=1/n*max(abs(H(:,k+2:sz)'*(double(idxx)-double(idxy))));
    
    % compare KS-test, Gk-test and Hk-test
    vv=HT_times(z,double(idxx)-double(idxy),k);
    eksH=1/n*max(abs(vv(k+2:sz)));
    eksH_list(i,j)=eksH;
    
    G = gen_trunc_pow_basis( z,k );
    eksG=1/n*max(abs(G(:,k+2:sz)'*(double(idxx)-double(idxy))));
    eksG_list(i,j)=eksG;
    
    
    pks_list(i,j)=pKS_test( x,y,k);
    
end

%AD-test
ad = ADtestk([[x, ones(size(x))];[y, 2*ones(size(y))]]);
ad_list(i)=ad;

%ks-test
[h,p, ks]=kstest2(x,y);
ks_list(i)=ks;

%wilcoxon test
[p,h,rs] = ranksum(x,y);
rs_list(i)=-rs.ranksum;

%alex's mmd 

mmd = mmdTestBootStats(x,y,-1);
mmd_list(i)=mmd;

%Fast MMD: B-test
[h,p,kb]=btest(num2cell(x),num2cell(y));
kb_list(i)=kb;



%oracle likelihood ratio test
logL0= -sum(abs([x;y]));
logL1= -sum(abs(x))-sum(abs(y-mu_diff));
%logL1= std_normal_logL((y-mu_diff))+std_normal_logL(x);
olr=logL1-logL0;
olr_list(i)=olr;
fprintf('Iteration %i done.\n',i);
end



%% Compare Higher-Order KS and FFKS
target=[zeros(floor(num/2),1);ones(ceil(num/2),1)];
%[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1);
tpr1=[];tpr2=[];
fpr1=[];fpr2=[];
for i=1:kmax
[prec, tpr, fpr, thresh] = prec_rec(eksG_list(:,i), target, 'plotROC',0);
tpr1=[tpr1,tpr];fpr1=[fpr1,fpr];
[prec, tpr, fpr, thresh] = prec_rec(eksH_list(:,i), target, 'plotROC',0);
tpr2=[tpr2,tpr];fpr2=[fpr2,fpr];
end
hold off;
[prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',0);
plot(fpr,tpr,'k-.','linewidth',2);
hold on;
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',0);
plot(fpr,tpr,'k:','linewidth',2);

for i=1:kmax
plot(fpr1(:,i),tpr1(:,i),'r-','linewidth',2);
hold on;
plot(fpr2(:,i),tpr2(:,i),'b--','linewidth',2);
end

plot([0,1],[0,1],'k')
xlim([-0.01,1.01]);
ylim([-0.01,1.01]);
xlabel('False Postive Rate');
ylabel('True Postive Rate')

legend('Oracle (UMP)','0th Order KS','kth Order KS (with G)','kth Order FFKS (with H)');

%% Compare KS and higher order KS
target=[zeros(floor(num/2),1);ones(ceil(num/2),1)];
%[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1);
for i=1:kmax
[prec, tpr, fpr, thresh] = prec_rec(eksH_list(:,i), target, 'plotROC',1,'holdFigure',1, 'numThresh',1000);
end
xlim([-0.01,1.01]);
ylim([-0.01,1.01]);
legend('baseline','1stOrderFFKS','2ndOrderFFKS','3rdOrderFFKS','4thOrderFFKS','5thOrderFFKS');

%% Compare with other two-sample tests
figure(4)
[prec, tpr, fpr, thresh] = prec_rec(eksH_list(:,3), target, 'plotROC',1, 'numThresh',1000,'style','--b');
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1,'holdFigure',1,'style','k:');
[prec, tpr, fpr, thresh] = prec_rec(rs_list, target, 'plotROC',1,'holdFigure',1,'style','c-');
[prec, tpr, fpr, thresh] = prec_rec(mmd_list, target, 'plotROC',1,'holdFigure',1,'style','g-');
%[prec, tpr, fpr, thresh] = prec_rec(kb_list, target, 'plotROC',1,'holdFigure',1);
[prec, tpr, fpr, thresh] = prec_rec(ad_list, target, 'plotROC',1,'holdFigure',1,'style','r-');
[prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',1,'holdFigure',1,'style','k-.');
xlim([-0.01,1.01]);
ylim([-0.01,1.01]);
legend('baseline','3rdOrderFFKS','KS','RankSum','MMD','AD','Oracle');
