function [ B ] = gen_Bspline_basis( x,k,flag )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
% flag=1 selects to output the almost block-diagonal format for fast linear
% system solver.

% flag=0 selects matlab's sparse matrix representation as an output for
% fast matrix multiplication

% WARNING: it turns out that the block-diagonal format is much slower to
% solve than just 'sparse'. don't use it...
%-------------------------------------
cd Bsplines
%t=[repmat(x(1),ceil(k/2),1);x;repmat(x(end),floor(k/2),1)];
t=[zeros(ceil(k/2),1);x;(x(end)+1)*ones(floor(k/2),1)];
if flag==0 
    B=spcol(t,k,x,'sparse'); 
else
    B=spcol(t,k,x,'slvblk'); 
end
%B=bspline_basismatrix(k,t,x);
cd ..
end

