%% This script runs the Normal vs. t experiments
addpath('prec_rec')
addpath('btest-master')
%% setting
mlist=[10,20,50,100,200,300,400,500,600,700,800,1000];
NN=length(mlist);
m=100;n=100;
stats=0;
num=1000;
kmax=5;
mu_diff=0.3;

alphalist=[0.01,0.05, 0.1];
Na=length(alphalist);
eksG_powers=zeros(NN,Na,kmax);
eksH_powers=zeros(NN,Na,kmax);
ks_powers=zeros(NN,Na);
rs_powers=zeros(NN,Na);%rank-sum
kb_powers=zeros(NN,Na);%kernel B-test
mmd_powers=zeros(NN,Na);%MMD
ad_powers=zeros(NN,Na);
olr_powers=zeros(NN,Na);% oracle likelihood ratio test

%%
for iter=1:NN
    
    m=mlist(iter);n=mlist(iter);

eksG_list=zeros(num,kmax);
eksH_list=zeros(num,kmax);
ks_list=zeros(num,1);
rs_list=zeros(num,1);%rank-sum
kb_list=zeros(num,1);%kernel B-test
mmd_list=zeros(num,1);%MMD
ad_list=zeros(num,1);
olr_list=zeros(num,1);% oracle likelihood ratio test


pd = makedist('tLocationScale','nu',5);%default dof=5

parfor i=1:num

% x=sort(randn(m,1));
% if i<=floor(num/2)
% y=sort(randn(n,1));
% else
% y=sort(random(pd,n,1));
% end

x=sort(randn(m,1));
if i<=floor(num/2)
y=sort(randn(n,1));
else
y=sort(randn(n,1)+mu_diff);
end

for j=1:kmax
    k=j;
    [z,idxx,idxy]=merge_sort_idx(x,y);
    sz=length(z);


%     H = gen_fallingfactobasis( z,k );
%     eksH=1/n*max(abs(H(:,k+2:sz)'*(double(idxx)-double(idxy))));
    
    % compare KS-test, Gk-test and Hk-test
    vv=HT_times(z,double(idxx)-double(idxy),k);
    eksH=1/n*max(abs(vv(k+2:sz)));
    eksH_list(i,j)=eksH;
    
    G = gen_trunc_pow_basis( z,k );
    eksG=1/n*max(abs(G(:,k+2:sz)'*(double(idxx)-double(idxy))));
    eksG_list(i,j)=eksG;
end

%AD-test
ad = ADtestk([[x, ones(size(x))];[y, 2*ones(size(y))]]);
ad_list(i)=ad;

%ks-test
[h,p, ks]=kstest2(x,y);
ks_list(i)=ks;

%wilcoxon test
[p,h,rs] = ranksum(x,y);
rs_list(i)=-rs.ranksum;

%alex's mmd 

mmd = mmdTestBootStats(x,y,-1);
mmd_list(i)=mmd;

%Fast MMD: B-test
[h,p,kb]=btest(num2cell(x),num2cell(y));
kb_list(i)=kb;


%oracle likelihood ratio test
% logL0= std_normal_logL( [x;y] );
% logL1= std_normal_logL(x)+pd_logL(y,pd);
% olr=logL1-logL0;
% olr_list(i)=olr;

%oracle likelihood ratio test
logL0= std_normal_logL( [x;y] );
logL1= std_normal_logL((y-mu_diff))+std_normal_logL(x);
olr=logL1-logL0;
olr_list(i)=olr;
fprintf('Iteration %i done.\n',i);
end

%record the empirical power of the alpha level test
target=[zeros(floor(num/2),1);ones(ceil(num/2),1)];

for i=1:kmax
[prec, tpr, fpr, thresh] = prec_rec(eksG_list(:,i), target, 'plotROC',0);
eksG_powers(iter,:,i)=getPower(tpr,fpr,alphalist);
[prec, tpr, fpr, thresh] = prec_rec(eksH_list(:,i), target, 'plotROC',0);
eksH_powers(iter,:,i)=getPower(tpr,fpr,alphalist);
end

[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',0);
ks_powers(iter,:)=getPower(tpr,fpr,alphalist);

[prec, tpr, fpr, thresh] = prec_rec(rs_list, target, 'plotROC',0);
rs_powers(iter,:)=getPower(tpr,fpr,alphalist);
[prec, tpr, fpr, thresh] = prec_rec(kb_list, target, 'plotROC',0);
kb_powers(iter,:)=getPower(tpr,fpr,alphalist);
[prec, tpr, fpr, thresh] = prec_rec(ad_list, target, 'plotROC',0);
ad_powers(iter,:)=getPower(tpr,fpr,alphalist);
[prec, tpr, fpr, thresh] = prec_rec(mmd_list, target, 'plotROC',0);
mmd_powers(iter,:)=getPower(tpr,fpr,alphalist);

[prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',0);
olr_powers(iter,:)=getPower(tpr,fpr,alphalist);


end



%% Compare Higher-Order KS and FFKS
lv=2;
figure(1)
hold off;
plot(mlist,olr_powers(:,lv),'k-.',...
    mlist,ks_powers(:,lv),'k:','linewidth',2);
hold on;
for i=1:kmax
plot(mlist,eksG_powers(:,lv,i),'r-','linewidth',2);
hold on;
plot(mlist,eksH_powers(:,lv,i),'b--','linewidth',2);
end

xlabel('Sample size');
ylabel('Power of the test at level \alpha=0.05')

legend('Oracle','0th Order KS', 'kth Order KS (with G)','kth Order FFKS (with H)');

%% Compare Higher-Order KS and FFKS
figure(2)
plot(mlist,eksH_powers(:,lv,3),'b--',...
    mlist,ks_powers(:,lv),'k:',...
    mlist,rs_powers(:,lv),'c-',...
    mlist,mmd_powers(:,lv),'g-',...
    mlist,ad_powers(:,lv),'r-',...
    mlist,olr_powers(:,lv),'k-.','linewidth',2);
grid on

xlabel('Sample size');
ylabel('Power of the test at level \alpha=0.05')

legend('3rdOrderFFKS','KS','RankSum','MMD','AD','Oracle');
