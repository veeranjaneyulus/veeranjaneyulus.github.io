function [ z, alpha ] = G2T_times( x,y,k,t0 )
%G2T_times fast left multiplication with G_2^T
%  knots are x(1:end-1) and also t0
%  z_i = <y, (x-t_i)_+^k >    t = [t0, x_1,...x_{end-1}]
x = x(:);
y = y(:);
n=length(x);
if(n==0)
    z=0;
    alpha=0;
    return;
end
l=1; u=n-1; % first and last knots are x(l), x(u)

z = zeros(n,1); % output
alpha = zeros(u-l+1,k+1); % alpha(r,j) = < y, (x-x_{l+r-1})_+^{j-1} >
delta = diff(x);

% calculate the first element
z(1) = sum( (x-t0).^k .* y);

% Calculate the last row of alpha.. for knot x(u)
for j=1:k+1
    alpha(end,j) = sum(y(u:n).* (x(u:n)-x(u)).^(j-1));
end

choose = zeros(k+1); % for fast calculation
for i=1:k
    for j=0:i
        choose(i,j+1) = nchoosek(i,j);
    end
end

for r=(u-l+1):-1:2 % should be in decreasing order (r=knot number)
    % set alpha(r-1,:) from alpha(r,:)
    alpha(r-1,1) = alpha(r,1) + y(l+r-2);
    
    for j=2:(k+1)
        jp = j-1; % power in the truncated power basis function
        % alpha(r-1,j) = alpha(r,j)+ 
        %   \sum_{m=0}^{jp-1} (jp choose m) 
        %                 * (x_{l+r} - x_{l+r-1})^{jp-m}
        %                 * alpha(r,m+1)
        alpha(r-1,j) = alpha(r,j) + ...
            sum(choose(jp,1:jp) .* delta(l+r-2).^(jp:-1:1) .* alpha(r,1:jp));
    end
end

z(2:end) = alpha(:,k+1);

% first row of alpha
alpha = [zeros(1,k+1); alpha];
for j=0:k
    alpha(1,j+1) = sum( (x-t0).^j .* y);
end

end

