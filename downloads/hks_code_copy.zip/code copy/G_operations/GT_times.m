function [ z ] = GT_times( x,y,k )
%GT_times fast left multiplication with G^T
%   
x = x(:);
y = y(:);
n=length(x);
if mod(k,2)%odd
    t=x(floor((1+k)/2+1):floor(n-(1+k)/2));%knots
    l = (1+k)/2;
else
    t=x(floor(k/2+2):floor(n-k/2));
    l = k/2+1;
end

z = zeros(n,1);
alpha = zeros(n-k-1,k+1); % alpha(r,j) = < y, (x-x_{l+r})_+^{j-1} >
delta = diff(x);
% calculate first k+1 elements
for i=1:k+1
    z(i) = sum(x.^(i-1) .* y);
end
% Calculate the last row of alpha
for j=1:k+1
    u=l+n-k-1; % last knot is t(u)
    alpha(n-k-1,j) = sum(y(u:n).* (x(u:n)-x(u)).^(j-1));
end

choose = zeros(k+1); % for fast calculation
for i=1:k
    for j=0:i
        choose(i,j+1) = nchoosek(i,j);
    end
end

for r=(n-k-1):-1:2 % should be in decreasing order
    % set alpha(r-1,:) from alpha(r,:)
    alpha(r-1,1) = alpha(r,1) + y(l+r-1);
    
    for j=2:(k+1)
        jp = j-1; % power in the truncated power basis function
        % alpha(r-1,j) = alpha(r,j)+ 
        %   \sum_{m=0}^{jp-1} (jp choose m) 
        %                 * (x_{l+r} - x_{l+r-1})^{jp-m}
        %                 * alpha(r,m+1)
        alpha(r-1,j) = alpha(r,j) + ...
            sum(choose(jp,1:jp) .* delta(l+r-1).^(jp:-1:1) .* alpha(r,1:jp));
    end
end

z(k+2:end) = alpha(:,k+1);
end

