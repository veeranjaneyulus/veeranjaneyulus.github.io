kmax = 7;
m=50;n=50;num=1000;
polyproj=false; % do not project out polynomials
w=0;
runsim=true; % true -> run simulations, false -> only plot
[tests_noolr,ihks,iks] = alltests(kmax,polyproj);
iolr = numel(tests_noolr)+1;

cc = get_colors();
dr = 'NewPlots2/';

prefix = sprintf('%sExp_3rdMoment_v1%s_m%d',dr,expsuff,m);
pd = makedist('Normal');
pd2 = makedist('Exponential','mu',1/sqrt(2));
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n).*((rand(m,n)<0.5)-0.5)*2);
olrfun = @(x,y) olrfun_3rdMoment_v1(x,y,m,n);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end

load(sprintf('%s.mat',prefix),'ex')
legend_labs = {'Higher-order KS', 'KS','Oracle'};

%%
plotHKSOnly(ex,sprintf('%s_HKSOnly_projfree.pdf',prefix),ihks(1:5),iks,iolr,cc)

%%
function olr = olrfun_3rdMoment_v1(x,y,m,n)
    logL0= 0.5*std_normal_logL( [x;y] ) + (m+n)*log(1/sqrt(2*pi));
    logL1= sum(-sqrt(2)*abs(y)) +n*log(1/sqrt(2))...
        +0.5*std_normal_logL(x)+m*log(1/sqrt(2*pi));
    olr=logL1-logL0;
end


function [tests,ihks,iks] = alltests(kmax,polyproj)
    for k=1:kmax
        hks_tests{k} = @(x,y) HKS_projfree_test(x,y,3*k,polyproj);
    end
    tests = [ hks_tests {@kstestfun}];
    ihks = 1:kmax;
    iks = max(ihks)+1;
    
end

function [] = plotpdfs(filename,x,pdf1,pdf2,lab1,lab2)
    figure
    plot(x,pdf1,x,pdf2,'LineWidth',2)
    lh=legend(lab1,lab2);
    set(lh,'fontsize',16)
    set(gca,'Position',[.05 .05 .9 .93])
    saveTightFig(gcf,filename);
end
