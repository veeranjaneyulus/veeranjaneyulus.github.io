function [ z, idx1,idx2 ] = merge_sort_idx( x,y )
%merge_idx   this function merge to sorted number x1,...,x_n, y1,...,y_n2,
%sort them, then return the sorted list and the index mask of x and y
% addpath('merge_sorted')
[z,idx]=mergemex(x,y);
idx1=idx>0;
idx2=idx<0;

end

