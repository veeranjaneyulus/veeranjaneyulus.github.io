
% Normal vs Laplace with first three moments matching

% Why does the old test do so well?



dr = 'NewPlots2/';
%% HKS witness function
m=100;n=100;
prefix = sprintf('%sold_new_hks',dr);
pd = makedist('Normal');
pd2 = makedist('Exponential','mu',1/sqrt(2));
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n).*((rand(m,n)<0.5)-0.5)*2);

x=sort(xgen(m,1));
y=sort(ygen(n,1));
% y=sort(xgen(n,1));  % NULL
[z,idx] = merge_sort_idx(x,y);

useG = true;
polyproj = true;

k1=3; k2=3;
[tks,tpoly,wit1,~] = HKS_projfree_test(x,y,k1,polyproj);
[tks2,tpoly2,wit2,~] = pKS_test(x,y,k2,useG);

figure
subplot(2,1,1)
plot(z, wit1/mean(abs(wit1)),z,wit2/mean(abs(wit2)));
legend( sprintf('HKS new proj k=%d',k1), sprintf('HKS old k=%d',k2))
title('Alternative','FontSize',18)

subplot(2,1,2)
x=sort(xgen(m,1));
y=sort(xgen(n,1));
[z,idx] = merge_sort_idx(x,y);
[tks,tpoly,wit1,~] = HKS_projfree_test(x,y,k1,polyproj);
[tks2,tpoly2,wit2,~] = pKS_test(x,y,k2,useG);
plot(z, wit1/mean(abs(wit1)),z,wit2/mean(abs(wit2)));
title('Null','FontSize',18)
saveTightFig(gcf,sprintf('%s_witness.pdf',prefix))

fprintf('%.2E %.2E\n',[max(abs(wit1)), max(abs(wit2)); tks, tks2]);

fprintf('\n')


%% Plot test statistic values
m=100;n=100;num=1000;
k1=3;k2=3;
tests = {@(x,y) HKS_projfree_test(x,y,k1,polyproj), @(x,y) pKS_test(x,y,k2,useG), @kstestfun};
ex2 = exp_roc(xgen,ygen,m,n,num,tests);
res2 = simulate(ex2);

legend_names={ sprintf('HKS new proj k=%d',k1), sprintf('HKS old k=%d',k2), 'KS'};
figure
plotTestStats(ex2,sprintf('%s_teststats.pdf',prefix),1:numel(tests),legend_names)
getpower(ex2,0.1)


%% test G2T_times
nn = 300;
z = sort(rand(nn,1));
k = 2;
G = gen_trunc_pow_basis(z,k);

Gtv = zeros(numel(z));
for i=1:numel(z)
    v = zeros(numel(z),1); v(i) = 1;
    Gtv(:,i) = G2T_times(z,v,k,0);
end

idx=round(0.5*nn);
plot(z(k+1:nn),G(idx,k+1:nn),z(k+1:nn),Gtv(k+1:nn,idx))
legend('G direct','G indirect')

