
% B(t) = W(t) - t/T W(T)

% indepedent increments


n = 100;
nsim=5;
t = (0:n)'/n;
dt = diff(t);
for i=1:nsim
    delta = randn([numel(dt),1]) .* sqrt(dt);
    W = [0;cumsum(delta)];
    B = W - t.*W;
    plot(t,B,'LineWidth',1.5);hold on
end
set(gca,'FontSize',24)
saveTightFig(gcf, 'NewPlots2/brownian_bridge.pdf')
