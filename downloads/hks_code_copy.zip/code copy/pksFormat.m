%% FFKS plot with increasing k

figure(1)
target=[zeros(floor(num/2),1);ones(ceil(num/2),1)];
%[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1);
tpr1=[];tpr2=[];
fpr1=[];fpr2=[];
for i=1:kmax
[prec, tpr, fpr, thresh] = prec_rec(eksG_list(:,i), target, 'plotROC',0);
tpr1=[tpr1,tpr];fpr1=[fpr1,fpr];
[prec, tpr, fpr, thresh] = prec_rec(pks_list(:,i), target, 'plotROC',0);
tpr2=[tpr2,tpr];fpr2=[fpr2,fpr];
end
hold off;
[prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',0);
plot(fpr,tpr,'k-.','linewidth',2);
hold on;
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',0);
plot(fpr,tpr,'m-','linewidth',2);

for i=1:kmax
plot(fpr1(:,i),tpr1(:,i),'r-','linewidth',2);
hold on;
plot(fpr2(:,i),tpr2(:,i),'b--','linewidth',2);
end

plot([0,1],[0,1],'k')
xlim([-0.01,1.01]);
ylim([-0.01,1.01]);
xlabel('False postive rate','fontsize',12);
ylabel('True postive rate','fontsize',12)
ti = get(gca,'TightInset');
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

hline = findobj(gcf, 'type', 'line');
lg=legend(hline([end-1,end-2,end-3,end]),{'0th order pKS','kth order KS (with G)','kth order pKS (with H)','Oracle'});
set(lg,'fontsize',12,'Location','best')
%
for i=1:kmax
    str=sprintf('k=%d',i);
%      txx=0.8-0.1*(i-1);
%      txy=0.7-0.1*(i-1);
     txx=0.8-0.1*(kmax-i);
     txy=0.7-0.1*(kmax-i);
    %arx=[txx,fpr1(floor(length(fpr1(:,i))/2),i)+0.05];
    arx=[txx,0.15];
    [val,IX]=min(abs(fpr2(:,i)-0.15));
    ary=[txy,tpr2(IX,i)];
    
text(txx,txy,str)
axPos = get(gca,'Position');
xMinMax = xlim;
yMinMax = ylim;
xAnnotation = axPos(1) + ((arx - xMinMax(1))/(xMinMax(2)-xMinMax(1))) * axPos(3);
yAnnotation = axPos(2) + ((ary - yMinMax(1))/(yMinMax(2)-yMinMax(1))) * axPos(4);
ah=annotation('arrow',xAnnotation,yAnnotation);
end

h=figure(1)
saveTightFigure(h,'Exp1_KS_increase_k.pdf');

%% Compare with other two-sample tests

[prec, tpr, fpr, thresh] = prec_rec(pks_list(:,3), target, 'plotROC',1, 'numThresh',1000,'style','--b');
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1,'holdFigure',1,'style','m-');
[prec, tpr, fpr, thresh] = prec_rec(rs_list, target, 'plotROC',1,'holdFigure',1,'style','c-');
[prec, tpr, fpr, thresh] = prec_rec(mmd_list, target, 'plotROC',1,'holdFigure',1,'style','g-');
%[prec, tpr, fpr, thresh] = prec_rec(kb_list, target, 'plotROC',1,'holdFigure',1);
[prec, tpr, fpr, thresh] = prec_rec(ad_list, target, 'plotROC',1,'holdFigure',1,'style','r-');
[prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',1,'holdFigure',1,'style','k-.');
xlim([-0.01,1.01]);
ylim([-0.01,1.01]);

ti = get(gca,'TightInset');
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

hline = findobj(gcf, 'type', 'line');
set(hline(1:end-1),'linewidth',2)

xlabel('False postive rate','fontsize',12);
ylabel('True postive rate','fontsize',12)
lg=legend(hline([5,6,4,3,2,1]),{'0th order KS','3rd order KS','Rank-sum','MMD','Anderson-Darling','Oracle'});
set(lg,'fontsize',12,'Location','best')

h=figure(1)
saveTightFigure(h,'Exp2_Benchmark.pdf');

%% Samplesize vs. Power of the test: KS vs FFKS
lv=2;
figure(1)
hold off;
plot(mlist,ks_powers(:,lv),'m-','linewidth',2);
hold on;
for i=1:kmax
plot(mlist,eksG_powers(:,lv,i),'r-','linewidth',2);
hold on;
plot(mlist,eksH_powers(:,lv,i),'b--','linewidth',2);
end
plot(mlist,olr_powers(:,lv),'k-.','linewidth',2)

ylim([-0.01,1.01]);

xlabel('Sample size','fontsize',12);
ylabel('Power of the test at level \alpha=0.05','fontsize',12)

hline = findobj(gcf, 'type', 'line');
lg=legend(hline([end,end-1,end-2,1]),{'0th order KS', 'kth order KS (with G)','kth order KS (with H)','Oracle'});
ti = get(gca,'TightInset');
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);


for i=1:kmax
    str=sprintf('k=%d',i);
%    txx=[0.8-0.1*(i-1)]*1000;
%    txy=0.7-0.1*(i-1);
%    if i==1
%        txx=txx-200;
%    end
     txx=[0.8-0.1*(kmax-i)]*1000;
     txy=0.7-0.1*(kmax-i);
    %arx=[txx,fpr1(floor(length(fpr1(:,i))/2),i)+0.05];
    arx=[txx,200];
    [val,IX]=min(abs(mlist-200));
    ary=[txy,eksG_powers(IX,lv,i)];
    
text(txx,txy,str)

axPos = get(gca,'Position');
xMinMax = xlim;
yMinMax = ylim;
xAnnotation = axPos(1) + ((arx - xMinMax(1))/(xMinMax(2)-xMinMax(1))) * axPos(3);
yAnnotation = axPos(2) + ((ary - yMinMax(1))/(yMinMax(2)-yMinMax(1))) * axPos(4);
ah=annotation('arrow',xAnnotation,yAnnotation);
end
set(lg,'fontsize',12,'Location','best')

h=figure(1)
saveTightFigure(h,'Exp1_SampleSize_increase_k.pdf');
%% Samplesize vs. Power of the test: compare with other tests
figure(2)
hold off
plot(mlist,ks_powers(:,lv),'m-','linewidth',2);
hold on
plot(mlist,eksH_powers(:,lv,3),'b--',...
    mlist,rs_powers(:,lv),'c-',...
    mlist,mmd_powers(:,lv),'g-',...
    mlist,ad_powers(:,lv),'r-',...
    mlist,olr_powers(:,lv),'k-.','linewidth',2);
grid on


xlabel('Sample size','fontsize',12);
ylabel('Power of the test at level \alpha=0.05','fontsize',12)

ti = get(gca,'TightInset');
set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

lg=legend('0th order KS','3rd order KS','Rank-sum','MMD','Anderson-Darling','Oracle');
set(lg,'fontsize',12,'Location','best')

h=figure(2)
saveTightFigure(h,'Exp_SampleSize2.pdf');

%%
h=figure(1)
saveTightFigure(h,'Exp1_illustration.pdf');
h=figure(2)
saveTightFigure(h,'Exp2_illustration.pdf');
h=figure(3)
saveTightFigure(h,'Exp3_illustration.pdf');

%%
h=figure(2)
saveTightFigure(h,'RuntimeHG.pdf');