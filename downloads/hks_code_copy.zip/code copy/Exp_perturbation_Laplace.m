kmax = 5;
m=500;n=500;num=1000;
legend_labs = {'HKS','MMD.poly','KS','Oracle'};
runsim=true;
polyproj = false;
centerhks = false;
w = 0;
mmdpolydeg = [1:5, 8:4:20];
hksodddeg =1:2:kmax;
hks_tests = cell(1,kmax);
mmdpoly_tests = cell(1,numel(mmdpolydeg));

for k=1:kmax
    hks_tests{k} = @(x,y) HKS_projfree_test(x,y,k,polyproj,centerhks);
end
for i=1:numel(mmdpolydeg)
    mmdpoly_tests{i} = @(x,y) mmdTestPoly(x,y,mmdpolydeg(i));
end

dr = 'NewPlots2/';

cc = get_colors();

%%
prefix = sprintf('%sExp_pert_laplace_pin0',dr);
pd = makedist('Uniform');
pd2 = makedist('Beta','a',1,'b',2);


r=9/10; b=5;
up = r +  (1/b) * ((1 + 3*b*(1-r))^(1/3) - 1);
xgen = @(m,n) sort(rand(m,n) .* up); % Uniform [0,up]
ygen = @(m,n) gen_unif_gt(r,b,m,n); % Uniform -- with alignment to a g_t
olrfun = @(x,y) olrfun_unif_gt(r,b,x,y);
tests = [hks_tests {@kstestfun, olrfun}];
iprojfree=1:numel(hks_tests);
iks=iprojfree(end)+1;
iolr=iks+1;

if runsim
    ex = exp_roc(xgen,ygen,m,n,num,tests);
    res = simulate(ex);
    save(sprintf('%s.mat',prefix),'ex');
end

load(sprintf('%s.mat',prefix),'ex')

x=linspace(0,up,500);
pdf1=ones(numel(x),1)./up;
pdf2=pdf_gt(r,b,x);
lab1='p';lab2='q';
plotpdfs(sprintf('%s_pdf.pdf',prefix),x,pdf1,pdf2,lab1,lab2);
plotHKSOnly(ex,sprintf('%s_HKS.pdf',prefix),iprojfree,iks,iolr,cc)
hold off

function olr = olrfun_pd(x,y,pd,pd2)
    logL0= sum(log(pdf(pd,[x;y])));
    logL1= sum(log(pdf(pd,x))) + sum(log(pdf(pd2,y)));
    olr=logL1-logL0;
end

function olr = olrfun_unif_gt(r,b,x,y)
    logL1 = sum(log(pdf_gt(r,b,y)));
    olr = logL1;
end
function [] = plotpdfs(filename,x,pdf1,pdf2,lab1,lab2)
    figure
    plot(x,pdf1,'b-','LineWidth',2); hold on
    plot(x,pdf2,'r:','LineWidth',2)
    lh=legend(lab1,lab2);
    set(lh,'fontsize',18,'Location','best')
    set(gca,'Position',[.05 .05 .9 .93],'FontSize',18)
    
    ylim([0,2])
    saveTightFig(gcf,filename);
end
