
%%
kmax = 5;
m=100;n=100;num=1000;

legend_labs = {'HKS','MMD.poly','KS','Oracle'};
runsim=false;
polyproj = false;
centerhks = false;
w = 0;
mmdpolydeg = [1:5, 8:4:20];
hksodddeg =1:2:kmax;
hks_tests = cell(1,kmax);
mmdpoly_tests = cell(1,numel(mmdpolydeg));

for k=1:kmax
    hks_tests{k} = @(x,y) HKS_projfree_test(x,y,k,polyproj,centerhks);
end
for i=1:numel(mmdpolydeg)
    mmdpoly_tests{i} = @(x,y) mmdTestPoly(x,y,mmdpolydeg(i));
end

dr = 'NewPlots2/permnull_';

iprojfree = 1:kmax;
immdpoly = kmax + (1:numel(mmdpolydeg));
iks = max(immdpoly)+1;
immd = iks+1;
ienergy = iks+2;
iad = iks+3;
iolr = iks+4;

cc = get_colors();

%% Uniform vs. Uniform + bump k=0 (step function bump)
prefix = sprintf('%sExp_unif_bump0_pin0',dr);

m=500;n=500;
r = 0.2; b = 0.1;
xgen = @(m,n) sort(rand(m,n));
ygen = @(m,n) gen_unif_bump0(r,b,m,n); % Uniform -- with a step
olrfun = @(x,y) olrfun_unif_bump0(x,y,r,b);
tests = [hks_tests mmdpoly_tests {@kstestfun, @mmdfun, @energyDist, @adtestfun, olrfun}];
if runsim
    ex = exp_roc(xgen,ygen,m,n,num,tests);
    res = simulate(ex);
    save(sprintf('%s.mat',prefix),'ex');
end

load(sprintf('%s.mat',prefix),'ex')

% plot pdfs
figure
lab1='p';lab2='q';
stairs([0,r,r+b,r+2*b,1]',ones(5,1), 'b-','LineWidth',2);hold on
stairs([0,r,r+b,r+2*b,1]',[1,1+b,1-b,1,1]','r:','LineWidth',2)
lh=legend(lab1,lab2);
set(lh,'fontsize',18)
yl=ylim;
ylim([yl(1)*0.97 yl(2)])
set(gca,'Position',[.05 .05 .9 .93])
set(gca,'FontSize',18)

saveTightFig(gcf,sprintf('%s_pdf.pdf',prefix));
hold off

% plot ROC curves
plotHKSOnly(ex,sprintf('%s_HKS.pdf',prefix),iprojfree,iks,iolr,cc)
plotKSOthers(ex,sprintf('%s_benchmark_mmdpoly.pdf',prefix),iprojfree,immdpoly,iks,ienergy,immd,iad,iolr,mmdpolydeg,1:kmax,cc)
plotHKSOthers(ex,sprintf('%s_benchmark_projfree_allhksroc.pdf',prefix),iprojfree(hksodddeg),iks,ienergy,immd,iad,iolr,hksodddeg,cc)
plotBestHKSOthers(ex,sprintf('%s_benchmark_projfree_besthksroc.pdf',prefix),iprojfree,iks,ienergy,immd,iad,iolr,1:kmax,cc)
hold off


%% Uniform vs Uniform + steps at the tails
prefix = sprintf('%sExp_unif_tail_bump0',dr);

m=500;n=500;num=1000;
b=0.15; h=0.25;
xgen = @(m,n) sort(2*rand(m,n)-1);
ygen = @(m,n) gen_unif_tail_bump0(b,h,m,n); % Uniform -- with steps of height h and width b at the tails
olrfun = @(x,y) olrfun_unif_tail_bump0(x,y,b,h);
tests = [hks_tests mmdpoly_tests {@kstestfun, @mmdfun, @energyDist, @adtestfun, olrfun}];
if runsim
    ex = exp_roc(xgen,ygen,m,n,num,tests);
    res = simulate(ex);
    save(sprintf('%s.mat',prefix),'ex');
end


load(sprintf('%s.mat',prefix),'ex')
% plot pdfs
figure
lab1='p';lab2='q';
stairs([-1,-1+b,1-b,1]', 0.5*ones(4,1), 'b-','LineWidth',2);hold on
stairs([-1,-1+b,1-b,1]',[0.5-h,0.5,0.5+h,0.5+h]','r:','LineWidth',2)
lh=legend(lab1,lab2);
set(lh,'fontsize',18,'Location','best')
yl=ylim;
ylim([0 1])
set(gca,'Position',[.05 .05 .9 .93])
set(gca,'FontSize',18)

saveTightFig(gcf,sprintf('%s_pdf.pdf',prefix));
hold off

% plot ROC curves
plotHKSOnly(ex,sprintf('%s_HKS.pdf',prefix),iprojfree,iks,iolr,cc)
plotKSOthers(ex,sprintf('%s_benchmark_mmdpoly.pdf',prefix),iprojfree,immdpoly,iks,ienergy,immd,iad,iolr,mmdpolydeg,1:kmax,cc)
plotHKSOthers(ex,sprintf('%s_benchmark_projfree_allhksroc.pdf',prefix),iprojfree(hksodddeg),iks,ienergy,immd,iad,iolr,hksodddeg,cc)
plotBestHKSOthers(ex,sprintf('%s_benchmark_projfree_besthksroc.pdf',prefix),iprojfree,iks,ienergy,immd,iad,iolr,1:kmax,cc)
hold off



%% Uniform vs Uniform + g_t
prefix = sprintf('%sExp_unif_gt',dr);
m=2000;n=2000;num=1000;
r=9/10; b=5;
up = r +  (1/b) * ((1 + 3*b*(1-r))^(1/3) - 1);
xgen = @(m,n) sort(rand(m,n) .* up); % Uniform [0,up]
ygen = @(m,n) gen_unif_gt(r,b,m,n); % Uniform -- with alignment to a g_t
olrfun = @(x,y) olrfun_unif_gt(r,b,up,x,y);
tests = [hks_tests mmdpoly_tests {@kstestfun, @mmdfun, @energyDist, @adtestfun, olrfun}];

if runsim
    ex = exp_roc(xgen,ygen,m,n,num,tests);
    res = simulate(ex);
    save(sprintf('%s.mat',prefix),'ex');
end

load(sprintf('%s.mat',prefix),'ex')

x=linspace(0,up,500);
pdf1=ones(numel(x),1)./up;
pdf2=pdf_gt(r,b,x);
lab1='p';lab2='q';
plotpdfs(sprintf('%s_pdf.pdf',prefix),x,pdf1,pdf2,lab1,lab2);
% plot ROC curves
plotHKSOnly(ex,sprintf('%s_HKS.pdf',prefix),iprojfree,iks,iolr,cc)
plotKSOthers(ex,sprintf('%s_benchmark_mmdpoly.pdf',prefix),iprojfree,immdpoly,iks,ienergy,immd,iad,iolr,mmdpolydeg,1:kmax,cc)
plotHKSOthers(ex,sprintf('%s_benchmark_projfree_allhksroc.pdf',prefix),iprojfree(hksodddeg),iks,ienergy,immd,iad,iolr,hksodddeg,cc)
plotBestHKSOthers(ex,sprintf('%s_benchmark_projfree_besthksroc.pdf',prefix),iprojfree,iks,ienergy,immd,iad,iolr,1:kmax,cc)
hold off

%% Uniform vs. Uniform + bump k=1 (triangle function bump)
prefix = sprintf('%sExp_unif_bump1',dr);
pd = makedist('Uniform');
pd2 = makedist('Beta','a',1,'b',2);

h=0.2;r=0.2;b=0.05;
m=5000;n=5000;num=100;
xgen = @(m,n) sort(rand(m,n));
ygen = @(m,n) gen_unif_bump12(r,b,m,n); % Uniform -- with triangular bumps
olrfun = @(x,y) olrfun_pd(x,y,pd,pd2); %TODO change this!!
tests = [hks_tests mmdpoly_tests {@kstestfun, @mmdfun, @energyDist, @adtestfun, olrfun}];
iprojfree=1:numel(hks_tests);
iks=iprojfree(end)+1;
iolr=iks+1;
if runsim
    ex = exp_roc(xgen,ygen,m,n,num,tests);
    res = simulate(ex);
    save(sprintf('%s.mat',prefix),'ex');
end

load(sprintf('%s.mat',prefix),'ex')

% plot pdfs
figure
lab1='p';lab2='q';
plot(linspace(0,1,5), ones(5,1), 'b-','LineWidth',2);hold on
plot([0,r,r+b/2,r+b,r+3*b/2,r+2*b,1]',[1,1,2,1,0,1,1]','r:','LineWidth',2)
lh=legend(lab1,lab2);
set(lh,'fontsize',18,'Location','best')
set(gca,'Position',[.05 .05 .9 .93])
set(gca,'FontSize',18)

saveTightFig(gcf,sprintf('%s_pdf.pdf',prefix));
hold off

plotHKSOnly(ex,sprintf('%s_HKS.pdf',prefix),iprojfree,iks,iolr,cc)
plotKSOthers(ex,sprintf('%s_benchmark_mmdpoly.pdf',prefix),iprojfree,immdpoly,iks,ienergy,immd,iad,iolr,mmdpolydeg,1:kmax,cc)
plotHKSOthers(ex,sprintf('%s_benchmark_projfree_allhksroc.pdf',prefix),iprojfree(hksodddeg),iks,ienergy,immd,iad,iolr,hksodddeg,cc)
plotBestHKSOthers(ex,sprintf('%s_benchmark_projfree_besthksroc.pdf',prefix),iprojfree,iks,ienergy,immd,iad,iolr,1:kmax,cc)
hold off


function olr = olrfun_unif_bump0(x,y,r,b)
    logL0 = sum(log((1+pdf_bump0(r,b,[x;y]))/2 )); % \sum_{i} log (p(z_i)+q(z_i))/2 where z=[x;y]
    logL1 = 0+sum(log(pdf_bump0(r,b,y)));
    olr=logL1-logL0;
end

function olr = olrfun_unif_tail_bump0(x,y,b,h)
    logL0 = sum(log((0.5+pdf_tail_bump0(b,h,[x;y]))/2 ));
    logL1 = numel(x)*0.5 + sum(log(pdf_tail_bump0(b,h,y)));
    olr=logL1-logL0;
end

function olr = olrfun_unif_gt(r,b,up,x,y)
    logL0 = sum(log((1/up+pdf_gt(r,b,[x;y]))/2 ));
    logL1 = numel(x)/up + sum(log(pdf_gt(r,b,y)));
    olr = logL1-logL0;
end


function px = pdf_bump0(r,b,x)
    px = (x<=r).* 1 + (r<x & x<=r+b).* (1+b) + ...
        (r+b<x & x <= r+2*b) .* (1-b) + (r+2*b<x).*1;
end
function px = pdf_tail_bump0(b,h,x)
    px = (x<=-1+b).* (.5-h) +  ...
        (-1+b<x & x<=1-b).* 0.5 + ...
        (1-b < x) .* (.5+h);
end

% pdf: 1 on [0,r],
%     (1+b(t-r))^2 on (r,r+c] 
function px = pdf_gt(r,b,x)
    px = (x<=r) .* 1 + (x>r) .* (1+b.*(x-r)).^2;
end



function [] = plotpdfs(filename,x,pdf1,pdf2,lab1,lab2)
    figure
    plot(x,pdf1,'b-','LineWidth',2); hold on
    plot(x,pdf2,'r:','LineWidth',2)
    lh=legend(lab1,lab2);
    set(lh,'fontsize',18,'Location','best')
    set(gca,'Position',[.05 .05 .9 .93],'FontSize',18)
    
    ylim([0,2])
    saveTightFig(gcf,filename);
end



