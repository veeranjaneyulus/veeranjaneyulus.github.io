kmax = 8;
m=100;n=100;num=1000;
[tests_noolr,iproj,iprojfree,immdpoly,iks,irs,immd,iad] = alltests(kmax, 0);
iolr = numel(tests_noolr)+1;

% dr = 'NewPlots2/tmp_proj_';
% prefix = sprintf('%sExp_1stMoment_v1',dr);
% mu_diff = 0.2;
% xgen = @(m,n) normrnd(0,1,m,n);
% ygen = @(m,n) normrnd(0,1,m,n) + mu_diff;
% olrfun = @(x,y) sum(y.^2) - sum( (y-mu_diff).^2);
% tests = [tests_noolr {olrfun}];
% ex = exp_roc(xgen,ygen,m,n,num,tests);
% res = simulate(ex);
% plotHKS(ex,sprintf('%s_HKS.pdf',prefix),iproj,iprojfree,iolr,iks)


dr = 'NewPlots2/tmp_proj_';
prefix = sprintf('%sExp_3rdMoment_v1',dr);
pd = makedist('Normal');
pd2 = makedist('Exponential','mu',1/sqrt(2));
xgen = @(m,n) sort(random(pd,m,n));
ygen = @(m,n) sort(random(pd2,m,n).*((rand(m,n)<0.5)-0.5)*2);
olrfun = @(x,y) olrfun_3rdMoment_v1(x,y,m,n);
tests = [tests_noolr {olrfun}];
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex);

%%
pp = getpower(ex,0.1);
[pp(1:kmax), pp(kmax+1:2*kmax), pp(2*kmax+1:3*kmax)]
pp(3*kmax+1:end)


function olr = olrfun_2ndMoment_v1(x,y,sigma_diff)
    logL0= std_normal_logL( [x;y] );
    logL1= std_normal_logL((y))/(1+sigma_diff)^2 ...
        + length(y)*log(1/(1+sigma_diff)) +std_normal_logL(x);
    olr=logL1-logL0;
end

function olr = olrfun_3rdMoment_v1(x,y,m,n)
    logL0= 0.5*std_normal_logL( [x;y] ) + (m+n)*log(1/sqrt(2*pi));
    logL1= sum(-sqrt(2)*abs(y)) +n*log(1/sqrt(2))...
        +0.5*std_normal_logL(x)+m*log(1/sqrt(2*pi));
    olr=logL1-logL0;
end

function [tests,iproj,iprojfree,immdpoly,iks,irs,immd,iad] = alltests(kmax,w)
    for k=1:kmax
        proj_tests{k} = @(x,y) HKSHseptest(x,y,k,w);
        projfree_tests{k} = @(x,y) HKS_projfree_test(x,y,k);
        mmdpoly_tests{k} = @(x,y) mmdTestPoly(x,y,k);
    end
    for k=1:kmax
        proj_tests{k} = @(x,y) HKSHseptest(x,y,k,0);
        projfree_tests{k} = @(x,y) HKS_projfree_test(x,y,k,true);
        mmdpoly_tests{k} = @(x,y) polyres_testfun(mmdpoly_tests{k},k,x,y);
    end
    tests = [proj_tests projfree_tests mmdpoly_tests ...
        {@kstestfun, @ranksumfun, @mmdfun, @adtestfun}];
    iproj=1:kmax;
    iprojfree=iproj+kmax;
    immdpoly=iprojfree+kmax;
    iks=max(immdpoly)+1; 
    irs=iks+1; 
    immd=iks+2;
    iad=iks+3;
end
