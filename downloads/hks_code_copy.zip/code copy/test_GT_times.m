% 

n = 10;
ks = [0,1,2,3,4];
x = sort(rand(n,1));
y = rand(n,1);
G2 = zeros(n);
I = eye(n);
for k=ks
    fprintf('k=%d ',k);
    G = gen_trunc_pow_basis(x,k);
    for i=1:numel(x)
        G2(:,i) = GT_times(x,I(:,i),k);
    end
    s1 = sum(sum( (G'-G2).^2 ));
    s2 = sum( (G'*y - GT_times(x,y,k)).^2);
    if s1+s2 < 1e-16
        fprintf('passed %g\n',s1+s2);
    else
        fprintf('failed %g\n',s1+s2);
    end
end