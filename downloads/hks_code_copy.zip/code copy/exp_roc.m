
% methods: G,G2,PG2, H,H2,PH2 (G2 = last n-k-1 cols of G, PG2 is G2 projected onto polynomials)
%           cdf transformed G,H
%           AD, MMD, RS

classdef exp_roc < handle
%EXP_ROC Summary of this class goes here
%   Detailed explanation goes here

properties
    m
    n
    num % number of simulations
    tests % list of tests to run
    xgen % generates mx1 vectors from distribution P
    ygen % generates nx1 vectors from distribution Q
    testres
end

methods
    function obj = exp_roc(xgen,ygen,m,n,num,tests)
        obj.xgen = xgen;
        obj.ygen = ygen;
        obj.m = m;
        obj.n = n;
        obj.num = num;
        obj.tests = tests;
    end

    function res = simulate(o)
        xgen1 = o.xgen;
        ygen1 = o.ygen;
        num1 = o.num;
        m1 = o.m;
        n1 = o.n;
        tests1 = o.tests;
        halfnum=floor(num1/2);
        res0 = zeros(halfnum,numel(o.tests));
        res1 = zeros(halfnum,numel(o.tests));
        parfor i=1:floor(num1/2)
            x = sort(feval(xgen1,m1,1));
            y = sort(feval(ygen1,n1,1));
            
            z = [x;y]; z = z(randperm(numel(z)));
            xp = sort(z(1:m1));
            yp = sort(z( (m1+1): end));

            res0i = zeros(numel(tests1),1);
            res1i = zeros(numel(tests1),1);
            for it=1:numel(tests1)
                res0i(it) = feval(tests1{it},xp,yp); % null stat
                res1i(it) = feval(tests1{it},x,y); % alternative stat
            end
            res0(i,:) = res0i;
            res1(i,:) = res1i;
            % fprintf('Iteration %i done.\n',i);
        end
        res = [res0;res1];
        o.testres = res;
        fprintf('Simulation done.\n')
    end

    function res = simulate_nullp(o)
        res = zeros(o.num,numel(o.tests));
        xgen1 = o.xgen;
        ygen1 = o.ygen;
        num1 = o.num;
        m1 = o.m;
        n1 = o.n;
        tests1 = o.tests;
        
        for i=1:o.num
            x = sort(feval(xgen1,m1,1));
            if (i<=floor(num1/2))
                y = sort(feval(xgen1,n1,1));
            else
                y = sort(feval(ygen1,n1,1));
            end
            
            resi = zeros(numel(tests1),1);

            for it=1:numel(tests1)
                resi(it) = feval(tests1{it},x,y);
            end
            res(i,:) = resi;
            % fprintf('Iteration %i done.\n',i);
        end
        o.testres = res;
        fprintf('Simulation done.\n')
    end

    function [] = plotHKSOne(o,filename,iHsep,iolr,iks) 
        % Plots just iHsep test roc curves
        kmax = numel(iHsep);
        ksHsep_list = reshape(o.testres(:,iHsep),[o.num,numel(iHsep)]);
        olr_list = o.testres(:,iolr);
        ks_list  = o.testres(:,iks);
        
        figure
        target=[zeros(floor(o.num/2),1);ones(ceil(o.num/2),1)];
        tprHs=[];
        fprHs=[];
        
        for i=1:kmax % just calculate tpr,fpr - don't plot
            [prec, tpr, fpr, thresh] = prec_rec(ksHsep_list(:,i), target, 'plotROC',0);
            tprHs=[tprHs,tpr];fprHs=[fprHs,fpr];
        end
        hold off;
        % Start plotting now
        [prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',0);
        plot(fpr,tpr,'k-.','linewidth',2);
        hold on;
        [prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',0);
        plot(fpr,tpr,'m-','linewidth',2);

        for i=1:kmax
            plot(fprHs(:,i),tprHs(:,i),'b-','linewidth',2);
            hold on
        end

        
        plot([0,1],[0,1],'k')
        xlim([-0.01,1.01]);
        ylim([-0.01,1.01]);
        xlabel('False positive rate','fontsize',18);
        ylabel('True positive rate','fontsize',18);
        ti = get(gca,'TightInset');
        set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

        hline = findobj(gcf, 'type', 'line');
        lg=legend(hline([end-1,end-2,end]),{'KS k=0','KS k>0','Oracle'});
        set(lg,'fontsize',16,'Location','best')
        %
        alpha=0.1;
        for i=1:kmax % arrows at \alpha=0.15 level for H only.
            str=sprintf('k=%d',i);
            txx=0.8-0.1*(kmax-i);
            txy=0.7-0.1*(kmax-i);
            arx=[txx,alpha];
            [val,IX]=min(abs(fprHs(:,i)-alpha));
            ary=[txy,tprHs(IX,i)];

            tt = text(txx,txy,str);
            tt.FontSize=18;
            axPos = get(gca,'Position');
            xMinMax = xlim;
            yMinMax = ylim;
            xAnnotation = axPos(1) + ((arx - xMinMax(1))/(xMinMax(2)-xMinMax(1))) * axPos(3);
            yAnnotation = axPos(2) + ((ary - yMinMax(1))/(yMinMax(2)-yMinMax(1))) * axPos(4);
            ah=annotation('arrow',xAnnotation,yAnnotation);
        end

        saveTightFig(gcf, filename);
        
    end
    function [] = plotHKS(o,filename,imeth1,imeth2,iks,iolr,legend_labs)
        % H2,PH2,Hsep,olr,KS
        
        if(nargin<7)
            legend_labs = {'KS','KS.T','KS.pfree','Oracle'};
        end
            
        
        kmax = numel(imeth1);
        meth1_list = reshape(o.testres(:,imeth1),[o.num,numel(imeth1)]);
        meth2_list = reshape(o.testres(:,imeth2),[o.num,numel(imeth2)]);
        olr_list = o.testres(:,iolr);
        ks_list  = o.testres(:,iks);
        
        
        target=[zeros(floor(o.num/2),1);ones(ceil(o.num/2),1)];
        tprCdf=[];tprHs=[];
        fprCdf=[];fprHs=[];
        
        for i=1:numel(imeth1)
            [prec, tpr, fpr, thresh] = prec_rec(meth1_list(:,i), target, 'plotROC',0);
            tprHs=[tprHs,tpr];fprHs=[fprHs,fpr];
        end
        for i=1:numel(imeth2)
            [prec, tpr, fpr, thresh] = prec_rec(meth2_list(:,i), target, 'plotROC',0);
            tprCdf=[tprCdf,tpr];fprCdf=[fprCdf,fpr];
        end
        % hold off;
        % Plot ROC curves
        figure
        [prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',0);
        plot(fpr,tpr,'k-.','linewidth',2);
        hold on;
        [prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',0);
        plot(fpr,tpr,'m-','linewidth',2);

        for i=1:numel(imeth1)
            plot(fprHs(:,i),tprHs(:,i),'r:','linewidth',2); hold on;
        end
        for i=1:numel(imeth2)
            plot(fprCdf(:,i),tprCdf(:,i),'g:','linewidth',2); hold on;
        end

        plot([0,1],[0,1],'k')
        xlim([-0.01,1.01]);
        ylim([-0.01,1.01]);
        xlabel('False positive rate','fontsize',12);
        ylabel('True positive rate','fontsize',12)
        ti = get(gca,'TightInset');
        set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

        hline = findobj(gcf, 'type', 'line');
%         lg=legend(hline([end-1,end-2,end-3,end]),{'KS','KS.T','KS.cdf','Oracle'});
        lg=legend(hline([end-2,end-2-numel(imeth1),end-1,end]),legend_labs);
        set(lg,'fontsize',12,'Location','best')
        
        alpha=0.1;
        %
        for i=1:numel(imeth1) % arrows at \alpha=0.1 level for H only.
            str=sprintf('k=%d',i);
            txx=0.8-0.05*(kmax-i);
            txy=0.7-0.05*(kmax-i);
            arx=[txx,alpha];
            [val,IX]=min(abs(fprHs(:,i)-alpha));
            ary=[txy,tprHs(IX,i)];

            text(txx,txy,str)
            axPos = get(gca,'Position');
            xMinMax = xlim;
            yMinMax = ylim;
            xAnnotation = axPos(1) + ((arx - xMinMax(1))/(xMinMax(2)-xMinMax(1))) * axPos(3);
            yAnnotation = axPos(2) + ((ary - yMinMax(1))/(yMinMax(2)-yMinMax(1))) * axPos(4);
            ah=annotation('arrow',xAnnotation,yAnnotation);
        end

        saveTightFig(gcf, filename);
    end
    
    
    function [] = plotRocAll(o,filename,iH2,iPH2,iHsep,iks,irs,immd,iad,iolr)
        %% Compare with other two-sample tests
        
        res = o.testres;
        
        kmax = numel(iHsep);
        ksH2_list = reshape(o.testres(:,iH2),[o.num,numel(iH2)]);
        pks_list = reshape(o.testres(:,iPH2),[o.num,numel(iPH2)]);
        ksHsep_list = reshape(o.testres(:,iHsep),[o.num,numel(iHsep)]);
        
        % For higher-order tests, pick the k for which the power is highest
        alpha=0.1; 
        target=[zeros(floor(o.num/2),1);ones(ceil(o.num/2),1)];
        pp = zeros(kmax,3);
        
        for i=1:kmax % same kmax for all tests
            
            [prec, tpr, fpr, thresh] = prec_rec(ksH2_list(:,i), target, 'plotROC',0);
            [val,IX]=min(abs(fpr-alpha)); pp(i,1) = tpr(IX);
            [prec, tpr, fpr, thresh] = prec_rec(pks_list(:,i), target, 'plotROC',0);
            [val,IX]=min(abs(fpr-alpha)); pp(i,2) = tpr(IX);
            [prec, tpr, fpr, thresh] = prec_rec(ksHsep_list(:,i), target, 'plotROC',0);
            [val,IX]=min(abs(fpr-alpha)); pp(i,3) = tpr(IX);
        end
        [vals,ik] = max(pp);
        fprintf('max power attained for k=\n'); disp(ik)
        
        [prec, tpr, fpr, thresh] = prec_rec(ksH2_list(:,ik(1)), target, 'plotROC',1, 'numThresh',1000,'style','g:');
        [prec, tpr, fpr, thresh] = prec_rec(pks_list(:,ik(2)), target, 'plotROC',1, 'holdFigure',1,'style','b:');
        [prec, tpr, fpr, thresh] = prec_rec(ksHsep_list(:,ik(3)), target, 'plotROC',1,'holdFigure',1,'style','r:');
        [prec, tpr, fpr, thresh] = prec_rec(res(:,iks), target, 'plotROC',1,'holdFigure',1,'style','m-');
        [prec, tpr, fpr, thresh] = prec_rec(res(:,irs), target, 'plotROC',1,'holdFigure',1,'style','y-');
        [prec, tpr, fpr, thresh] = prec_rec(res(:,immd), target, 'plotROC',1,'holdFigure',1,'style','g-');
        [prec, tpr, fpr, thresh] = prec_rec(res(:,iad), target, 'plotROC',1,'holdFigure',1,'style','r-');
        [prec, tpr, fpr, thresh] = prec_rec(res(:,iolr), target, 'plotROC',1,'holdFigure',1,'style','k-.');
        xlim([-0.01,1.01]);
        ylim([-0.01,1.01]);

        ti = get(gca,'TightInset');
        set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

        hline = findobj(gcf, 'type', 'line');
        set(hline(1:end-1),'linewidth',2)

        xlabel('False positive rate','fontsize',18);
        ylabel('True positive rate','fontsize',18)
        labH2 = sprintf('KS (k=%d)',ik(1));
        labp = sprintf('TH (k=%d)',ik(2));
        labHs = sprintf('TH+T2 (k=%d)',ik(3));
        
        %hline reverse order in which the lines were made
        lg=legend(hline([5,8,7,6,4,3,2,1]),{'KS',labH2,labp,labHs,'Rank-sum','MMD','Anderson-Darling','Oracle'});
        set(lg,'fontsize',16,'Location','best')

        saveTightFig(gcf,filename);
    end
    
    % 
    function [] = plotKSOthers(o,filename,ihks,immdpoly,iks,ienergy,immd,iad,iolr,mmdpolydeg,hksdeg,cc)
        %% Compare HKS with other two-sample tests
        % Includes MMD-poly, only best KS, MMD-poly
        
        res = o.testres;
        
%         if ~exist('mmdpolydeg','var')
%             mmdpolydeg = 1:numel(immdpoly);
%         end
%         if ~exist('cc','var')
%             cc = get_colors();
%         end
        hks_list = reshape(o.testres(:,ihks),[o.num,numel(ihks)]);
        
        target=[zeros(floor(o.num/2),1);ones(ceil(o.num/2),1)];
        
        t10 = getpower(o,0.1);
        [val,imax] = max(t10(immdpoly));
        immdpolymax = immdpoly(imax);
        mmdpolydegmax = mmdpolydeg(imax);
        [val,ihksmax] = max(t10(ihks));
        hksdegmax = hksdeg(ihksmax);
        
%         [prec, tpr, fpr, thresh] = prec_rec(ksHsep_list(:,1), target, 'plotROC',1, 'numThresh',1000,'style','g-');
%         [prec, tpr, fpr, thresh] = prec_rec(ksHsep_list(:,2), target, 'plotROC',1, 'holdFigure',1,'style','b-');
%         [prec, tpr, fpr, thresh] = prec_rec(ksHsep_list(:,3), target, 'plotROC',1,'holdFigure',1,'style','r-');
        figure
        plot([0,1],[0,1],'k'); hold on
        [prec, tpr, fpr, thresh] = prec_rec(res(:,iks), target, 'plotROC',0, 'numThresh',1000);
        plot(fpr,tpr,'-','color',cc.ks); hold on
        [prec, tpr, fpr, thresh] = prec_rec(hks_list(:,ihksmax), target, 'plotROC',0);
        plot(fpr,tpr,'-','color',cc.hks(end,:)); hold on
        % [prec, tpr, fpr, thresh] = prec_rec(res(:,irs), target, 'plotROC',1,'holdFigure',1,'style','c-');
        [prec, tpr, fpr, thresh] = prec_rec(res(:,immdpolymax), target, 'plotROC',0);
        plot(fpr,tpr,'-.','color',cc.poly); hold on
        [prec, tpr, fpr, thresh] = prec_rec(res(:,immd), target, 'plotROC',0);
        plot(fpr,tpr,'--x','color',cc.rbf); hold on
        [prec, tpr, fpr, thresh] = prec_rec(res(:,ienergy), target, 'plotROC',0);
        plot(fpr,tpr,':','color',cc.energy); hold on
        [prec, tpr, fpr, thresh] = prec_rec(res(:,iad), target, 'plotROC',0);
        plot(fpr,tpr,'-+','color',cc.ad); hold on
        [prec, tpr, fpr, thresh] = prec_rec(res(:,iolr), target, 'plotROC',0);
        plot(fpr,tpr,'-.','color',cc.olr); hold on
        xlim([-0.01,1.01]);
        ylim([-0.01,1.01]);

        ti = get(gca,'TightInset');
        set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

        hline = findobj(gcf, 'type', 'line');
        set(hline(1:end-1),'linewidth',2)

        xlabel('False positive rate','fontsize',18);
        ylabel('True positive rate','fontsize',18);
        
        %hline reverse order in which the lines were made
%         lg=legend(hline([6,9,8,7,5,4,3,2,1]),{'KS k=0','KS k=1', 'KS k=2', 'KS k=3','Rank-sum',...
%             sprintf('MMD-poly d=%d',mmdpolydegmax),...
%             'MMD-RBF','Anderson-Darling','Oracle'});
        lg=legend(hline([7,6,5,4,3,2,1]),{'KS k=0',...
            sprintf('KS k=%d',hksdegmax),...
            sprintf('MMD-poly d=%d',mmdpolydegmax),...
            'MMD-RBF','Energy Distance', 'Anderson-Darling','Oracle'});
        set(lg,'fontsize',16,'Location','best')

        saveTightFig(gcf,filename); hold off
    end
    
    % No MMD-polynomial, put ROC curves for KS k=0:kmax separately
    function [] = plotHKSOthers(o,filename,ihks,iks,ienergy,immd,iad,iolr,hksdeg,cc)
        %% Compare HKS with other two-sample tests
        
        res = o.testres;
        
        hks_list = reshape(o.testres(:,ihks),[o.num,numel(ihks)]);
        
        target=[zeros(floor(o.num/2),1);ones(ceil(o.num/2),1)];
        
%         [prec, tpr, fpr, thresh] = prec_rec(ksHsep_list(:,1), target, 'plotROC',1, 'numThresh',1000,'style','g-');
%         [prec, tpr, fpr, thresh] = prec_rec(ksHsep_list(:,2), target, 'plotROC',1, 'holdFigure',1,'style','b-');
%         [prec, tpr, fpr, thresh] = prec_rec(ksHsep_list(:,3), target, 'plotROC',1,'holdFigure',1,'style','r-');
        figure
        plot([0,1],[0,1],'k'); hold on
        [~, tpr, fpr, ~] = prec_rec(res(:,iks), target, 'plotROC',0, 'numThresh',1000);
        plot(fpr,tpr,'-','color',cc.ks); hold on
        legend_hks=cell(numel(ihks),1);
        for i=1:numel(ihks)
            [~, tpr, fpr, ~] = prec_rec(hks_list(:,i), target, 'plotROC',0);
            plot(fpr,tpr,'-','color',cc.hks(i,:)); hold on;
            legend_hks{i}=sprintf('KS k=%d',hksdeg(i));
        end
        [~, tpr, fpr, ~] = prec_rec(res(:,immd), target, 'plotROC',0);
        plot(fpr,tpr,'--x','color',cc.rbf); hold on
        [prec, tpr, fpr, thresh] = prec_rec(res(:,ienergy), target, 'plotROC',0);
        plot(fpr,tpr,':','color',cc.energy); hold on
        [prec, tpr, fpr, thresh] = prec_rec(res(:,iad), target, 'plotROC',0);
        plot(fpr,tpr,'-+','color',cc.ad); hold on
        [prec, tpr, fpr, thresh] = prec_rec(res(:,iolr), target, 'plotROC',0);
        plot(fpr,tpr,'-.','color',cc.olr); hold on
        xlim([-0.01,1.01]);
        ylim([-0.01,1.01]);

        ti = get(gca,'TightInset');
        set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

        hline = findobj(gcf, 'type', 'line');
        set(hline(1:end-1),'linewidth',2)

        xlabel('False positive rate','fontsize',18);
        ylabel('True positive rate','fontsize',18);
        
        %hline reverse order in which the lines were made
%         lg=legend(hline([6,9,8,7,5,4,3,2,1]),{'KS k=0','KS k=1', 'KS k=2', 'KS k=3','Rank-sum',...
%             sprintf('MMD-poly d=%d',mmdpolydegmax),...
%             'MMD-RBF','Anderson-Darling','Oracle'});
        lg=legend(hline(flip(1:end-1)),{'KS k=0',...
            legend_hks{:},...
            'MMD-RBF','Energy Distance', 'Anderson-Darling','Oracle'});
        set(lg,'fontsize',16,'Location','best')

        saveTightFig(gcf,filename); hold off
    end

    function [] = plotBestHKSOthers(o,filename,ihks,iks,ienergy,immd,iad,iolr,hksdeg,cc)
        %% Compare HKS with other two-sample tests
        
        res = o.testres;
        
        hks_list = reshape(o.testres(:,ihks),[o.num,numel(ihks)]);
        
        target=[zeros(floor(o.num/2),1);ones(ceil(o.num/2),1)];
        
        t10 = getpower(o,0.1);
        [val,ihksmax] = max(t10(ihks));
        hksdegmax = hksdeg(ihksmax);
        
        figure
        plot([0,1],[0,1],'k'); hold on
        [~, tpr, fpr, ~] = prec_rec(res(:,iks), target, 'plotROC',0, 'numThresh',1000);
        plot(fpr,tpr,'-','color',cc.ks); hold on
        [prec, tpr, fpr, thresh] = prec_rec(hks_list(:,ihksmax), target, 'plotROC',0, 'numThresh',1000);
        plot(fpr,tpr,'-','color',cc.hks(min(ihksmax,size(cc.hks,1)),:)); hold on
        [~, tpr, fpr, ~] = prec_rec(res(:,immd), target, 'plotROC',0);
        plot(fpr,tpr,'--x','color',cc.rbf); hold on
        [prec, tpr, fpr, thresh] = prec_rec(res(:,ienergy), target, 'plotROC',0);
        plot(fpr,tpr,':','color',cc.energy); hold on
        [prec, tpr, fpr, thresh] = prec_rec(res(:,iad), target, 'plotROC',0);
        plot(fpr,tpr,'-+','color',cc.ad); hold on
        [prec, tpr, fpr, thresh] = prec_rec(res(:,iolr), target, 'plotROC',0);
        plot(fpr,tpr,'-.','color',cc.olr); hold on
        xlim([-0.01,1.01]);
        ylim([-0.01,1.01]);

        ti = get(gca,'TightInset');
        set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

        hline = findobj(gcf, 'type', 'line');
        set(hline(1:end-1),'linewidth',2)

        xlabel('False positive rate','fontsize',18);
        ylabel('True positive rate','fontsize',18);
        
        lg=legend(hline(flip(1:end-1)),{'KS k=0',...
            sprintf('KS k=%d',hksdegmax),...
            'MMD-RBF','Energy Distance', 'Anderson-Darling','Oracle'});
        set(lg,'fontsize',16,'Location','best')

        saveTightFig(gcf,filename); hold off
    end


    function [] = plotroc(o,filename,testids,legend_names)
        res = o.testres;
        target=[zeros(floor(o.num/2),1);ones(ceil(o.num/2),1)];
        [prec, tpr, fpr, thresh] = prec_rec(res(:,testids(1)), target, 'plotROC',0,'holdFigure',0,'numThresh',1000);
        plot(fpr,tpr,'linewidth',2); hold on
        for i=testids(2:end)
            [prec, tpr, fpr, thresh] = prec_rec(res(:,testids(i)), target, 'plotROC',0);
            plot(fpr,tpr,'linewidth',2); hold on
        end
        
        xlim([-0.01,1.01]);
        ylim([-0.01,1.01]);

        ti = get(gca,'TightInset');
        set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

        hline = findobj(gcf, 'type', 'line');
        
        xlabel('False positive rate','fontsize',12);
        ylabel('True positive rate','fontsize',12)
        lg=legend(hline([2,1]), legend_names);
        set(lg,'fontsize',12,'Location','best')

        saveTightFig(gcf,filename);
    end
    
    function [] = plotTestStats(o,filename,testids,legend_names)
        
        res_sc = zscore(o.testres);
        n2 = floor(o.num/2);
        colors = distinguishable_colors(numel(testids));
        figure
        for i=1:numel(testids)
            scatter(i*ones(n2,1), res_sc(1:n2,testids(i)),'.','MarkerEdgeColor',colors(i,:)); hold on;
        end
        for i=1:numel(testids)
            scatter(i*ones(3,1), quantile(res_sc(1:n2,testids(i)),[.25,.5,.75]),'k+');hold on
            scatter((i+0.1)*ones(o.num-n2,1), res_sc(n2+1:end,testids(i)),'.','MarkerEdgeColor',colors(i,:)); hold on;
            scatter((i+0.1)*ones(3,1), quantile(res_sc(n2+1:end,testids(i)),[.25,.5,.75]),'k+');hold on
        end
        hold off
        
        legend(legend_names)
        
        saveTightFig(gcf,filename);
    end
    
    function [] = plotHKSOnlyArrows(o,filename,ihks,iks,iolr,legend_labs)
        
        if(nargin<6)
            legend_labs = {'Higher-order KS', 'KS','Oracle'};
        end
        
        kmax = numel(ihks);
        meth1_list = reshape(o.testres(:,ihks),[o.num,numel(ihks)]);
        olr_list = o.testres(:,iolr);
        ks_list  = o.testres(:,iks);
        
        
        target=[zeros(floor(o.num/2),1);ones(ceil(o.num/2),1)];
        tprCdf=[];tprHs=[];
        fprCdf=[];fprHs=[];
        
        for i=1:numel(ihks)
            [prec, tpr, fpr, thresh] = prec_rec(meth1_list(:,i), target, 'plotROC',0);
            tprHs=[tprHs,tpr];fprHs=[fprHs,fpr];
        end
        
        % hold off;
        % Plot ROC curves
        figure
        [prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',0);
        plot(fpr,tpr,'k-.','linewidth',2);
        hold on;
        [prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',0);
        plot(fpr,tpr,'m-','linewidth',2);

        for i=1:numel(ihks)
            plot(fprHs(:,i),tprHs(:,i),'r:','linewidth',2); hold on;
        end
        
        plot([0,1],[0,1],'k')
        xlim([-0.01,1.01]);
        ylim([-0.01,1.01]);
        xlabel('False positive rate','fontsize',18);
        ylabel('True positive rate','fontsize',18)
        ti = get(gca,'TightInset');
        set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

        hline = findobj(gcf, 'type', 'line');
%         lg=legend(hline([end-1,end-2,end-3,end]),{'KS','KS.T','KS.cdf','Oracle'});
        lg=legend(hline([end-2,end-1,end]),legend_labs);
        set(lg,'fontsize',16,'Location','best')
        
        alpha=0.1;
        %
        for i=1:numel(ihks) % arrows at \alpha=0.1 level for H only.
            str=sprintf('k=%d',i);
            txx=0.8-0.05*(kmax-i);
            txy=0.7-0.05*(kmax-i);
            arx=[txx,alpha];
            [val,IX]=min(abs(fprHs(:,i)-alpha));
            ary=[txy,tprHs(IX,i)];

            text(txx,txy,str)
            axPos = get(gca,'Position');
            xMinMax = xlim;
            yMinMax = ylim;
            xAnnotation = axPos(1) + ((arx - xMinMax(1))/(xMinMax(2)-xMinMax(1))) * axPos(3);
            yAnnotation = axPos(2) + ((ary - yMinMax(1))/(yMinMax(2)-yMinMax(1))) * axPos(4);
            ah=annotation('arrow',xAnnotation,yAnnotation);
        end

        saveTightFig(gcf, filename);
    end
  
    
    function [] = plotHKSOnly(o,filename,ihks,iks,iolr,cc)
        
        kmax = numel(ihks);
        meth1_list = reshape(o.testres(:,ihks),[o.num,numel(ihks)]);
        olr_list = o.testres(:,iolr);
        ks_list  = o.testres(:,iks);
        
        target=[zeros(floor(o.num/2),1);ones(ceil(o.num/2),1)];
        tprHs=[]; fprHs=[];
        
        for i=1:numel(ihks)
            [prec, tpr, fpr, thresh] = prec_rec(meth1_list(:,i), target, 'plotROC',0);
            tprHs=[tprHs,tpr];fprHs=[fprHs,fpr];
        end
        
        % Plot ROC curves
        figure
        legend_labs = cell(numel(ihks)+2,1);
        [prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',0);
        plot(fpr,tpr,'-','color',cc.ks,'linewidth',2); hold on;
        legend_labs{1} = 'KS k=0';
        for i=1:numel(ihks)
            plot(fprHs(:,i),tprHs(:,i),'-','color',cc.hks(i,:),'linewidth',2); hold on;
            legend_labs{i+1} = sprintf('KS k=%d',i);
        end
        [prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',0);
        plot(fpr,tpr,'-.','color',cc.olr,'linewidth',2);
        legend_labs{kmax+2} = 'Oracle';
        
        plot([0,1],[0,1],'k')
        xlim([-0.01,1.01]);
        ylim([-0.01,1.01]);
        xlabel('False positive rate','fontsize',18);
        ylabel('True positive rate','fontsize',18)
        ti = get(gca,'TightInset');
        set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

        hline = findobj(gcf, 'type', 'line');
        lg=legend(hline(end-(0:(kmax+1))),legend_labs);
        set(lg,'fontsize',16,'Location','best')

        saveTightFig(gcf, filename);
    end
    
    function [] = plotHKSMMD(o,filename,ihks,iks,immdpoly,iolr,hksdeg,mmddeg,cc)
        res = o.testres;
        
        hks_list = reshape(o.testres(:,ihks),[o.num,numel(ihks)]);
        mmd_list = reshape(o.testres(:,immdpoly),[o.num,numel(immdpoly)]);
        
        target=[zeros(floor(o.num/2),1);ones(ceil(o.num/2),1)];
        
        figure
        plot([0,1],[0,1],'k'); hold on
        [~, tpr, fpr, ~] = prec_rec(res(:,iks), target, 'plotROC',0, 'numThresh',1000);
        plot(fpr,tpr,'-','color',cc.ks); hold on
        legend_hks=cell(1,numel(ihks));
        for i=1:numel(ihks)
            [~, tpr, fpr, ~] = prec_rec(hks_list(:,i), target, 'plotROC',0);
            plot(fpr,tpr,'-','color',cc.hks(i,:)); hold on;
            legend_hks{i}=sprintf('KS k=%d',hksdeg(i));
        end
        legend_mmd=cell(1,numel(immdpoly));
        for i=1:numel(immdpoly)
            [~, tpr, fpr, ~] = prec_rec(mmd_list(:,i), target, 'plotROC',0);
            plot(fpr,tpr,':','color',cc.hks(i,:)); hold on; % same color but dots
            legend_mmd{i}=sprintf('MMD d=%d',mmddeg(i));
        end
        [~, tpr, fpr, ~] = prec_rec(o.testres(:,iolr), target, 'plotROC',0);
        plot(fpr,tpr,'-.','color',cc.olr); hold on;
            
        xlim([-0.01,1.01]);
        ylim([-0.01,1.01]);

        ti = get(gca,'TightInset');
        set(gca,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

        hline = findobj(gcf, 'type', 'line');
        set(hline(1:end-1),'linewidth',2)

        xlabel('False positive rate','fontsize',18);
        ylabel('True positive rate','fontsize',18);
        
        lg=legend(hline(flip(1:end-1)), [{'KS k=0'} legend_hks legend_mmd {'Oracle'}]);
        set(lg,'fontsize',16,'Location','best')

        saveTightFig(gcf,filename); hold off
    end
    
    function test_pow = getpower(o,alpha)
        test_pow = zeros(numel(o.tests),1);
        res = o.testres;
        target=[zeros(floor(o.num/2),1);ones(ceil(o.num/2),1)];
        for i=1:numel(o.tests)
            [prec, tpr, fpr, thresh] = prec_rec(res(:,i), target, 'plotROC',0);
            [val,IX]=min(abs(fpr-alpha)); 
            test_pow(i) = tpr(IX);
        end
    end
end
end
