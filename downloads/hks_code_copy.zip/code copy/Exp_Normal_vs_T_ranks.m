%% This script runs the Normal vs. t experiments
addpath('prec_rec')
addpath('btest-master')
addpath('mmd')
%% setting
m=200;n=200;
stats=0;
num=100; %1000
kmax=5;
eksG_list=zeros(num,kmax);
eksH_list=zeros(num,kmax);

pks_list=zeros(num,kmax);
pksr_list=zeros(num,kmax); % pKS after transforming data to their ranks

ks_list=zeros(num,1);
rs_list=zeros(num,1);%rank-sum
kb_list=zeros(num,1);%kernel B-test
mmd_list=zeros(num,1);%MMD
ad_list=zeros(num,1);

olr_list=zeros(num,1);% oracle likelihood ratio test


pd = makedist('tLocationScale','nu',3);%default dof=5
for i=1:num % parfor

x=sort(randn(m,1));
if i<=floor(num/2)
y=sort(randn(n,1));
else
y=sort(random(pd,n,1)) - 0.3;
end

[z,idxx,idxy]=merge_sort_idx(x,y);
sz=length(z);

rx = find(idxx) ./ sz;
ry = find(idxy) ./ sz;

for j=1:kmax
    k=j;


%     H = gen_fallingfactobasis( z,k );
%     eksH=1/n*max(abs(H(:,k+2:sz)'*(double(idxx)-double(idxy))));
    
    % compare KS-test, Gk-test and Hk-test
    vv=HT_times(z,double(idxx)-double(idxy),k);
    eksH=1/n*max(abs(vv(k+2:sz)));
    eksH_list(i,j)=eksH;
    
    G = gen_trunc_pow_basis( z,k );
    eksG=1/n*max(abs(G(:,k+2:sz)'*(double(idxx)-double(idxy))));
    eksG_list(i,j)=eksG;
    
    pks_list(i,j)=pKS_test( x,y,k);
		
		% pKS with ranks of data
		pksr_list(i,j)=pKS_test(rx,ry,k);
    
end

%AD-test
ad = ADtestk([[x, ones(size(x))];[y, 2*ones(size(y))]]);
ad_list(i)=ad;

%ks-test
[h,p, ks]=kstest2(x,y);
ks_list(i)=ks;

%wilcoxon test
[p,h,rs] = ranksum(x,y);
rs_list(i)= abs(rs.zval);

%alex's mmd 

mmd = mmdTestBootStats(x,y,-1);
mmd_list(i)=mmd;

%Fast MMD: B-test
[h,p,kb]=btest(num2cell(x),num2cell(y));
kb_list(i)=kb;

%oracle likelihood ratio test
logL0= std_normal_logL( [x;y] );
logL1= std_normal_logL(x)+pd_logL(y,pd);
olr=logL1-logL0;
olr_list(i)=olr;
fprintf('Iteration %i done.\n',i);
end

% save results

%% Compare Higher-Order KS and FFKS
target=[zeros(floor(num/2),1);ones(ceil(num/2),1)];
%[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1);
tpr1=[];tpr2=[];tpr3=[];tpr4=[];
fpr1=[];fpr2=[];fpr3=[];fpr4=[];
for i=1:kmax
[prec, tpr, fpr, thresh] = prec_rec(eksG_list(:,i), target, 'plotROC',0);
tpr1=[tpr1,tpr];fpr1=[fpr1,fpr];
[prec, tpr, fpr, thresh] = prec_rec(eksH_list(:,i), target, 'plotROC',0);
tpr2=[tpr2,tpr];fpr2=[fpr2,fpr];
[prec, tpr, fpr, thresh] = prec_rec(pks_list(:,i), target, 'plotROC',0);
tpr3=[tpr3,tpr];fpr3=[fpr3,fpr];
[prec, tpr, fpr, thresh] = prec_rec(pksr_list(:,i), target, 'plotROC',0);
tpr4=[tpr4,tpr];fpr4=[fpr4,fpr];

end
hold off;
[prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',0);
plot(fpr,tpr,'k-','linewidth',2);
hold on;
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',0);
plot(fpr,tpr,'r-','linewidth',2);

for i=1:kmax
plot(fpr1(:,i),tpr1(:,i),'r-','linewidth',2);
hold on;
plot(fpr2(:,i),tpr2(:,i),'b--','linewidth',2);
hold on;
plot(fpr3(:,i),tpr3(:,i),'c--','linewidth',2);
hold on;
plot(fpr4(:,i),tpr4(:,i),'g--','linewidth',2);

end


plot([0,1],[0,1],'k')
xlabel('False Postive Rate');
ylabel('True Postive Rate')

legend('Oracle (UMP)','0th Order KS','kth Order KS (with G)','kth Order FFKS (with H)','kth Order pKS', 'kth Order pKSR');
saveTightFig(gcf,'Exp_Normal_vs_T_ranks_HKS.pdf')

%% Compare KS and higher order KS
target=[zeros(floor(num/2),1);ones(ceil(num/2),1)];
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1);
for i=1:kmax
[prec, tpr, fpr, thresh] = prec_rec(eksH_list(:,i), target, 'plotROC',1,'holdFigure',1, 'numThresh',1000);
end

legend('baseline','KS','1stOrderFFKS','2ndOrderFFKS','3rdOrderFFKS','4thOrderFFKS','5thOrderFFKS');
saveTightFig(gcf,'Exp_Normal_vs_T_ranks_FFKS.pdf')
%%
target=[zeros(floor(num/2),1);ones(ceil(num/2),1)];
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1);
for i=1:kmax
[prec, tpr, fpr, thresh] = prec_rec(pks_list(:,i), target, 'plotROC',1,'holdFigure',1, 'numThresh',1000);
end

legend('baseline','KS','1stOrderPKS','2ndOrderPKS','3rdOrderPKS','4thOrderPKS','5thOrderPKS');
saveTightFig(gcf,'Exp_Normal_vs_T_ranks_PKS.pdf')
%%
target=[zeros(floor(num/2),1);ones(ceil(num/2),1)];
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1);
for i=1:kmax
[prec, tpr, fpr, thresh] = prec_rec(pksr_list(:,i), target, 'plotROC',1,'holdFigure',1, 'numThresh',1000);
end

legend('baseline','KS','1stOrderPKSR','2ndOrderPKSR','3rdOrderPKSR','4thOrderPKSR','5thOrderPKSR');
saveTightFig(gcf,'Exp_Normal_vs_T_ranks_PKSR.pdf')
%% Compare with other two-sample tests
[prec, tpr, fpr, thresh] = prec_rec(eksH_list(:,3), target, 'plotROC',1, 'numThresh',1000,'style','b-');
[prec, tpr, fpr, thresh] = prec_rec(pks_list(:,3), target, 'plotROC',1, 'holdFigure',1,'style','b--');
[prec, tpr, fpr, thresh] = prec_rec(pksr_list(:,3), target, 'plotROC',1, 'holdFigure',1,'style','b-.');
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1,'holdFigure',1,'style','k:');
[prec, tpr, fpr, thresh] = prec_rec(rs_list, target, 'plotROC',1,'holdFigure',1,'style','c-');
[prec, tpr, fpr, thresh] = prec_rec(mmd_list, target, 'plotROC',1,'holdFigure',1,'style','g-');
%[prec, tpr, fpr, thresh] = prec_rec(kb_list, target, 'plotROC',1,'holdFigure',1);
[prec, tpr, fpr, thresh] = prec_rec(ad_list, target, 'plotROC',1,'holdFigure',1,'style','r-');
[prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',1,'holdFigure',1,'style','k-.');
legend('baseline','3rdOrderFFKS','3rdOrderPKS','3rdOrderPKSR', 'KS','RankSum','MMD','AD','Oracle');
saveTightFig(gcf,'Exp_Normal_vs_T_ranks_others.pdf')