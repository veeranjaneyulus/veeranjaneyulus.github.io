function [ logL ] = pd_logL( x, pd )
% pd_logL compute the log-likelihood of Matlab's distribution object pd
%   x is samples.
%   logL is the loglikelihood.

y=pdf(pd,x);
logL=sum(log(y));

end

