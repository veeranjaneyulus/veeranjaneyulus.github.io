kmax = 5;
m=100;n=100;num=1000;
polyproj=false; % do not project out polynomials
w=0;
runsim=true; % true -> run simulations, false -> only plot
hksalldeg = [1:5, 8:4:20]; hks_choices = [1,2,3,5,6];
mmdpolydeg = [1:5, 8:4:20]; mmd_choices = [1,2,3,5,6];
hksodddeg = 1:2:kmax;
[tests_noolr,tt] = tests_noproj(kmax,polyproj,w,mmdpolydeg,hksalldeg);
% [tests_noolr,iproj,iprojfree,ihksall,immdpoly,iks,ienergy,immd,iad] = alltests(kmax, polyproj,w,mmdpolydeg,hksalldeg);
tt.iolr = numel(tests_noolr)+1;

dr = 'NewPlots2/';
suff = 'mmdweights'; % suffix indicating the method to combine hks test stats 
legend_labs_projfree = {'KS.new','MMD.poly','KS','Oracle'};
legend_labs_proj = {'KS.new.proj','MMD.poly','KS','Oracle'};
legend_labs_comb = {sprintf('KS.%s',suff),'MMD.poly','KS','Oracle'};

cc = get_colors();

%% N(0,1) vs. N(0.2,1)
prefix = sprintf('%sExp_1stMoment_v1_0',dr);
mu_diff = 0.2;
xgen = @(m,n) normrnd(0,1,m,n);
ygen = @(m,n) normrnd(0,1,m,n) + mu_diff;
olrfun = @(x,y) sum(y.^2) - sum( (y-mu_diff).^2);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end

plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)

function [tests,tt] = tests_noproj(kmax,polyproj,w,mmdpolydeg,hksalldeg)
    for k=1:kmax
        projfree_tests{k} = @(x,y) HKS_projfree_test(x,y,k,polyproj,false);
    end
    for i=1:numel(mmdpolydeg)
        mmdpoly_tests{i} = @(x,y) mmdTestPoly(x,y,mmdpolydeg(i));
    end
    for i=1:numel(hksalldeg)
        hksall_tests{i} = @(x,y) HKS_allk_test(x,y,hksalldeg(i));
    end
    tests = [ projfree_tests hksall_tests mmdpoly_tests ...
        {@kstestfun, @energyDist, @mmdfun, @adtestfun}];
    
    tt.iprojfree=1:kmax;
    tt.ihksall= tt.iprojfree(end)+ (1:numel(hksalldeg));
    tt.immdpoly=tt.ihksall(end)+ (1:numel(mmdpolydeg));
    tt.iks=max(tt.immdpoly)+1;
    tt.ienergy=tt.iks+1; 
    tt.immd=tt.iks+2;
    tt.iad=tt.iks+3;
end

function [] = plot_ex(prefix,tt,mmdpolydeg,hksalldeg,hksodddeg,hks_choices,mmd_choices,suff,legend_labs_projfree,legend_labs_comb,cc)
    load(sprintf('%s.mat',prefix),'ex')
    plotHKS(ex,sprintf('%s_HKS_projfree.pdf',prefix),tt.iprojfree,tt.immdpoly,tt.iks,tt.iolr,legend_labs_projfree)
    plotHKSOnly(ex,sprintf('%s_HKSOnly_projfree.pdf',prefix),tt.iprojfree,tt.iks,tt.iolr,cc)
    plotHKS(ex,sprintf('%s_HKS_%s.pdf',prefix,suff),tt.ihksall,tt.immdpoly,tt.iks,tt.iolr,legend_labs_comb)
    plotKSOthers(ex,sprintf('%s_benchmark_projfree.pdf',prefix),tt.iprojfree,tt.immdpoly,tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,mmdpolydeg,1:numel(tt.iprojfree),cc)
    plotKSOthers(ex,sprintf('%s_benchmark_%s.pdf',prefix,suff),tt.ihksall,tt.immdpoly,tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,mmdpolydeg,hksalldeg,cc)
    plotHKSOthers(ex,sprintf('%s_benchmark_projfree_allhksroc.pdf',prefix),tt.iprojfree(hksodddeg),tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,hksodddeg,cc)
    plotBestHKSOthers(ex,sprintf('%s_benchmark_projfree_besthksroc.pdf',prefix),tt.iprojfree,tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,1:numel(tt.iprojfree),cc)
    plotBestHKSOthers(ex,sprintf('%s_benchmark_%s_besthksroc.pdf',prefix,suff),tt.ihksall,tt.iks,tt.ienergy,tt.immd,tt.iad,tt.iolr,hksalldeg,cc)
    plotHKSMMD(ex,sprintf('%s_%s_HKSMMD.pdf',prefix,suff),tt.ihksall(hks_choices),tt.iks,tt.immdpoly(mmd_choices),tt.iolr,hksalldeg(hks_choices), mmdpolydeg(mmd_choices), cc)
end

