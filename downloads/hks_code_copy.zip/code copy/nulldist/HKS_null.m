function [ sample ] = HKS_null( Q, quantiles, k, sample_sz, t0 )
%HKS_NULL Asymptotic null
%		T is a grid on the support of Q: [Q.xmin, Q.xmax]
%   Projection onto polynomials is w.r.t Q
%
%			Q should be a struct with xmin, xmax, pdf, mu(1:k+1)
%				mu(i) = E_Q [ X^i ]

tt = icdf(Q.pd,sort(quantiles(:)));

% first set K(i,j) = E_{X~Q} [g_s(X) g_t(X)]
% and subtract Eg_s Eg_t from K(i,j) later to form covariance K

idxn = find(tt<t0,1,'last'); if isempty(idxn), idxn=0; end
idxp = find(tt>t0,1,'first'); if isempty(idxp), idxp=numel(tt)+1; end

% Approximate sup_{g in \cG_k} |GP(g)|
% with the max over the functions 
% g_{tt(1:idxn)}, g_{0-}, g_{0+}, g_{tt(idxp:nt)}
nK = idxn + (numel(tt)-idxp+1) + 2; 

tt = [tt(1:idxn); t0; t0; tt(idxp:end)];
idxn=idxn+1; % careful: updating idxn, idxp!
idxp=idxn+1;
K = zeros(nK);

% tt(tt<t0), 0-
for i=1:(idxn)
    for j=i:(idxn) % symmetrize K later
        s=tt(i);
        t=tt(j);
        
        f = @(x) max(s-x,0).^k .* max(t-x,0).^k .* Q.pd.pdf(x);
		K(i,j) = integral(f, Q.xmin, min(s,t));
    end
end

% 0+, tt(tt>t0)
for i=idxp:nK
    for j=i:nK % symmetrize K later
        s=tt(i);
        t=tt(j);
        
        f = @(x) max(x-s,0).^k .* max(x-t,0).^k .* Q.pd.pdf(x);
		K(i,j) = integral(f, max(s,t), Q.xmax);
    end
end

% nu(i) = E g_{tt(i)} essentially
nu = zeros(nK,1);
for i=1:idxn
    f = @(x) max(tt(i)-x,0).^k .* Q.pd.pdf(x);
    nu(i) = integral(f, Q.xmin, tt(i));
end
for i=idxp:nK
    f = @(x) max(x-tt(i),0).^k .* Q.pd.pdf(x);
    nu(i) = integral(f, tt(i), Q.xmax);
end

K = K+K'; % diagonal is 2x its right value
K(1:(nK+1):nK*nK) = K(1:(nK+1):nK*nK)/2; % halve the diagonal
K = K - nu * nu';

K = K./(factorial(k)^2);

% ignore the first and last points of the bridge
gaussian_sample = mvnrnd(zeros(1,nK-2),K(2:(nK-1),2:(nK-1)),sample_sz);

sample = max(abs(gaussian_sample),[],2);

end

% if k==0
%     quantiles=sort(quantiles);
%     nK = numel(quantiles);
%     K=zeros(nK,nK);
%     for i=1:nK
%         for j=i:nK
%             K(i,j) = quantiles(i) * (1-quantiles(j)); %quantiles are sorted
%         end
%     end
%     K = K+K';
%     K(1:(nK+1):nK*nK) = K(1:(nK+1):nK*nK)/2;
%     
%     gaussian_sample = mvnrnd(zeros(1,nK-2),K(2:(nK-1),2:(nK-1)),sample_sz);
%     sample1 = max(abs(gaussian_sample),[],2);
% end
% K2=K;
% 
