

%% This script explores potential failure case for
addpath('prec_rec')
addpath('btest-master')
addpath('mmd')
%% setting
m=100;n=100;
stats=0;
num=1000;
mu_diff=0.15;

kmax=4;
eksG_list=zeros(num,kmax);
eksH_list=zeros(num,kmax);

pks_list=zeros(num,kmax);
pksr_list=zeros(num,kmax);

ks_list=zeros(num,1);
rs_list=zeros(num,1);%rank-sum
kb_list=zeros(num,1);%kernel B-test
mmd_list=zeros(num,1);%MMD
ad_list=zeros(num,1);
olr_list=zeros(num,1);% oracle likelihood ratio test


% prefix = 'Exp_Laplace_vs_shiftedLaplace_ranks';
prefix = 'Exp_piecewiselinear_diff';
%pd = makedist('tLocationScale','nu',2);%default dof=5

pd = makedist('Exponential');

% for i=1:num
% x=sort(random(pd,m,1).*((rand(m,1)<0.5)-0.5)*2);
% if i<=floor(num/2)
% y=sort(random(pd,m,1).*((rand(m,1)<0.5)-0.5)*2);
% else
% y=sort(random(pd,m,1).*((rand(m,1)<0.5)-0.5)*2)+mu_diff;
% end

F_pwlinearpdf = @(d) @(x) ...
    (x <= 1/4) .* (x*(1-3*d-1/4) + x^2) + ...
    (x > 1/4) .* (1 - (1-x)*(1+d)); % constant pdf of 1+d in [1/4,1]

for i=1:num
    x = sort( unifrnd(0,1,m,1) );
    if i<=floor(num/2)
        y=sort( unifrnd(0,1,m,1) );
    else
        % step diff in pdfs
        %y=sort( [unifrnd(0,0.25,round(0.38*m),1); unifrnd(0.25,1,round(0.62*m),1)]);
        
        % piecewise linear diff in pdfs
        F = F_pwlinearpdf(0.2);
        y = sort(cdfrnd(F,m,1));
    end
    
    [z,idxx,idxy]=merge_sort_idx(x,y);
    sz=length(z);
    
    rx = find(idxx) ./ sz;
    ry = find(idxy) ./ sz;
    
    for j=1:kmax
        k=j;
        %     H = gen_fallingfactobasis( z,k );
        %     eksH=1/n*max(abs(H(:,k+2:sz)'*(double(idxx)-double(idxy))));
        
        % compare KS-test, Gk-test and Hk-test
        vv=HT_times(z,double(idxx)-double(idxy),k);
        eksH=1/n*max(abs(vv(k+2:sz)));
        eksH_list(i,j)=eksH;
        
        G = gen_trunc_pow_basis( z,k );
        eksG=1/n*max(abs(G(:,k+2:sz)'*(double(idxx)-double(idxy))));
        eksG_list(i,j)=eksG;
        
        
        pks_list(i,j)=pKS_test( x,y,k);
        pksr_list(i,j)=pKS_test( rx,ry,k);
        
    end
    
    %AD-test
    ad = ADtestk([[x, ones(size(x))];[y, 2*ones(size(y))]]);
    ad_list(i)=ad;
    
    %ks-test
    [h,p, ks]=kstest2(x,y);
    ks_list(i)=ks;
    
    %wilcoxon test
    [p,h,rs] = ranksum(x,y);
    rs_list(i)=abs(rs.zval);
    
    %alex's mmd
    
    mmd = mmdTestBootStats(x,y,-1);
    mmd_list(i)=mmd;
    
    %Fast MMD: B-test
    [h,p,kb]=btest(num2cell(x),num2cell(y));
    kb_list(i)=kb;
    
    
    
    %oracle likelihood ratio test
    logL0= -sum(abs([x;y]));
    logL1= -sum(abs(x))-sum(abs(y-mu_diff));
    %logL1= std_normal_logL((y-mu_diff))+std_normal_logL(x);
    olr=logL1-logL0;
    olr_list(i)=olr;
    fprintf('Iteration %i done.\n',i);
end



%% Compare Higher-Order KS and FFKS
target=[zeros(floor(num/2),1);ones(ceil(num/2),1)];
%[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1);
tpr1=[];tpr2=[];
fpr1=[];fpr2=[];
for i=1:kmax
    [prec, tpr, fpr, thresh] = prec_rec(eksG_list(:,i), target, 'plotROC',0);
    tpr1=[tpr1,tpr];fpr1=[fpr1,fpr];
    [prec, tpr, fpr, thresh] = prec_rec(eksH_list(:,i), target, 'plotROC',0);
    tpr2=[tpr2,tpr];fpr2=[fpr2,fpr];
end
hold off;
[prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',0);
plot(fpr,tpr,'k-.','linewidth',2);
hold on;
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',0);
plot(fpr,tpr,'k:','linewidth',2);

for i=1:kmax
    plot(fpr1(:,i),tpr1(:,i),'r-','linewidth',2);
    hold on;
    plot(fpr2(:,i),tpr2(:,i),'b--','linewidth',2);
end

plot([0,1],[0,1],'k')
xlim([-0.01,1.01]);
ylim([-0.01,1.01]);
xlabel('False Postive Rate');
ylabel('True Postive Rate')

hold off
legend('Oracle (UMP)','0th Order KS','kth Order KS (with G)','kth Order FFKS (with H)');
saveTightFig(gcf,sprintf('%s_HKS.pdf',prefix))

%% Compare KS and higher order KS
%%
figure
target=[zeros(floor(num/2),1);ones(ceil(num/2),1)];
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',0);
plot(fpr,tpr,'linewidth',2); hold on
for i=1:kmax
    [prec, tpr, fpr, thresh] = prec_rec(eksH_list(:,i), target, 'plotROC',0);
    plot(fpr,tpr,'linewidth',2); hold on
end
plot([0,1],[0,1],'k')
hold off
xlim([-0.01,1.01]);
ylim([-0.01,1.01]);

xlabel('False Postive Rate','FontSize',16);
ylabel('True Postive Rate','FontSize',16)

legend({},'FontSize',16,'Location','SouthEast')
legend('KS','KS (k=1)','KS (k=2)','KS (k=3)','KS (k=4)','baseline');
saveTightFig(gcf,sprintf('%s_FFKS.pdf',prefix))

%%
figure
target=[zeros(floor(num/2),1);ones(ceil(num/2),1)];
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',0);
plot(fpr,tpr,'linewidth',2); hold on
for i=1:kmax
    [prec, tpr, fpr, thresh] = prec_rec(pks_list(:,i), target, 'plotROC',0);
    plot(fpr,tpr,'linewidth',2); hold on
end
plot([0,1],[0,1],'k')
hold off
xlim([-0.01,1.01]);
ylim([-0.01,1.01]);

xlabel('False Postive Rate','FontSize',16);
ylabel('True Postive Rate','FontSize',16)

legend({},'FontSize',16,'Location','SouthEast')
legend('KS','KS (k=1)','KS (k=2)','KS (k=3)','KS (k=4)','baseline');
saveTightFig(gcf,sprintf('%s_PKS.pdf',prefix))

%%
target=[zeros(floor(num/2),1);ones(ceil(num/2),1)];
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',1);
for i=1:kmax
    [prec, tpr, fpr, thresh] = prec_rec(pksr_list(:,i), target, 'plotROC',1,'holdFigure',1, 'numThresh',1000);
end

legend('baseline','KS','1stOrderPKSR','2ndOrderPKSR','3rdOrderPKSR','4thOrderPKSR');
saveTightFig(gcf,sprintf('%s_PKSR.pdf',prefix))
hold off

%% Compare with other two-sample tests

[prec, tpr, fpr, thresh] = prec_rec(pks_list(:,1), target, 'plotROC',0);
plot(fpr,tpr,'linewidth',2); hold on
[prec, tpr, fpr, thresh] = prec_rec(ks_list, target, 'plotROC',0);
plot(fpr,tpr,'linewidth',2); hold on
[prec, tpr, fpr, thresh] = prec_rec(rs_list, target, 'plotROC',0);
plot(fpr,tpr,'linewidth',2); hold on
[prec, tpr, fpr, thresh] = prec_rec(mmd_list, target, 'plotROC',0);
plot(fpr,tpr,'linewidth',2); hold on
%[prec, tpr, fpr, thresh] = prec_rec(kb_list, target, 'plotROC',1,'holdFigure',1);
[prec, tpr, fpr, thresh] = prec_rec(ad_list, target, 'plotROC',0);
plot(fpr,tpr,'linewidth',2); hold on
[prec, tpr, fpr, thresh] = prec_rec(olr_list, target, 'plotROC',0);
plot(fpr,tpr,'linewidth',2); hold on
plot([0,1],[0,1],'k')
hold off
xlabel('False Postive Rate','FontSize',16);
ylabel('True Postive Rate','FontSize',16)

legend({},'FontSize',16,'Location','SouthEast')

legend('KS (k=1)', 'KS','RankSum','MMD','AD','Oracle','baseline');
saveTightFig(gcf,sprintf('%s_others.pdf',prefix))

