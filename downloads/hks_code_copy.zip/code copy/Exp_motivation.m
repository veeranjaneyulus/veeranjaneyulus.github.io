kmax = 5;
m=250;n=250;num=500;
polyproj=false; % do not project out polynomials
w=0;
runsim=false; % true -> run simulations, false -> only plot
centerhks = false;
hksalldeg = [1:5, 8:4:20];
[tests_noolr,ihks,iks] = alltests(kmax,polyproj);
iolr = numel(tests_noolr)+1;

cc = get_colors();
dr = 'NewPlots2/permnull_m250_';
if centerhks
    expsuff = ''; 
else
    expsuff = '_pin0';
end
prefix = sprintf('%sExp_2ndMoment_v1%s',dr,expsuff);
sigma_diff = 0.2;
xgen = @(m,n) normrnd(0,1,m,n);
ygen = @(m,n) normrnd(0,1,m,n) .* (1+sigma_diff);
olrfun = @(x,y) olrfun_2ndMoment_v1(x,y,sigma_diff);
tests = [tests_noolr {olrfun}];
if runsim
ex = exp_roc(xgen,ygen,m,n,num,tests);
res = simulate(ex); 
save(sprintf('%s.mat',prefix),'ex')
end


load(sprintf('%s.mat',prefix),'ex')
legend_labs = {'Higher-order KS', 'KS','Oracle'};

plotHKSOnly(ex,sprintf('%s_HKSOnly_projfree.pdf',prefix),ihks,iks,iolr,cc)

%%

%% Witness functions
kmax=5;
rng('default')
m=1000; n=1000;
x = sort(xgen(m,1));
y = sort(ygen(n,1));
[z,idx] = merge_sort_idx(x,y);

% run tests
wits = zeros(m+n,kmax+1);

for i=0:kmax
  [t,~,wit,~] = HKS_projfree_test(x,y,i);
  wits(:,i+1) = wit;
end


figure

x=linspace(-5,5,1000);
pdf1=pdf(makedist('Normal'),x);
pdf2=pdf(makedist('Normal','Sigma',1+sigma_diff),x);

% plotpdfs(sprintf('%s_pdf.pdf',prefix),x,pdf1,pdf2,'N(0,1)', 'N(0,1.44)');
plot(x,pdf1,'b','LineWidth',2);hold on
plot(x,pdf2,'r','LineWidth',2);hold on
plot(z, 0.5*wits(:,1)/(max(abs(wits(:,1)))+1e-10), 'color', cc.ks, 'linewidth', 2); hold on
for i=1:kmax
    plot(z, 0.5*wits(:,i+1)/(max(abs(wits(:,i+1)))+1e-10), 'color', cc.hks(i,:), 'linewidth', 2); hold on
end

ylim([-0.01,.51])

legend_labs = cell(kmax+3,1);
legend_labs{1} = 'N(0,1)';
legend_labs{2} = 'N(0,1.44)';

legend_labs{3} = 'KS k=0';
for i=4:(kmax+3)
    legend_labs{i} = sprintf('KS k=%d',i-3);
end


lg=legend(legend_labs);
set(lg,'fontsize',18,'Location','best')
saveTightFig(gcf,sprintf('%s_hks_witness.pdf',prefix))
hold off

%%
function olr = olrfun_2ndMoment_v1(x,y,sigma_diff)
    logL0= std_normal_logL( [x;y] );
    logL1= std_normal_logL((y))/(1+sigma_diff)^2 ...
        + length(y)*log(1/(1+sigma_diff)) +std_normal_logL(x);
    olr=logL1-logL0;
end

function [tests,ihks,iks] = alltests(kmax,polyproj)
    for k=1:kmax
        hks_tests{k} = @(x,y) HKS_projfree_test(x,y,k,polyproj);
    end
    tests = [ hks_tests {@kstestfun}];
    ihks = 1:kmax;
    iks = max(ihks)+1;
    
end

function [] = plotpdfs(filename,x,pdf1,pdf2,lab1,lab2)
    figure
    plot(x,pdf1,x,pdf2,'LineWidth',2)
    lh=legend(lab1,lab2);
    set(lh,'fontsize',18,'Location','best')
    set(gca,'Position',[.05 .05 .9 .93])
    saveTightFig(gcf,filename);
end
