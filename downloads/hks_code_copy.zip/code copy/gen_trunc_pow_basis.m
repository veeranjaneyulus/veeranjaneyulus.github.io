function [ G ] = gen_trunc_pow_basis( x,k )
%gen_trunc_pow_basis:   Generate an evaluation of truncated power basis with
%                       kth order
%----------------------------------------------------------------
% x:            input data points (sorted into ascending order)
% knots:        knots are assumed to be exactly the data points
% k:            order we want to consider
% G:            output basis matrix. Each column is the evaluations
%               of the truncated basis
%----------------------------------------------------------------

m=length(x);
if mod(k,2)%odd
    t=x(floor((1+k)/2+1):floor(m-(1+k)/2));%knots
    l = (1+k)/2;
else
    t=x(floor(k/2+2):floor(m-k/2));
    l = k/2+1;
end
t=x(k+1:m-1);
l = k;
G=zeros(m,m);

for i=1:k+1
    G(:,i)=x.^(i-1);
end
mask=true(m,1);
mask(1:l) = 0;

for i=k+2:m
    j=i-k-1;
    mask(j+l-1)=0;
    G(mask,i)=(x(mask)-t(j)).^k;
end
end

